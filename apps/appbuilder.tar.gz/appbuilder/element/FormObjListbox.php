<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class FormObjListbox extends Listbox
{
	
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {
		
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$objList = $svc->listFormObjects($selectFrom);
        foreach ($objList as $obj)
        {            
        	$obj = substr($obj,0,strlen($obj)-4);
        	$obj = str_replace("/",".",$obj);
            $list[$i]['val'] = $obj;
            $list[$i]['txt'] = str_replace($selectFrom.'.','',$obj);
            $i++;        	
        }
    }   
}
?>