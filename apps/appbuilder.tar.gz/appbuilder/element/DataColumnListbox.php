<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class DataColumnListbox extends Listbox
{
	
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {				
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$priModArr = $this->getFormObj()->getViewObject()->getPrimaryModule();
    	$priDoInfo = $svc->getDataObjectInfo($priModArr['primary_do']);
		$priDoDBConn = $priDoInfo['DBNAME'];
		$tableName = $this->getFormObj()->m_DataPanel->get('fld_intermediate_table_exists')->getValue();
		$db = BizSystem::dbConnection($priDoDBConn);

		$sql = "SHOW FULL COLUMNS FROM `$tableName`";
		$columnList = $db->fetchAssoc($sql);
    	
        foreach ($columnList as $column)
        {            
            $list[$i]['val'] = $column['Field'];
            $list[$i]['txt'] = $column['Field'];
            $i++;        	
        }
    }   
}
?>