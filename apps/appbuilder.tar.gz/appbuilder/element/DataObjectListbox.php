<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class DataObjectListbox extends Listbox
{
	
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {				
    	$module = $this->getFormObj()->m_DataPanel->get('fld_module_name')->getValue();
    	if(!$module)
    	{
    		return ;
    	}
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$doList = $svc->listDataObjects($module);
        foreach ($doList as $do)
        {            
            $list[$i]['val'] = $do;
            $txt = $do;
            //$txt = str_replace($module."/", "", $txt);
            $txt = str_replace("/", ".", $txt);
            $txt = str_replace(".xml", "", $txt);
            $list[$i]['txt'] = $txt;
            $i++;        	
        }
    }   
}
?>