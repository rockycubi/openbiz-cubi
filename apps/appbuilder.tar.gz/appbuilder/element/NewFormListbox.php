<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
include_once dirname(__FILE__).'/DetailFormListbox.php';
class NewFormListbox extends DetailFormListbox
{
	
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {				
    	switch(strtolower($this->m_Module))
    	{
    		case "primary":
    			$moduleArr = $this->getFormObj()->getViewObject()->getPrimaryModule();
    			$module = $moduleArr['primary_module'];    		
    			$obj = $moduleArr['primary_do'];	
    			break;
    		case "secondary":
    			$moduleArr = $this->getFormObj()->getViewObject()->getSecondaryModule();
    			$module = $moduleArr['secondary_module'];
    			$obj = $moduleArr['secondary_do'];
    			break;
    	}
    	
    	$subModule = $this->getSubModuleName($obj);
    	
    	if(!$module)
    	{
    		return ;
    	}
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);
        foreach ($formList as $form)
        {            
        	if(preg_match("/Widget/si",$form)){
        		continue;
        	}
        	if(preg_match("/New/si",$form)  && preg_match("/^".$subModule."/si",$form) ){
	            $list[$i]['val'] = $form;
	            $txt = $form;
	            //$txt = str_replace($module."/", "", $txt);
	            $txt = str_replace("/", ".", $txt);
	            $txt = str_replace(".xml", "", $txt);
	            $list[$i]['txt'] = $txt;
	            $i++;        	
        	}
        }
    }   
}
?>