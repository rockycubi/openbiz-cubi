<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN.'/easy/element/InputText.php';
class InputSimpleExpression extends InputPicker
{
	public function render()
	{
		$sHTML = InputText::render();
		if ($this->m_ValuePicker != null)
        {
            $function = $this->m_FormName . ".LoadPicker($this->m_ValuePicker,$this->m_Name)";
			$editor_btn = "
			<a href=\"#\" class=\"input_simpleexpression_editor_btn\" onClick=\"Openbiz.CallFunction('$function');\"></a>
			";
            $sHTML .= $editor_btn;
        }
		return $sHTML;
	}

}
?>