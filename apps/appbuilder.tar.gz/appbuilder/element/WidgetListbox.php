<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class WidgetListbox extends Listbox
{
	public $m_DOFilter;
	public $m_NameFilter;
	
	protected function readMetaData(&$xmlArr)
    {
        parent::readMetaData($xmlArr);
        $this->m_DOFilter 	= isset($xmlArr["ATTRIBUTES"]["DOFILTER"]) ? $xmlArr["ATTRIBUTES"]["DOFILTER"] : null;
        $this->m_NameFilter = isset($xmlArr["ATTRIBUTES"]["NAMEFILTER"]) ? $xmlArr["ATTRIBUTES"]["NAMEFILTER"] : null;
    }
    
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       

    protected function getSubModuleName($object)
    {
    	$objectArr = explode("/", $object);
    	if(count($objectArr)>3)
    	{
    		$subModule = $objectArr[0].'.'.$objectArr[1];
    	}
    	else
    	{
    		$subModule = $objectArr[0];
    	}
    	return $subModule;    	
    }    
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {				
    	$module = $this->getFormObj()->m_DataPanel->get('fld_module_name')->getValue();
    	$obj    = $this->getFormObj()->m_DataPanel->get('fld_do')->getValue();
    	
    	$doFilter = Expression::evaluateExpression($this->m_DOFilter, $this->getFormObj());
    	$doFilter = $this->__getObjName($doFilter);

    	if(!$module)
    	{
    		return ;
    	}
    	$subModule = $this->getSubModuleName($obj);
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);
        foreach ($formList as $form)
        {            
        	if(	preg_match("/Widget/si",$form)  
        		&& preg_match("/^".$subModule."/si",$form) 
        		&& preg_match("/".$this->m_NameFilter."/si",$form)
        		){
	            $formDO = $this->getFormDOName($form);	            
	            if($doFilter=="" || $formDO == $doFilter){
	        		$list[$i]['val'] = $form;
		            $txt = $form;
		            //$txt = str_replace($module."/", "", $txt);
		            $txt = str_replace("/", ".", $txt);
		            $txt = str_replace(".xml", "", $txt);
		            $list[$i]['txt'] = $txt;
		            $i++;
	            }
        	}
        }
    }   
    
    protected function getFormDOName($form)
    {
    	$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$form);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		return $xml->documentElement->attributes->getNamedItem("BizDataObj")->nodeValue;    	
    }
    
    private function __getObjName($obj_file)
	{
		$obj_name = str_replace(".xml", "", $obj_file);
		$obj_name = str_replace("/", ".", $obj_name);
		return $obj_name;
	}
	
}
?>