<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class SEDataFieldListbox extends Listbox
{
	
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {
		
    	$obj = BizSystem::getObject($selectFrom);
    	if(!is_a($obj,"BizDataObj"))
    	{
    		if(is_a($obj,"EasyForm"))
    		{
    			$do = $obj->m_DataObjName;
    			if($do){
    				$obj = BizSystem::getObject($do);			
    			}
    			else{
    				return;
    			}
    		}else{
    			return ;
    		} 
    	}
    	$fieldList = $obj->m_BizRecord;
        foreach ($fieldList as $field)
        {            
            $list[$i]['val'] = $field->m_Name;
            $list[$i]['txt'] = $field->m_Name." - ".$field->m_Column;
            $i++;        	
        }
    }   
}
?>