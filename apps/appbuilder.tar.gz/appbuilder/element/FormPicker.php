<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN.'/easy/element/InputText.php';
class FormPicker extends InputText
{
    public $m_ValuePicker;
    public $m_PickerMap;
    public $m_AllowClear;

    /**
     * Read array meta data, and store to meta object
     *
     * @param array $xmlArr
     * @return void
     */
    public function readMetaData(&$xmlArr)
    {
        parent::readMetaData($xmlArr);
        $this->m_ValuePicker  = isset($xmlArr["ATTRIBUTES"]["VALUEPICKER"]) ? $xmlArr["ATTRIBUTES"]["VALUEPICKER"] : null;
        $this->m_PickerMap  = isset($xmlArr["ATTRIBUTES"]["PICKERMAP"]) ? $xmlArr["ATTRIBUTES"]["PICKERMAP"] : null;
        // if no class name, add default class name. i.e. NewRecord => ObjName.NewRecord
        $this->m_ValuePicker = $this->prefixPackage($this->m_ValuePicker);
        $this->m_UpdateForm = isset($xmlArr["ATTRIBUTES"]["UPDATEFORM"]) ? $xmlArr["ATTRIBUTES"]["UPDATEFORM"] : "N";
        $this->m_AllowClear = isset($xmlArr["ATTRIBUTES"]["ALLOWCLEAR"]) ? $xmlArr["ATTRIBUTES"]["ALLOWCLEAR"] : "N";
    }

    /**
     * Render, draw the control according to the mode
     *
     * @return string HTML text
     */
    public function render()
    {
    	$this->m_Enabled='N';
        $sHTML = parent::render();

        // sample picker call CallFunction('easy.f_AttendeeListChild.LoadPicker(view,form,elem)','Prop_Window');
        if ($this->m_ValuePicker != null)
        {
            $function = $this->m_FormName . ".LoadPicker($this->m_ValuePicker,$this->m_Name)";
           // $sHTML .= " <input type=button onClick=\"Openbiz.CallFunction('$function');\" value=\"...\" style='width:20px;' />";
        }

        $editor_btn = "
		<a href=\"javascript:;\" onclick=\"if($('$this->m_Name').value){location.href='".APP_INDEX."/appbuilder/xml_edit/metaobj='+$('$this->m_Name').value}\" class=\"input_form_editor_btn\"></a>
		";
        if(strtoupper($this->m_AllowClear)=='Y'){
	        $clear_btn = "
			<a href=\"javascript:;\" onclick=\"$('$this->m_Name').value=''\" class=\"input_form_clear_btn\"></a>
			";
        }
		return $sHTML.$editor_btn.$clear_btn;
    }
	
    public function getEvents(){
    	$events = parent::getEvents();
    	$events['onclick'] .= "Openbiz.CallFunction('".$this->m_FormName . ".LoadPicker($this->m_ValuePicker,$this->m_Name)')";
        return $events;
    }
    
    public function matchRemoteMethod($method)
    {
        return ($method == "loadpicker");
    }	

}
?>