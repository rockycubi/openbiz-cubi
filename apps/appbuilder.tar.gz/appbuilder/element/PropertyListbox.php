<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class PropertyListbox extends Listbox
{
	
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {
		
    	if(!$selectFrom)
    	{
    		return;
    	}
    	$svc = BizSystem::getObject($selectFrom);
        foreach (get_object_vars($svc) as $method=>$value)
        {      
        	if(!is_string($method))
        	{
        		continue;
        	}              	
        	if( substr($method,0,1) == '_' ||
        		strtolower($method) == 'readmetadata' ||
        		strtolower($method) == 'dataformat'        		
        	){
        		continue;
        	}
            $list[$i]['val'] = $method;
            $list[$i]['txt'] = $method;
            $i++;        	
        }
    }   
}
?>