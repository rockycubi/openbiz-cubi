<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/LabelText.php";
class LabelMainTable extends LabelText
{
	public function render()
	{
		$formobj = $this->getFormObj();
		$metaFile = $formobj->m_MetaFile;
		$joinName = $this->getFormObj()->m_DataPanel->get('fld_joinref')->getValue();
		$xmlStr = file_get_contents($metaFile);		
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		if($joinName){
			//get join table name
			foreach($xml->getElementsByTagName("TableJoins")->item(0)->getElementsByTagName("Join") as $node)
			{
				if($node->attributes->getNamedItem("Name")->nodeValue == $joinName)				
				{
					$tableName = $node->attributes->getNamedItem("Table")->nodeValue ;
					break;				
				}			
			}	
		}
		else{
			//get main do table name
			$tableName = $xml->documentElement->attributes->getNamedItem("Table")->nodeValue;
		}
		$this->m_Value = $tableName;
		return parent::render();
	}	
}
?>