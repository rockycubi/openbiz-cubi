<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/Listbox.php";
class FormElementListbox extends Listbox
{
	
    public function getFromList(&$list, $selectFrom=null)
    {
        if (!$selectFrom) {
            $selectFrom = $this->getSelectFrom();
        }
        $this->getSimpleFromList($list, $selectFrom);
        if ($list != null)
            return;
        
        return;
    }	       
    
    protected function getSimpleFromList(&$list, $selectFrom)
    {
		
    	$obj = BizSystem::getObject($selectFrom);
    	if(!is_a($obj,"EasyForm"))
    	{
    		return ; 
    	}
    	$panel = $obj->m_DataPanel;
        foreach ($panel as $element)
        {            
            $list[$i]['val'] = $element->m_Name;
            $list[$i]['txt'] = $element->m_Name." - ".$element->m_FieldName;
            $i++;        	
        }
    }   
}
?>