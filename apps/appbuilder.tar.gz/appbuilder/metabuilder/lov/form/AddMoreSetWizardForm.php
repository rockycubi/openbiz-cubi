<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.lov.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class AddMoreSetWizardForm extends EasyFormWizard
{
    public function gotoStep($step)
    {   
    	$this->m_ActiveRecord = null;
    	$viewObj = $this->getViewObject();
        $viewObj->renderStep($step);
    }	
    
	public function goNext($commit=false)
	{		
	    $viewObj 	= $this->getViewObject();
	    $fileOption = $viewObj->getFileOption();
	    $valueSets 	= $viewObj->getAllValueSets();
	    
		//generate the file	    	    
	    $svcObj = BizSystem::getService("appbuilder.metabuilder.lov.lib.LovBuilderService");
	    $svcObj->setFileOption($fileOption);
	    $svcObj->setValueSets($valueSets);
	    $svcObj->generate();
	    
		parent::goNext(false);
	}    
}
?>