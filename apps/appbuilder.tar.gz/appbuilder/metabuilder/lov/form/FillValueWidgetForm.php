<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.lov.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FillValueWidgetForm extends EasyForm
{
	public $m_ActiveValueSetName;
	public $m_ActiveValueSetType;	
	
	public function fetchData()
	{
		$prtForm = BizSystem::getObject($this->m_ParentFormName);
		$valueSet = $prtForm->getViewObject()->getActiveValueSet();	
		
		$this->m_ActiveValueSetName = $valueSet['valueset_name'];
		$this->m_ActiveValueSetType = $valueSet['valueset_type'];
		
        if (strtoupper($this->m_FormType) == "NEW")
        {
            $result =  $this->getNewRecord();
            $result['SetName'] = $this->m_ActiveValueSetName;
        }
        else
        {        	           					
			$recordId = $this->m_RecordId;									
			$recordSet = $prtForm->getRecordList();
			if(is_array($recordSet))
			{
				foreach($recordSet as $key=>$data)
				{
					if($data['Id']==$recordId)
					{
						$result = $data;
						break;
					}
				}
			}
        }
			
		return $result;
	}
	
	public function updateRecord()
	{
		//validate the value exists or not
        $currentRec = $this->fetchData();
        $recArr = $this->readInputRecord();
		$rec = $this->readInputRecord();
		$valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
		if(is_array($valueSetData) && $currentRec['Value']!=$rec['Value'] ){
			foreach($valueSetData as $key=>$data)
			{
				if($data['Value']==$rec['Value'])
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_value" => $this->getMessage("VALUE_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}

		//save value
		$valueSet = BizSystem::getObject($this->m_ParentFormName)->getViewObject()->getActiveValueSet();
		$rec['Id'] 		= $rec['Value'];
		$rec['SetName'] = $valueSet['valueset_name'];
		$prtForm = BizSystem::getObject($this->m_ParentFormName);		
		$prtForm->updateValueSetRecord($rec,$currentRec['Id']);
		$prtForm->rerender();

		$this->close();
		return $result;		
	}
	
	public function insertRecord()
	{
		//validate the value exists or not
		$rec = $this->readInputRecord();
		$valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
		if(is_array($valueSetData)){
			foreach($valueSetData as $key=>$data)
			{
				if($data['Value']==$rec['Value'])
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_value" => $this->getMessage("VALUE_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}

		//save value
		$valueSet = BizSystem::getObject($this->m_ParentFormName)->getViewObject()->getActiveValueSet();
		$rec['Id'] 		= $rec['Value'];
		$rec['SetName'] = $valueSet['valueset_name'];
		$prtForm = BizSystem::getObject($this->m_ParentFormName);		
		$prtForm->addValueSetRecord($rec);
		$prtForm->rerender();

		$this->close();
		return $result;
	}
	
	   	
}
?>