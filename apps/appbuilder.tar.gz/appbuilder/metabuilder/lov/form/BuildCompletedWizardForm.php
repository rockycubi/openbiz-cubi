<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.lov.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class BuildCompletedWizardForm extends EasyFormWizard
{
	public $m_GenerateFileEncoded;
	
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$result['FileOption'] = $this->getViewObject()->getFileOption();
		$result['ValueSets'] = $this->getViewObject()->getAllValueSets();
		$result['GeneratedFileRaw'] = $result['FileOption']['module'].'.'.str_replace('/','.',$result['FileOption']['folder']).'.'.$result['FileOption']['filename'];
		$result['GeneratedFile'] = str_replace("..",'.',$result['GeneratedFileRaw']);
		$result['LovFile'] = substr($result['GeneratedFile'],0,strlen($result['GeneratedFile'])-4);
		$result['GeneratedFileEncoded'] = base64_encode( $result['FileOption']['module'].'/'.$result['FileOption']['folder'].'/'.$result['FileOption']['filename'] );
		return $result;
	}
	
	public function doFinish()
	{		
		$fileOption = $this->getViewObject()->getFileOption();
		$this->m_GeneratedFileEncoded = base64_encode( $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['filename'] );;
		$result = parent::doFinish();
		return $result;
	} 
	
}
?>