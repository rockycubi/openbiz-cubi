<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.lov.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class AddSetWizardForm extends EasyFormWizard
{
	public $m_ActiveValueSet;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "AcitveValueSet", $this->m_ActiveValueSet);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "AcitveValueSet", $this->m_ActiveValueSet);     
    }	
    
    public function clearActiveValueSet()
    {
    	$this->m_AcitveValueSet = null;
    	$this->m_ActiveRecord = null;
    	BizSystem::sessionContext()->setObjVar($this->m_Name, "AcitveValueSet",$this->m_AcitveValueSet, true);
		BizSystem::sessionContext()->setObjVar($this->m_Name, "ActiveRecord", $this->m_ActiveRecord, true);	
    }
    
	public function goNext($commit=false)
	{			    
		$rec = $this->readInputRecord();
		$this->m_ActiveValueSet = $rec;
		parent::goNext(false);
	}	    
}
?>