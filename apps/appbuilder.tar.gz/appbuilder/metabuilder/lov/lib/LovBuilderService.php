<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.lov.lib
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class LovBuilderService
{
	protected $m_FileOption;
	protected $m_ValueSets;
	
	public function setFileOption($fileOption)
	{
		$this->m_FileOption	=	$fileOption;
		return $this;
	}

	public function setValueSets($valueSets)
	{
		$this->m_ValueSets	=	$valueSets;
		return $this;
	}

	public function generate()
	{
		//test folder exists
		$module 	= $this->m_FileOption['module'];
		$folder 	= $this->m_FileOption['folder'];
		$filename 	= $this->m_FileOption['filename'];
		$folderPath = MODULE_PATH.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR.$folder.DIRECTORY_SEPARATOR;
		if(!is_dir($folderPath))
		{
			@mkdir($folderPath,0777,TRUE);
		}
		
		//generate file
		$smarty = BizSystem::getSmartyTemplate();                
        $smarty->assign("valueSets", $this->m_ValueSets);
		$templateFile = $this->__getMetaTempPath().'/lov/Selection.xml.tpl';
		
        $content = $smarty->fetch($templateFile);                
        $targetFile = $folderPath.$filename;
        file_put_contents($targetFile, $content);        
        
		//return file path
		return $targetFile;
	}
	
	private function __getMetaTempPath()
	{
		$this->m_MetaTempPath = MODULE_PATH.DIRECTORY_SEPARATOR.'appbuilder'.
											DIRECTORY_SEPARATOR.'resource'.
											DIRECTORY_SEPARATOR.'module_template';
		return $this->m_MetaTempPath; 
	}	
}
?>