<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.lov.widget
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class LovLeftWidget extends EasyForm
{
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$result['FileOption'] = $this->getViewObject()->getFileOption();
		$result['ValueSets'] = $this->getViewObject()->getAllValueSets();		
		return $result;
	}
	
	public function EditValueSet($setName)
	{				
		$viewObj = $this->getViewObject();
		if(!$viewObj->canEditValueSets())
		{
			return false;
		}
		$valueSets = $viewObj->getAllValueSets();
		if(!is_array($valueSets))
		{
			return;
		}
		foreach($valueSets as $valueSet)
		{
			if($valueSet['Setting']['valueset_name']==$setName)
			{	
				$valueSetSetting = $valueSet['Setting'];
				$valueSetData 	 = $valueSet['Data'];
				break;
			}
		}
		BizSystem::getObject("appbuilder.metabuilder.lov.form.AddSetWizardForm")->m_ActiveValueSet = $valueSetSetting;		
    	BizSystem::getObject("appbuilder.metabuilder.lov.form.FillValueWizardForm")->m_ActiveValueSetData = $valueSetData;
		if($viewObj->getCurrentStep()==4)
		{
			BizSystem::getObject("appbuilder.metabuilder.lov.form.FillValueWizardForm")->rerender();
		}else{
			$viewObj->renderStep(4);
		}
	}
} 
?>