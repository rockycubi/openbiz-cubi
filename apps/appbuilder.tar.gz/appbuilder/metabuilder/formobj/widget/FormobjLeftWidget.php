<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.widget
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FormobjLeftWidget extends EasyForm
{
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$result['FileOption'] = $this->getViewObject()->getFileOption();
		$result['Attributes'] = $this->getViewObject()->getAttributes();
		if($result['Attributes']['Class']=='CustomClass')
		{
			$result['Attributes']['Class']=$result['FileOption']['form_name'];
		}		
		$preview_image = "";
		$step = $this->getViewObject()->getCurrentStep();
		switch($step)
		{
			case "1":
			case "2":
				break;
			default:
			case "3":								
			case "4":
				if(strtolower($result['FileOption']['form_type'])=='list')
				{
					$preview_image = "listform.png";
				}else{
					$preview_image = "detailform.png";
				}
				break;
			case "5": //data panel
				if(strtolower($result['FileOption']['form_type'])=='list')
				{
					$preview_image = "listform_datapanel.png";
				}else{
					$preview_image = "detailform_datapanel.png";
				}
				break;
			case "6": //action panel
				if(strtolower($result['FileOption']['form_type'])=='list')
				{
					$preview_image = "listform_actionpanel.png";
				}else{
					$preview_image = "detailform_actionpanel.png";
				}
				break;
			case "7": //search panel
				if(strtolower($result['FileOption']['form_type'])=='list')
				{
					$preview_image = "listform_searchpanel.png";
				}
				break;
			case "8": //navi panel
				if(strtolower($result['FileOption']['form_type'])=='list')
				{
					$preview_image = "listform_navipanel.png";
				}
				break;
		}
		if($preview_image)
		{
			$preview_image = RESOURCE_URL.'/appbuilder/images/paneltype/'.$preview_image;
		}
		$result['preview_image'] = $preview_image;
		return $result;
	}
	
} 
?>