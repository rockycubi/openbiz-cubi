<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class PanelElementForm extends EasyFormWizard
{
	public $m_FormName;
	public $m_FormType;
	public $m_ParentFormName;
	public $m_Module;
	public $m_FormDataObj;
	
	protected function getParentFormName()
	{
		$step = $this->getViewObject()->getCurrentStep();
    	switch($step)
    	{
    		case "5":
    			$formName = "appbuilder.metabuilder.formobj.form.DataPanelWizardForm";
    			break;
    		case "6":
    			$formName = "appbuilder.metabuilder.formobj.form.ActionPanelWizardForm";
    			break;
    		case "7":
    			$formName = "appbuilder.metabuilder.formobj.form.SearchPanelWizardForm";
    			break;
    		case "8":
    			$formName = "appbuilder.metabuilder.formobj.form.NaviPanelWizardForm";
    			break;
    		default:
    			$formName = "";
    			break;
    	}
    	$this->m_ParentFormName = $formName;
    	return $formName;
	}
	
    protected function processPostAction()
    {
    	$formName = $this->getParentFormName();
    	if($formName)
    	{
        	return $this->_showForm($formName,null,array());
    	}
    }

	
	public function fetchData()
	{	
		$this->getParentFormName();
			
		$fileOption = $this->getViewObject()->getFileOption();		
		$this->m_FormName = $fileOption['form_name'];
		$this->m_FormType = $fileOption['form_type'];
		$this->m_Module = $fileOption['module'];
		
		$attrs = $this->getViewObject()->getAttributes();
		$this->m_FormDataObj = $attrs['BizDataObj'];		
		
		
		
		if ($this->m_ActiveRecord != null && $this->m_ActiveRecord['Id']==$this->m_RecordId)
            return $this->m_ActiveRecord;
            
		$prtForm = BizSystem::getObject($this->m_ParentFormName);
		
        if (strtoupper($this->m_FormType) == "NEW")
        {        	
            $result =  $this->getNewRecord();
        }
        else
        {        	           					
			$recordId = $this->m_RecordId;		
			$recordSet = $prtForm->getRecordList();			
			if(is_array($recordSet))
			{
				foreach($recordSet as $key=>$data)
				{
					if($data['Id']==$recordId)
					{
						$result = $data;
						break;
					}
				}
			}
        }
        if($result['EventHandler_Name'] && !isset($result['EventHandler_Enabled']))
        {
        	$result['EventHandler_Enabled']="1";
        }
        else
        {
        	$result['EventHandler_Enabled']="0";
        }
		return $result;
	}
	
	public function updateRecord()
	{
		$this->getParentFormName();
		
		//validate the value exists or not
		$rec = $this->readInputRecord();
        $currentRec = $this->fetchData();		

        $valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
				
		if(is_array($valueSetData) && $currentRec['Name']!=$rec['Name'] ){
			foreach($valueSetData as $key=>$data)
			{
				if(strtolower($data['Name'])==strtolower($rec['Name']))
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_element_name" => $this->getMessage("ELEMENT_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}
		
		//save value
		$rec['Id'] 		= $rec['Name'];
		$prtForm = BizSystem::getObject($this->m_ParentFormName);		
		$prtForm->updatePanelConfigRecord($rec,$currentRec['Id']);

		$this->m_ActiveRecord = null;
		$this->processPostAction();
		return $result;		
	}
	
	public function insertRecord()
	{
		$this->getParentFormName();
		
		//validate the value exists or not
		$rec = $this->readInputRecord();
		$valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
		if(is_array($valueSetData)){
			foreach($valueSetData as $key=>$data)
			{
				if(strtolower($data['Name'])==strtolower($rec['Name']))
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_element_name" => $this->getMessage("ELEMENT_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}

		
		
		//save value
		$rec['Id'] 		 = $rec['Name'];		
		$prtForm = BizSystem::getObject($this->m_ParentFormName);				
		$prtForm->addPanelConfigRecord($rec);

		$this->m_ActiveRecord = null;
		$this->processPostAction();
		return $result;
	}    
    
}
?>