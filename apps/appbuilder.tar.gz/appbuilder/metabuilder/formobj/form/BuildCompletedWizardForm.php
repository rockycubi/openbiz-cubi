<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class BuildCompletedWizardForm extends EasyFormWizard
{
	public $m_GenerateFileEncoded;
	public $m_GenerateMetaObj;
	
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$viewObj 	 			= $this->getViewObject();
	    $result['FileOption']  	= $viewObj->getFileOption();	    	    
		$result['Attributes'] 	= $viewObj->getAttributes();
		$result['Attributes'] 	= $viewObj->getCustomization();
		$result['DataPanel'] 	= $viewObj->getDataPanel();
		$result['SearchPanel'] 	= $viewObj->getSearchPanel();
		$result['ActionPanel'] 	= $viewObj->getActionPanel();
		$result['NaviPanel'] 	= $viewObj->getNaviPanel();

		$fileOption = $result['FileOption'];
		if(substr($fileOption['folder'],strlen($fileOption['folder'])-1,1)=='/')
		{
			$fileOption['folder'] = substr($fileOption['folder'],0,strlen($fileOption['folder'])-1);
		}
		
		$result['GeneratedPHPFile'] =  $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['form_name'].".php";
		$result['GeneratedXMLFile'] =  $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['form_name'].".xml";
		
		if(is_file(MODULE_PATH.DIRECTORY_SEPARATOR.$result['GeneratedPHPFile']))
		{
			$result['GeneratedPHPFileEncoded'] = base64_encode($result['GeneratedPHPFile']);
		}
		$result['GeneratedXMLFileEncoded'] = base64_encode($result['GeneratedXMLFile']);		
		
		$module 	= $result['FileOption']['module'];
		$folder 	= $result['FileOption']['folder'];
		$result['package'] = $module.'.'.str_replace('/','.',$folder);
		if(substr($result['package'],strlen($result['package'])-1,1)=='.')
		{
			$result['package'] = substr($result['package'],	0,	strlen($result['package'])-1);
		}
		
		return $result;
	}
	
	public function doFinish()
	{		
		$fileOption = $this->getViewObject()->getFileOption();
		if(substr($fileOption['folder'],strlen($fileOption['folder'])-1,1)=='/')
		{
			$fileOption['folder'] = substr($fileOption['folder'],0,strlen($fileOption['folder'])-1);
		}
		
		$generatedPHPFile = $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['form_name'];
		$this->m_GenerateMetaObj = str_replace("/",'.',$generatedPHPFile);
		
		$this->getViewObject()->clearFormPanels();
		
		$result = parent::doFinish();
		return $result;
	} 
	
}
?>