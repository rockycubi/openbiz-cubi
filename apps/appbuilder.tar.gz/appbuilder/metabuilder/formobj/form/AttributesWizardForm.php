<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class AttributesWizardForm extends EasyFormWizard
{
	public $m_FormName;
	public $m_FormType;
	public $m_ModuleName;
	
	const GENERAL_ELEMENTSET_ITEM_COUNT = 5;
	
	public function fetchData()
	{
		$result = parent::fetchData();
		$fileOption = $this->getViewObject()->getFileOption();
		$this->m_FormName = $fileOption['form_name'];
		$this->m_FormType = $fileOption['form_type'];
		$this->m_ModuleName = $fileOption['module'];
		return $result;
	}

	public function goSkipNext($commit=false)
	{	
        // call ValidateForm()
        $recArr = $this->readInputRecord();
        $this->setActiveRecord($recArr);
    	
   		 try
        {
             if ($this->ValidateForm() == false)
            return;
        }catch (ValidationException $e)
        {
            $this->processFormObjError($e->m_Errors);
            return;
        }

        $this->m_ActiveRecord = $this->readInputRecord();
		$viewObj = $this->getViewObject();
        // get the step
    	if($viewObj->getCurrentStep()){
        	$step = $viewObj->getCurrentStep();
        }else{
        	$step = $_GET['step'];
        }
        if (!$step || $step=="")
            $step=1;

        // redirect the prev step
        /* @var $viewObj EasyViewWizard */
        $this->preloadElements();
        
        $viewObj->renderStep($step+2);
	}		
	
	public function goNext($commit=false)
	{
		$this->preloadElements();
		return parent::goNext($commit);
	}
	
	public function getElementClass( $datatype, $name, $type="Read" )
	{
		switch (strtolower($type))
		{
			case "list":
				$class="ColumnText";
				break;
			case "read":
				$class="LabelText";
				break;
			default:
			case "write":
				$class="InputText";
				break;
		}
		return $class;
	}
	
	public function getElementSelectFrom( $datatype, $name )
	{
		
		return $selectFrom;
	}
	
	public function preloadElements()
	{
		$rec = $this->readInputRecord();				
		if(!$rec['BizDataObj'])
		{
			return;
		}
		
		if(BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelAutoLoaded){
			return;
		}
		
		$fileOption = $this->getViewObject()->getFileOption();
		$module = $fileOption['module'];
		$formType = $fileOption['form_type'];
		
		$doName = $rec['BizDataObj'];
		$do = BizSystem::getObject($doName);
		
		switch(strtolower($fileOption['form_type']))
		{
			case "list":
				//process data panel
				$elementList = array();
				foreach($do->m_BizRecord as $field)
				{
					$label = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $field->m_Name));
					$label = str_replace("_"," ",$label);
					$label = ucwords($label);
					
					if($field->m_Name=='Id')
					{
						$allowURLParam = "Y";
						$hidden="Y";
					}
					else
					{
						$allowURLParam = "N";
						$hidden="N";
					}				
						
					$element = array(
						"Id" 		=> "fld_".$field->m_Name,	
						"Name" 		=> "fld_".$field->m_Name,
						"FieldName" => $field->m_Name,
						"Class" 	=> $this->getElementClass($field->m_Type,$field->m_Name,'List'),
						"Enabled" => "",
						"SelectFrom"=> $this->getElementSelectFrom($field->m_Type,$field->m_Name),
						"Label"		=> $label,
						"Description"	=> $label,						
						"Sortable"  => "Y",
						"AllowURLParam"  => $allowURLParam,
						"Hidden"	=> $hidden,
					);
					$elementList[] = $element;
				}	
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelConfig = $elementList;
				
				//process action panel	
				$elementList = array();
				$element = array(
						"Id" 		=> "btn_new",
						"Name" 		=> "btn_new",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "",
						"Text" => "Add",
						"CssClass"	=> "button_gray_add",
						"Description" 	=> "New Record (Insert)",
						"Access" => $module.".Manage",			
						"EventHandler_Name"=>"btn_new_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"SwitchForm($module.form.RecordNewForm)",
						"EventHandler_ShortcutKey"=>"Insert",
						"EventHandler_ContextMenu"=>"New",
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_edit",
						"Name" 		=> "btn_edit",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "",
						"Text" => "Edit",
						"CssClass"	=> "button_gray_m",
						"Description" 	=> "Edit Record (Ctrl+E)",
						"Access" => $module.".Manage",			
						"EventHandler_Name"=>"btn_edit_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"EditRecord()",
						"EventHandler_RedirectPage"=>"form=$module.form.RecordEditForm&amp;fld:Id={@:Elem[fld_Id].Value}",
						"EventHandler_ShortcutKey"=>"Ctrl+E",
						"EventHandler_ContextMenu"=>"Edit",
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_copy",
						"Name" 		=> "btn_copy",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "",
						"Text" => "Copy",
						"CssClass"	=> "button_gray_m",
						"Description" 	=> "Copy Record (Ctrl+C)",
						"Access" => $module.".Manage",			
						"EventHandler_Name"=>"btn_copy_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"CopyRecord()",
						"EventHandler_RedirectPage"=>"form=$module.form.RecordCopyForm&amp;fld:Id={@:Elem[fld_Id].Value}",
						"EventHandler_ShortcutKey"=>"Ctrl+C",
						"EventHandler_ContextMenu"=>"Copy",
				);
				$elementList[] = $element;					
				$element = array(
						"Id" 		=> "btn_delete",
						"Name" 		=> "btn_delete",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "",
						"Text" => "Delete",
						"CssClass"	=> "button_gray_m",
						"Description" 	=> "Delete Record",
						"Access" => $module.".Manage",			
						"EventHandler_Name"=>"btn_delete_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"DeleteRecord()",						
						"EventHandler_ShortcutKey"=>"Ctrl+Delete",
						"EventHandler_ContextMenu"=>"Delete",
				);
				$elementList[] = $element;					
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->m_PanelConfig = $elementList;
				

				//process navi panel
				$elementList = array();
				$element = array(
						"Id" 		=> "page_selector",
						"Name" 		=> "page_selector",
						"FieldName" => "",
						"Class" =>  "PageSelector",
						"Enabled" => "",
						"Label" => "Go to Page",
						"Text" => "{@:m_CurrentPage}",
						"CssClass"	=> "input_select",
						"CssFocusClass"	=> "input_select_focus",
						"EventHandler_Name"=>"btn_page_selector_onchange",
						"EventHandler_Event"=>"onchange",
						"EventHandler_Function"=>"GotoSelectedPage(page_selector)",						
				);
				$elementList[] = $element;				
				$element = array(
						"Id" 		=> "pagesize_selector",
						"Name" 		=> "pagesize_selector",
						"FieldName" => "",
						"Class" =>  "PagesizeSelector",
						"Enabled" => "",
						"Label" => "Show Rows",
						"Text" => "{@:m_Range}",
						"CssClass"	=> "input_select",
						"CssFocusClass"	=> "input_select_focus",
						"EventHandler_Name"=>"btn_pagesize_selector_onchange",
						"EventHandler_Event"=>"onchange",
						"EventHandler_Function"=>"SetPageSize(pagesize_selector)",						
				);
				$elementList[] = $element;
				$element = array(
						"Id" 		=> "btn_first",
						"Name" 		=> "btn_first",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "{(@:m_CurrentPage == 1)?'N':'Y'}",
						"Label" => "",
						"Text" => "",
						"CssClass"	=> "button_gray_navi {(@:m_CurrentPage == 1)?'first_gray':'first'}",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_first_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"GotoPage(1)",						
				);
				$elementList[] = $element;
				$element = array(
						"Id" 		=> "btn_prev",
						"Name" 		=> "btn_prev",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "{(@:m_CurrentPage == 1)?'N':'Y'}",
						"Label" => "",
						"Text" => "",
						"CssClass"	=> "button_gray_navi {(@:m_CurrentPage == 1)?'prev_gray':'prev'}",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_prev_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"GotoPage({@:m_CurrentPage - 1})",		
						"EventHandler_ShortcutKey"=>"Ctrl+Shift+Left",				
				);
				$elementList[] = $element;
				$element = array(
						"Id" 		=> "txt_page",
						"Name" 		=> "txt_page",
						"FieldName" => "",
						"Class" =>  "LabelText",
						"Enabled" => "",
						"Label" => "",
						"Text" => "{'@:m_CurrentPage of @:m_TotalPages '}",
						"CssClass"	=> "",
						"CssFocusClass"	=> ""				
				);
				$elementList[] = $element;
				$element = array(
						"Id" 		=> "btn_next",
						"Name" 		=> "btn_next",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "{(@:m_CurrentPage == @:m_TotalPages )?'N':'Y'}",
						"Label" => "",
						"Text" => "",
						"CssClass"	=> "button_gray_navi {(@:m_CurrentPage == @:m_TotalPages)?'next_gray':'next'}",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_next_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"GotoPage({@:m_CurrentPage + 1})",		
						"EventHandler_ShortcutKey"=>"Ctrl+Shift+Right",				
				);
				$elementList[] = $element;
				$element = array(
						"Id" 		=> "btn_last",
						"Name" 		=> "btn_last",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "{(@:m_CurrentPage == @:m_TotalPages )?'N':'Y'}",
						"Label" => "",
						"Text" => "",
						"CssClass"	=> "button_gray_navi {(@:m_CurrentPage == @:m_TotalPages)?'last_gray':'last'}",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_last_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"GotoPage({@:m_TotalPages})",		
						"EventHandler_ShortcutKey"=>"",				
				);
				$elementList[] = $element;
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.NaviPanelWizardForm")->m_PanelConfig = $elementList;
				
				//process search panel				
				$elementList = array();
				$do->m_BizRecord->rewind();
				$do->m_BizRecord->next();
				$field = $do->m_BizRecord->current();
				$fieldName = $field->m_Name;
				$element = array(
						"Id" 		=> "qry_$fieldName",
						"Name" 		=> "qry_$fieldName",
						"FieldName" => "$fieldName",
						"Class" =>  "AutoSuggest",
						"SelectFrom" => "{$doName}[{$fieldName}],[{$fieldName}] like '%{@:Elem[qry_{$fieldName}].Value}%' GROUP BY [{$fieldName}]",
						"Enabled" => "",
						"FuzzySearch"=>"Y",
						"Label" => "",
						"Text" => "",
						"CssClass"	=> "input_text_search",
						"CssFocusClass"	=> "input_text_search_focus",
			
				);
				$elementList[] = $element;
				$element = array(
						"Id" 		=> "btn_search",
						"Name" 		=> "btn_search",
						"FieldName" => "",
						"Class" =>  "Button",
						"Enabled" => "{(@:m_CurrentPage == @:m_TotalPages )?'N':'Y'}",
						"Label" => "",
						"Text" => "Go",
						"CssClass"	=> "button_gray",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_search_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"RunSearch()",		
						"EventHandler_ShortcutKey"=>"Enter",				
				);
				$elementList[] = $element;
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.SearchPanelWizardForm")->m_PanelConfig = $elementList;				
				
				break;
				
				
			case "detail":
				//process data panel
				$elementList = array();
				$elementSetI = 0;
				foreach($do->m_BizRecord as $field)
				{
					$label = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $field->m_Name));
					$label = str_replace("_"," ",$label);
					$label = ucwords($label);
					
					if($field->m_Name=='Id')
					{
						$allowURLParam = "Y";
						$hidden="Y";
					}
					else
					{
						$allowURLParam = "N";
						$hidden="N";
					}				
					
					switch($this->m_Name){
						case "create_by":
						case "update_by":
						case "create_time":
						case "update_time":
							$elementSet = "Miscellaneous";
							break;
						default:
							$elementSetI++;
							if($elementSetI <= self::GENERAL_ELEMENTSET_ITEM_COUNT)
							{
								$elementSet = "General";
							}else{
								$elementSet = "Additional";
							}
							break;
					}
					
					$element = array(
						"Id" 		=> "fld_".$field->m_Name,
						"Name" 		=> "fld_".$field->m_Name,
						"FieldName" => $field->m_Name,
						"Class" 	=> $this->getElementClass($field->m_Type,$field->m_Name,'Read'),
						"SelectFrom"=> $this->getElementSelectFrom($field->m_Type,$field->m_Name),
						"Label"		=> $label,
						"Description"	=> $label,
						"ElementSet"  => $elementSet,
						"AllowURLParam"  => $allowURLParam,
						"Hidden"	=> $hidden,
					);
					$elementList[] = $element;
				}
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelConfig = $elementList;
				
				//process action panel					
				$elementList = array();  
				$element = array(
						"Id" 		=> "btn_new",
						"Name" 		=> "btn_new",
						"FieldName" => "",
						"Class" =>  "Button",
						"Description"=>"New Record (Insert)",
						"Label" => "",
						"Text" => "Add",
						"CssClass"	=> "button_gray_add",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_new_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"SwitchForm($module.form.".ucfirst($module)."NewForm)",		
						"EventHandler_ShortcutKey"=>"Insert",
						"EventHandler_ContextMenu"=>"New",				
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_edit",
						"Name" 		=> "btn_edit",
						"FieldName" => "",
						"Class" =>  "Button",
						"Description"=>"Edit Record (Ctrl+E)",
						"Label" => "",
						"Text" => "Edit",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_new_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"SwitchForm($module.form.".ucfirst($module)."EditForm,{@:Elem[fld_Id].Value})",		
						"EventHandler_ShortcutKey"=>"Ctrl+E",
						"EventHandler_ContextMenu"=>"Edit",				
				);
				$elementList[] = $element;		
				$element = array(
						"Id" 		=> "btn_copy",
						"Name" 		=> "btn_copy",
						"FieldName" => "",
						"Class" =>  "Button",
						"Description"=>"Copy Record (Ctrl+C)",
						"Label" => "",
						"Text" => "Copy",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_copy_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"CopyRecord({@:Elem[fld_Id].Value})",
						"EventHandler_RedirectPage"=>"form=$module.form.".ucfirst($module)."CopyForm&amp;fld:Id={@:Elem[fld_Id].Value}",		
						"EventHandler_ShortcutKey"=>"Ctrl+C",
						"EventHandler_ContextMenu"=>"Copy",				
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_delete",
						"Name" 		=> "btn_delete",
						"FieldName" => "",
						"Class" =>  "Button",
						"Description"=>"Delete Record (Delete)",
						"Label" => "",
						"Text" => "Delete",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_delete_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"DeleteRecord({@:Elem[fld_Id].Value})",
						"EventHandler_RedirectPage"=>"{APP_INDEX}/$module/{$module}_manage",		
						"EventHandler_ShortcutKey"=>"Ctrl+Delete",
						"EventHandler_ContextMenu"=>"Delete",				
				);
				$elementList[] = $element;		
				$element = array(
						"Id" 	=> "btn_cancel",
						"Name" 	=> "btn_cancel",
						"Class" =>  "LabelBack",
						"Link" => "{APP_INDEX}/$module/{$module}_manage",
						"Text" => "Back",
						"CssClass"	=> "button_gray_m",									
				);
				$elementList[] = $element;									
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->m_PanelConfig = $elementList;				
				break;
				
				
			case "edit":
				//process data panel
				$elementList = array();
				$elementSetI = 0;
				foreach($do->m_BizRecord as $field)
				{
					$label = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $field->m_Name));
					$label = str_replace("_"," ",$label);
					$label = ucwords($label);
					
					if($field->m_Name=='Id')
					{
						$allowURLParam = "Y";
						$hidden="Y";
					}
					else
					{
						$allowURLParam = "N";
						$hidden="N";
					}				
					
					switch($this->m_Name){
						case "create_by":
						case "update_by":
						case "create_time":
						case "update_time":
							$elementSet = "Miscellaneous";
							break;
						default:
							$elementSetI++;
							if($elementSetI <= self::GENERAL_ELEMENTSET_ITEM_COUNT)
							{
								$elementSet = "General";
							}else{
								$elementSet = "Additional";
							}
							break;
					}
					
					$element = array(
						"Id" 		=> "fld_".$field->m_Name,
						"Name" 		=> "fld_".$field->m_Name,
						"FieldName" => $field->m_Name,
						"Class" 	=> $this->getElementClass($field->m_Type,$field->m_Name,'write'),
						"SelectFrom"=> $this->getElementSelectFrom($field->m_Type,$field->m_Name),
						"Label"		=> $label,
						"Description"	=> $label,
						"ElementSet"  => $elementSet,
						"AllowURLParam"  => $allowURLParam,
						"Hidden"	=> $hidden,
					);
					$elementList[] = $element;
				}
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelConfig = $elementList;
				
				//process action panel		
				$elementList = array();
				$element = array(
						"Id" 		=> "btn_save",
						"Name" 		=> "btn_save",
						"FieldName" => "",
						"Class" =>  "Button",
						"Label" => "",						
						"Text" => "Save",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_save_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"UpdateRecord()",
						"EventHandler_RedirectPage"=>"{APP_INDEX}/$module/{$module}_detail/{@$doName:Field[Id].Value}",		
						"EventHandler_ShortcutKey"=>"Ctrl+Enter",	
						"EventHandler_ContextMenu"=>"Save",				
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_cancel",
						"Name" 		=> "btn_cancel",
						"FieldName" => "",
						"Class" =>  "Button",
						"Label" => "",
						"Text" => "Cancel",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_cancel_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"SwitchForm()",
						"EventHandler_ShortcutKey"=>"Escape",	
						"EventHandler_ContextMenu"=>"Cancel",				
				);
				$elementList[] = $element;			
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->m_PanelConfig = $elementList;
				break;
				
				
			case "copy":
				//process data panel		
				$elementList = array();
				$elementSetI = 0;
				foreach($do->m_BizRecord as $field)
				{
					$label = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $field->m_Name));
					$label = str_replace("_"," ",$label);
					$label = ucwords($label);
					
					if($field->m_Name=='Id')
					{
						$allowURLParam = "Y";
						$hidden="Y";
					}
					else
					{
						$allowURLParam = "N";
						$hidden="N";
					}				
					
					switch($this->m_Name){
						case "create_by":
						case "update_by":
						case "create_time":
						case "update_time":
							$elementSet = "Miscellaneous";
							break;
						default:
							$elementSetI++;
							if($elementSetI <= self::GENERAL_ELEMENTSET_ITEM_COUNT)
							{
								$elementSet = "General";
							}else{
								$elementSet = "Additional";
							}
							break;
					}
					
					$element = array(
						"Id" 		=> "fld_".$field->m_Name,
						"Name" 		=> "fld_".$field->m_Name,
						"FieldName" => $field->m_Name,
						"Class" 	=> $this->getElementClass($field->m_Type,$field->m_Name,'write'),
						"SelectFrom"=> $this->getElementSelectFrom($field->m_Type,$field->m_Name),
						"Label"		=> $label,
						"Description"	=> $label,
						"ElementSet"  => $elementSet,
						"AllowURLParam"  => $allowURLParam,
						"Hidden"	=> $hidden,
					);
					$elementList[] = $element;
				}
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelConfig = $elementList;
				
				//process action panel		
				$elementList = array();
				$element = array(
						"Id" 		=> "btn_save",
						"Name" 		=> "btn_save",
						"FieldName" => "",
						"Class" =>  "Button",
						"Label" => "",
						"Text" => "Save",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_save_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"InsertRecord()",
						"EventHandler_RedirectPage"=>"{APP_INDEX}/$module/{$module}_detail/{@$doName:Field[Id].Value}",		
						"EventHandler_ShortcutKey"=>"Ctrl+Enter",	
						"EventHandler_ContextMenu"=>"Save",				
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_cancel",
						"Name" 		=> "btn_cancel",
						"FieldName" => "",
						"Class" =>  "Button",
						"Label" => "",
						"Text" => "Cancel",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_cancel_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"SwitchForm()",
						"EventHandler_ShortcutKey"=>"Escape",	
						"EventHandler_ContextMenu"=>"Cancel",				
				);
				$elementList[] = $element;							
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->m_PanelConfig = $elementList;
				break;
				
				
			case "new":
				//process data panel
				$elementList = array();
				$elementSetI = 0;
				foreach($do->m_BizRecord as $field)
				{
					$label = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $field->m_Name));
					$label = str_replace("_"," ",$label);
					$label = ucwords($label);
					
					if($field->m_Name=='Id')
					{
						$allowURLParam = "Y";
						$hidden="Y";
					}
					else
					{
						$allowURLParam = "N";
						$hidden="N";
					}				
					
					switch($this->m_Name){
						case "create_by":
						case "update_by":
						case "create_time":
						case "update_time":
							$elementSet = "Miscellaneous";
							break;
						default:
							$elementSetI++;
							if($elementSetI <= self::GENERAL_ELEMENTSET_ITEM_COUNT)
							{
								$elementSet = "General";
							}else{
								$elementSet = "Additional";
							}
							break;
					}
					
					$element = array(
						"Id" 		=> "fld_".$field->m_Name,
						"Name" 		=> "fld_".$field->m_Name,
						"FieldName" => $field->m_Name,
						"Class" 	=> $this->getElementClass($field->m_Type,$field->m_Name,'write'),
						"SelectFrom"=> $this->getElementSelectFrom($field->m_Type,$field->m_Name),
						"Label"		=> $label,
						"Description"	=> $label,
						"ElementSet"  => $elementSet,
						"AllowURLParam"  => $allowURLParam,
						"Hidden"	=> $hidden,
					);
					$elementList[] = $element;
				}				
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelConfig = $elementList;
				
				//process action panel
				$elementList = array();
				$element = array(
						"Id" 		=> "btn_save",
						"Name" 		=> "btn_save",
						"FieldName" => "",
						"Class" =>  "Button",
						"Label" => "",
						"Text" => "Save",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_save_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"InsertRecord()",
						"EventHandler_RedirectPage"=>"{APP_INDEX}/$module/{$module}_detail/{@$doName:Field[Id].Value}",		
						"EventHandler_ShortcutKey"=>"Ctrl+Enter",	
						"EventHandler_ContextMenu"=>"Save",				
				);
				$elementList[] = $element;	
				$element = array(
						"Id" 		=> "btn_cancel",
						"Name" 		=> "btn_cancel",
						"FieldName" => "",
						"Class" =>  "Button",
						"Label" => "",
						"Text" => "Cancel",
						"CssClass"	=> "button_gray_m",
						"CssFocusClass"	=> "",
						"EventHandler_Name"=>"btn_cancel_onclick",
						"EventHandler_Event"=>"onclick",
						"EventHandler_Function"=>"SwitchForm()",
						"EventHandler_ShortcutKey"=>"Escape",	
						"EventHandler_ContextMenu"=>"Cancel",				
				);
				$elementList[] = $element;		
				BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->m_PanelConfig = $elementList;
				break;
		}
		
		BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelAutoLoaded = true;
		
	}
	
	protected function getColumns($dbName,$dbTable)
	{
		$db = BizSystem::instance()->getDBConnection($dbName);
		$fieldList = $db->fetchAssoc("SHOW FULL COLUMNS FROM `$dbTable`");
    	return $fieldList;
	}
	
	public function getDefaultJsClass()
	{
		$fileOption = $this->getViewObject()->getFileOption();
		switch(strtolower($fileOption['form_type']))
		{
			case "list":
				$jsClass = "Openbiz.TableForm";
				break;
			case "detail":
			case "edit":
			case "copy":
			case "new":
				$jsClass = "Openbiz.Form";
				break;
		}
		return $jsClass;
	}
	
	public function getDefaultDesc()
	{
		$fileOption = $this->getViewObject()->getFileOption();
		$fileOption['form_name'] = str_replace("Form","",$fileOption['form_name']);
		$desc = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $fileOption['form_name']));
		return $desc;
	}
}
?>