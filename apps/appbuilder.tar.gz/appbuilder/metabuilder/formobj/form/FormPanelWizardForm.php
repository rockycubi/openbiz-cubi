<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FormPanelWizardForm extends EasyFormWizard
{
	public $m_PanelConfig;
	public $m_PanelAutoLoaded = false;
	
	public $m_ObjClassType;
	
	public function runSearch()
    {
        include_once(OPENBIZ_BIN."/easy/SearchHelper.php");
        $searchRule = "";
        foreach ($this->m_SearchPanel as $element)
        {
            $searchStr = '';
        	if(method_exists($element,"getSearchRule")){
        		$searchStr = $element->getSearchRule();        		
        	}else{        	
	            if (!$element->m_FieldName)
	                continue;
	
	            $value = BizSystem::clientProxy()->getFormInputs($element->m_Name);     	                   
	            if($element->m_FuzzySearch=="Y")
	            {
	                $value="*$value*";
	            }
	            if ($value!='')
	            {
	                $searchStr = inputValToRule($element->m_FieldName, $value, $this);	  
	                $values[] = $value; 	                           
	            }
        	}
        	if($searchStr){
        		if ($searchRule == "")
                    $searchRule .= $searchStr;
                else
                    $searchRule .= " AND " . $searchStr;
        	}        	        	
        }
        $this->m_SearchRule = $searchRule;
        $this->m_SearchRuleBindValues = $values;

        $this->m_RefreshData = true;

        $this->m_CurrentPage = 1;

        BizSystem::log(LOG_DEBUG,"FORMOBJ",$this->m_Name."::runSearch(), SearchRule=".$this->m_SearchRule);

		$recArr = $this->readInputRecord();		
		
		$this->m_SearchPanelValues = $recArr;
		
        
        $this->runEventLog();
        $this->rerender();
    }	
	
	public function fetchDataSet()
	{				
		//init variables
		$resultRaw = $this->getRecordList();
		
		$attrs = $this->getViewObject()->getAttributes();
		$this->m_ObjClassType = $attrs['Class'];
		
		if(!is_array($resultRaw))
		{
			return array();
		}
		
		$searchRule = $this->m_SearchRule;		
		
		preg_match_all("/\[(.*?)\]/si", $searchRule,$match);	
		$i=0;		
		$searchFilter = array();
		if(is_array($this->m_SearchRuleBindValues))
		{
			foreach( $this->m_SearchRuleBindValues as $key=>$value)
			{
				$fieldName = $match[1][$i];
				$fieldValue = $value;
				$i++;
				$searchFilter[$fieldName]=$fieldValue;
			}		
		}
		if(count($searchFilter))
		{
			
			foreach($resultRaw as $record)
			{				
				$testField = false;
				foreach($searchFilter as $field=>$value)
				{					
					if($record[$field]!=$value){
						$testField =true;
						break;
					}
				}
				if(!$testField)
				{
					$result[] = $record; 
				}
			}
		}
		else
		{
			$result=$resultRaw;
		}
		
    	//set default selected record
		if(!$this->m_RecordId){
				$this->m_RecordId=$result[0]["Name"];
		}
		//set paging 
		$this->m_TotalRecords = count($result);
			
        if ($this->m_Range && $this->m_Range > 0)
            $this->m_TotalPages = ceil($this->m_TotalRecords/$this->m_Range);
		
        if($this->m_CurrentPage > $this->m_TotalPages)
        {
        	$this->m_CurrentPage = $this->m_TotalPages;
        }
            
        if(is_array($result)){
			$result = array_slice($result,($this->m_CurrentPage-1)*$this->m_Range,$this->m_Range);
		}	    
            
    	return $result;
	}		
	
	public function getRecordList()
	{
		return $this->m_PanelConfig;		
	}
	
	public function deleteRecord($id=null)
	{
		if ($id==null || $id=='')
            $id = BizSystem::clientProxy()->getFormInputs('_selectedId');

        $selIds = BizSystem::clientProxy()->getFormInputs('row_selections', false);
        if ($selIds == null)
            $selIds[] = $id;
        foreach ($selIds as $id)
        {        	
            if(is_array($this->m_PanelConfig))
            {
            	foreach($this->m_PanelConfig as $key=>$value)
            	{
            		if($value['Id']==$id)
            		{
            			$deleteKeys[]=$key;	
            		}
            	}
            }
        }
        if(is_array($deleteKeys))
        {
        	foreach($deleteKeys as $key)
        	{
        		unset($this->m_PanelConfig[$key]);
        	}
        }
        
        if (strtoupper($this->m_FormType) == "LIST")
            $this->rerender();

        $this->runEventLog();
        $this->processPostAction();
	}
	
	public function loadDialog($formName, $id=null,$transId=false)
    {
    	$paramFields = array();   
    	if($id==null)
    	{     
        	$paramFields["Id"] = $this->m_RecordId;
    	}else{
    		$paramFields["Id"] = $id;
    	}
        if ($transId!=false)
            $paramFields["Id"] = $this->m_RecordId;
        $this->_showForm($formName, "Dialog", $paramFields);
    }
	
	public function addPanelConfigRecord($rec)
	{
		$this->m_PanelConfig[] = $rec;
		return $this->m_PanelConfig;
	}
	
	public function updatePanelConfigRecord($rec,$Id)
	{
		if(is_array($this->m_PanelConfig))
		{
			foreach ($this->m_PanelConfig as $key=>$data)
			{
				if($data['Id']==$Id)
				{					
					$this->m_PanelConfig[$key]=$rec;
					return $this->m_PanelConfig;
				}
			}
		}
	}
	
    public function goFinish()
    {
		$viewObj = $this->getViewObject();
        // get the step
    	if($viewObj->getCurrentStep()){
        	$step = $viewObj->getCurrentStep();
        }else{
        	$step = $_GET['step'];
        }
        if (!$step || $step=="")
            $step=1;

        $viewObj->renderStep(9);
    }
	
	
	public function goNext($commit=false)
	{		
		parent::goNext(false);
	}	
	
	public function generateFiles()
	{
		$viewObj 	 	= $this->getViewObject();
	    $fileOption  	= $viewObj->getFileOption();	    	    
		$attributes 	= $viewObj->getAttributes();
		$customization 	= $viewObj->getCustomization();
		$dataPanel 		= $viewObj->getDataPanel();
		$searchPanel 	= $viewObj->getSearchPanel();
		$actionPanel 	= $viewObj->getActionPanel();
		$naviPanel 		= $viewObj->getNaviPanel();
		
		$svcobj = BizSystem::getService("appbuilder.metabuilder.formobj.lib.FormobjBuilderService");
		$svcobj->setFileOption($fileOption);
		$svcobj->setAttributes($attributes);
		$svcobj->setCustomization($customization);
		$svcobj->setDataPanel($dataPanel);
		$svcobj->setActionPanel($actionPanel);
		$svcobj->setSearchPanel($searchPanel);
		$svcobj->setNaviPanel($naviPanel);

		$svcobj->generate();
		
		return;
	}
	
	public function clearPanelConfig()
	{
		$this->m_PanelConfig = null;
		$this->m_PanelAutoLoaded = null;
		BizSystem::sessionContext()->setObjVar($this->m_Name, "PanelConfig",			$this->m_PanelConfig, true);
		BizSystem::sessionContext()->setObjVar($this->m_Name, "PanelAutoLoaded",		$this->m_PanelAutoLoaded, true);
	}
	
	public function cancel()
	{
		$this->clearPanelConfig();
		return parent::cancel();
	}
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "PanelConfig", $this->m_PanelConfig);
        $sessionContext->getObjVar($this->m_Name, "PanelAutoLoaded", $this->m_PanelAutoLoaded);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "PanelConfig", $this->m_PanelConfig);  
        $sessionContext->setObjVar($this->m_Name, "PanelAutoLoaded", $this->m_PanelAutoLoaded);   
    }		
}
?>