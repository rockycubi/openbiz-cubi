<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class CustomizationWizardForm extends EasyFormWizard
{
	public $m_FormName;
	public $m_ModuleName;
	
	public function fetchData()
	{
		$result = parent::fetchData();
		$fileOption = $this->getViewObject()->getFileOption();
		$this->m_FormName = $fileOption['form_name'];
		$this->m_ModuleName = $fileOption['module'];
		return $result;
	}

}
?>