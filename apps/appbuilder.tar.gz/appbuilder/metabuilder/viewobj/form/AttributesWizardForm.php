<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.viewobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class AttributesWizardForm extends EasyFormWizard
{
	public $m_ViewName;
	public $m_ModuleName;
	
	public function fetchData()
	{
		$result = parent::fetchData();
		$fileOption = $this->getViewObject()->getFileOption();
		$this->m_ViewName = $fileOption['view_name'];
		$this->m_ModuleName = $fileOption['module'];
		return $result;
	}

	public function goSkipNext($commit=false)
	{		
        // call ValidateForm()
        $recArr = $this->readInputRecord();
        $this->setActiveRecord($recArr);
    	
   		 try
        {
             if ($this->ValidateForm() == false)
            return;
        }catch (ValidationException $e)
        {
            $this->processFormObjError($e->m_Errors);
            return;
        }

        $this->m_ActiveRecord = $this->readInputRecord();
		$viewObj = $this->getViewObject();
        // get the step
    	if($viewObj->getCurrentStep()){
        	$step = $viewObj->getCurrentStep();
        }else{
        	$step = $_GET['step'];
        }
        if (!$step || $step=="")
            $step=1;

        // redirect the prev step
        /* @var $viewObj EasyViewWizard */
        
        $viewObj->renderStep($step+2);
	}		
	
	public function getDefaultDesc()
	{
		$fileOption = $this->getViewObject()->getFileOption();
		$fileOption['view_name'] = str_replace("View","",$fileOption['view_name']);
		$desc = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $fileOption['view_name']));
		return $desc;
	}
}
?>