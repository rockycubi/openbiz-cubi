<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.viewobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FileCreationWizardForm extends EasyFormWizard
{
	public $m_FileOptions;
	public $m_GeneratedXMLFile;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "FileOptions", $this->m_FileOptions);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "FileOptions", $this->m_FileOptions);     
    }

	public function goNext($commit=false)
	{		
	    try
        {
            $this->ValidateForm();
        }
        catch (ValidationException $e)
        {
            $this->processFormObjError($e->m_Errors);
            return;
        }
        
		$rec = $this->readInputRecord();
		$this->m_FileOptions = $rec;
		parent::goNext(false);
	}	   

	public function doFinish($commit=false)
	{
	    $viewObj 	 = $this->getViewObject();
	    $fileOption  = $this->readInputRecord();	    
	    $attributes	 = array();
	    $customization	= array();
	    $formReferences = array();
	    
		//generate the file	    	    
	    $svcObj = BizSystem::getService("appbuilder.metabuilder.viewobj.lib.ViewobjBuilderService");
	    $svcObj->setFileOption($fileOption);
	    $svcObj->setAttributes($attributes);
	    $svcObj->setCustomization($customization);
	    $svcObj->setFormReference($formReferences);
	    $svcObj->generate();
	    	    
		if(substr($fileOption['folder'],strlen($fileOption['folder'])-1,1)=='/')
		{
			$fileOption['folder'] = substr($fileOption['folder'],0,strlen($fileOption['folder'])-1);
		}
	    $this->m_GeneratedXMLFile = str_replace("/",".",$fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['view_name']) ;
	    
	   	// call ValidateForm()
        $recArr = $this->readInputRecord();
        $this->setActiveRecord($recArr);
    	$this->setFormInputs($this->m_FormInputs);
    	
        $this->m_ActiveRecord = $this->readInputRecord();
		
        /* @var $viewObj EasyViewWizard */
        $viewObj = $this->getViewObject();
        
        $r = $viewObj->commit();        
        if (!$r)
            return;

        $this->processPostAction();
	}
	
	protected function validateForm($cleanError = true)
	{
		$result = parent::validateForm($clearError);
		if(!$result)
		{
			return $result;
		}
		$rec = $this->readInputRecord();
		
		//test path exists
		$module = $rec['module'];
		$folder = $rec['folder'];
		$filename = $rec['view_name'];
		$path = MODULE_PATH.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR.$folder;
		if(is_dir($path))
		{
			//test if xml file exists
			$file = $path.DIRECTORY_SEPARATOR.$filename.'.xml';
			if(is_file($file))
			{
				$this->m_ValidateErrors['fld_file_name'] = $this->getMessage('TARGET_FILE_EXISTS');
			}
			
			//test if php file exists
			$file = $path.DIRECTORY_SEPARATOR.$filename.'.php';
			if(is_file($file))
			{
				$this->m_ValidateErrors['fld_file_name'] = $this->getMessage('TARGET_FILE_EXISTS');
			}
		}
		
		if (count($this->m_ValidateErrors) > 0)
        {
            throw new ValidationException($this->m_ValidateErrors);
            return false;
        }
        return true;
	}
}
?>