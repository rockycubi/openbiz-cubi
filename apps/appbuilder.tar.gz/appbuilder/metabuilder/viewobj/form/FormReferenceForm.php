<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.viewobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FormReferenceForm extends EasyFormWizard
{
	public $m_ViewName;
	public $m_ParentFormName = "appbuilder.metabuilder.viewobj.form.FormReferenceWizardForm";
	
	public function fetchData()
	{		
		$fileOption = $this->getViewObject()->getFileOption();
		$this->m_ViewName = $fileOption['view_name'];
		
		$prtForm = BizSystem::getObject($this->m_ParentFormName);
		
        if (strtoupper($this->m_FormType) == "NEW")
        {        	
            $result =  $this->getNewRecord();
        }
        else
        {        	           					
			$recordId = $this->m_RecordId;		
			$recordSet = $prtForm->getRecordList();			
			if(is_array($recordSet))
			{
				foreach($recordSet as $key=>$data)
				{
					if($data['Id']==$recordId)
					{
						$result = $data;
						break;
					}
				}
			}
			BizSystem::getObject("appbuilder.attredit.widget.SubformEditableListWidgetForm")->m_SubFormArray = $result['SubFormArray'];;	
        }
		return $result;
	}
	
	public function updateRecord()
	{
		//validate the value exists or not
		$rec = $this->readInputRecord();
        $currentRec = $this->fetchData();		

        $valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
				
		if(is_array($valueSetData) && $currentRec['Name']!=$rec['Name'] ){
			foreach($valueSetData as $key=>$data)
			{
				if(strtolower($data['Name'])==strtolower($rec['Name']))
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_form_name" => $this->getMessage("FORM_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}
		
		//save value
		$rec['Id'] 		= $rec['Name'];
		$prtForm = BizSystem::getObject($this->m_ParentFormName);		
		$prtForm->updateFormReferenceRecord($rec,$currentRec['Id']);

		$this->m_ActiveRecord = null;
		$this->processPostAction();
		return $result;		
	}
	
	public function insertRecord()
	{
		//validate the value exists or not
		$rec = $this->readInputRecord();
		$valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
		if(is_array($valueSetData)){
			foreach($valueSetData as $key=>$data)
			{
				if(strtolower($data['Name'])==strtolower($rec['Name']))
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_form_name" => $this->getMessage("FORM_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}

		
		
		//save value
		$rec['Id'] 		 = $rec['Name'];		
		$prtForm = BizSystem::getObject($this->m_ParentFormName);				
		$prtForm->addFormReferenceRecord($rec);

		$this->m_ActiveRecord = null;
		$this->processPostAction();
		return $result;
	}
	
	   	
}
?>