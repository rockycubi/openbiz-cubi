<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.viewobj.widget
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ViewobjLeftWidget extends EasyForm
{
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$result['FileOption'] = $this->getViewObject()->getFileOption();
		$result['Attributes'] = $this->getViewObject()->getAttributes();
		if($result['Attributes']['Class']=='CustomClass')
		{
			$result['Attributes']['Class']=$result['FileOption']['view_name'];
		}
		return $result;
	}
	
} 
?>