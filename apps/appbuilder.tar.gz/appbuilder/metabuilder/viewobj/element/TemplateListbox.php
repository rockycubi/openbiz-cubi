<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.viewobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class TemplateListbox extends Listbox
{
	protected $m_ModuleRootFolder;	
	protected $m_TemplateFolder = 'template';
	
	public function getFromList(&$list, $selectFrom=null)
	{
		$fileOption = $this->getFormObj()->getViewObject()->getFileOption();
		$module = $fileOption['module'];
		$folder = $fileOption['folder'];

		$rootFolder = MODULE_PATH.DIRECTORY_SEPARATOR.$module;
		$currentFolder = $rootFolder.DIRECTORY_SEPARATOR.$folder;
		
		if(substr($currentFolder,strlen($currentFolder)-1,1)=='/')
		{
			$currentFolder = substr($currentFolder,0,strlen($currentFolder)-1);
		}
		
		$this->m_ModuleRootFolder = $rootFolder;
		$files = $this->getTemplateFiles($currentFolder);
		
		foreach($files as $key=>$value)
		{
			$list[] = array(
				'val'	=>	$key,
				'txt'	=>	$value	
			);			
		}
		
	}
	
	protected function getTemplateFiles($dir)
	{
		if( $dir!=$this->m_ModuleRootFolder )
		{
			return $this->getTemplateFiles(dirname($dir));
		}
		$currentDir = $dir.DIRECTORY_SEPARATOR.$this->m_TemplateFolder;
		if(is_dir($currentDir)){
			foreach(glob($currentDir.'/*') as $file)
			{
				$files[basename($file)] = str_replace($this->m_ModuleRootFolder,"",$file);
			}
		}
		return $files;
	}
}
?>