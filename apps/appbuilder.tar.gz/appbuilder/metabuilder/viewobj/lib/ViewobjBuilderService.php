<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.viewobj.lib
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ViewobjBuilderService extends MetaObject
{
	protected $m_FileOption;
	protected $m_Attribtues;
	protected $m_Customization;
	protected $m_FormReference;
	
	public function setFileOption($fileOption)
	{
		$this->m_FileOption	=	$fileOption;
		return $this;
	}

	public function setAttributes($attributes)
	{
		$this->m_Attribtues	=	$attributes;
		return $this;
	}

	public function setCustomization($customization)
	{
		$this->m_Customization	=	$customization;
		return $this;
	}	
	
	public function setFormReference($reference)
	{
		$this->m_FormReference	=	$reference;
		return $this;
	}	
	
	public function generate()
	{
		//test folder exists
		$module 	= $this->m_FileOption['module'];
		$folder 	= $this->m_FileOption['folder'];
		$filename 	= $this->m_FileOption['view_name'];
		$folderPath = MODULE_PATH.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR.$folder.DIRECTORY_SEPARATOR;
		if(!is_dir($folderPath))
		{
			@mkdir($folderPath,0777,TRUE);
		}
		
		//generate fileOption package
		$this->m_FileOption['package'] = $module.'.'.str_replace('/','.',$folder);
		if(substr($this->m_FileOption['package'],strlen($this->m_FileOption['package'])-1,1)=='.')
		{
			$this->m_FileOption['package'] = substr($this->m_FileOption['package'],	0,	strlen($this->m_FileOption['package'])-1);
		}
		
			
		//setup default value
		if($this->m_Attribtues['Class'] == '')
		{
			$this->m_Attribtues['Class'] 		= 'EasyView';
			$this->m_Attribtues['Description'] 	= 'Default View';
			$this->m_Attribtues['TemplateEngine'] 	= 'Smarty';
			$this->m_Attribtues['TemplateFile'] 	= 'view.tpl';
		}		
		
		//process values
		$this->m_Attribtues['ClassOrg'] = $this->m_Attribtues['Class'];
		if($this->m_Attribtues['Class'] =='CustomClass')
		{
			$this->m_Attribtues['Class'] = $this->m_FileOption['view_name'];
		}
		$this->m_Attribtues['CacheLifeTime'] = (int)$this->m_Attribtues['CacheLifeTime'];		

		
		
		//generate XML file
		$smarty = BizSystem::getSmartyTemplate();            
		$smarty->assign("fileOption", $this->m_FileOption);    
        $smarty->assign("attributes", $this->m_Attribtues);
        $smarty->assign("customization", $this->m_Customization);
        $smarty->assign("formReference", $this->m_FormReference);
		$templateFile = $this->__getMetaTempPath().'/view/ViewObject.xml.tpl';		
        $content = $smarty->fetch($templateFile);                        
        $targetFile = $folderPath.$filename.'.xml';
        file_put_contents($targetFile, $content);        
        
        if($this->m_Attribtues['ClassOrg']=='CustomClass')
        {
			//generate PHP file
			$smarty = BizSystem::getSmartyTemplate();            
			$smarty->assign("fileOption", $this->m_FileOption);    
	        $smarty->assign("attributes", $this->m_Attribtues);
	        $smarty->assign("customization", $this->m_Customization);
	        $smarty->assign("formReference", $this->m_FormReference);
			$templateFile = $this->__getMetaTempPath().'/view/ViewObject.php.tpl';		
	        $content = $smarty->fetch($templateFile);
	        $targetFile = $folderPath.$filename.'.php';
	        file_put_contents($targetFile, $content);        
        }
		//return file path
		return $targetFile;
	}
	
	private function __getMetaTempPath()
	{
		$this->m_MetaTempPath = MODULE_PATH.DIRECTORY_SEPARATOR.'appbuilder'.
											DIRECTORY_SEPARATOR.'resource'.
											DIRECTORY_SEPARATOR.'module_template';
		return $this->m_MetaTempPath; 
	}	
}
?>