<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.service.lib
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class SvcBuilderService extends MetaObject
{
	protected $m_FileOption;
	protected $m_ConfigAttrs;
	
	public function setFileOption($fileOption)
	{
		$this->m_FileOption	=	$fileOption;
		return $this;
	}

	public function setConfigAttrs($configAttrs)
	{
		$this->m_ConfigAttrs	=	$configAttrs;
		return $this;
	}

	public function generate()
	{
		//test folder exists
		$module 	= $this->m_FileOption['module'];
		$folder 	= $this->m_FileOption['folder'];
		$filename 	= $this->m_FileOption['service_name'];
		$folderPath = MODULE_PATH.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR.$folder.DIRECTORY_SEPARATOR;
		if(!is_dir($folderPath))
		{
			@mkdir($folderPath,0777,TRUE);
		}
		
		//generate fileOption package
		$this->m_FileOption['package'] = $module.'.'.str_replace('/','.',$folder);
		if(substr($this->m_FileOption['package'],strlen($this->m_FileOption['package'])-1,1)=='.')
		{
			$this->m_FileOption['package'] = substr($this->m_FileOption['package'],	0,	strlen($this->m_FileOption['package'])-1);
		}
		
		//generate XML file
		$smarty = BizSystem::getSmartyTemplate();            
		$smarty->assign("fileOption", $this->m_FileOption);    
        $smarty->assign("configAttrs", $this->m_ConfigAttrs);
		$templateFile = $this->__getMetaTempPath().'/lib/PluginService.xml.tpl';		
        $content = $smarty->fetch($templateFile);                        
        $targetFile = $folderPath.$filename.'.xml';
        file_put_contents($targetFile, $content);        
        
		//generate PHP file
		$smarty = BizSystem::getSmartyTemplate();            
		$smarty->assign("fileOption", $this->m_FileOption);    
        $smarty->assign("configAttrs", $this->m_ConfigAttrs);
		$templateFile = $this->__getMetaTempPath().'/lib/PluginService.php.tpl';		
        $content = $smarty->fetch($templateFile);
        $targetFile = $folderPath.$filename.'.php';
        file_put_contents($targetFile, $content);        
        
		//return file path
		return $targetFile;
	}
	
	private function __getMetaTempPath()
	{
		$this->m_MetaTempPath = MODULE_PATH.DIRECTORY_SEPARATOR.'appbuilder'.
											DIRECTORY_SEPARATOR.'resource'.
											DIRECTORY_SEPARATOR.'module_template';
		return $this->m_MetaTempPath; 
	}	
}
?>