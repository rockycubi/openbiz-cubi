<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.service.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ConfigAttrsWizardForm extends EasyFormWizard
{
	public $m_ConfigAttrs;
		
	
	public $m_TotalRecords;
	public function runSearch()
    {
        include_once(OPENBIZ_BIN."/easy/SearchHelper.php");
        $searchRule = "";
        foreach ($this->m_SearchPanel as $element)
        {
            $searchStr = '';
        	if(method_exists($element,"getSearchRule")){
        		$searchStr = $element->getSearchRule();        		
        	}else{        	
	            if (!$element->m_FieldName)
	                continue;
	
	            $value = BizSystem::clientProxy()->getFormInputs($element->m_Name);     	                   
	            if($element->m_FuzzySearch=="Y")
	            {
	                $value="*$value*";
	            }
	            if ($value!='')
	            {
	                $searchStr = inputValToRule($element->m_FieldName, $value, $this);	  
	                $values[] = $value; 	                           
	            }
        	}
        	if($searchStr){
        		if ($searchRule == "")
                    $searchRule .= $searchStr;
                else
                    $searchRule .= " AND " . $searchStr;
        	}        	        	
        }
        $this->m_SearchRule = $searchRule;
        $this->m_SearchRuleBindValues = $values;

        $this->m_RefreshData = true;

        $this->m_CurrentPage = 1;

        BizSystem::log(LOG_DEBUG,"FORMOBJ",$this->m_Name."::runSearch(), SearchRule=".$this->m_SearchRule);

		$recArr = $this->readInputRecord();		
		
		$this->m_SearchPanelValues = $recArr;
		
        
        $this->runEventLog();
        $this->rerender();
    }	
	
	public function fetchDataSet()
	{				
		//init variables
		$resultRaw = $this->getRecordList();
		
		if(!is_array($resultRaw))
		{
			return array();
		}
		
		$searchRule = $this->m_SearchRule;		
		
		preg_match_all("/\[(.*?)\]/si", $searchRule,$match);	
		$i=0;		
		$searchFilter = array();
		if(is_array($this->m_SearchRuleBindValues))
		{
			foreach( $this->m_SearchRuleBindValues as $key=>$value)
			{
				$fieldName = $match[1][$i];
				$fieldValue = $value;
				$i++;
				$searchFilter[$fieldName]=$fieldValue;
			}		
		}
		if(count($searchFilter))
		{
			
			foreach($resultRaw as $record)
			{				
				$testField = false;
				foreach($searchFilter as $field=>$value)
				{					
					if($record[$field]!=$value){
						$testField =true;
						break;
					}
				}
				if(!$testField)
				{
					$result[] = $record; 
				}
			}
		}
		else
		{
			$result=$resultRaw;
		}
		
    	//set default selected record
		if(!$this->m_RecordId){
				$this->m_RecordId=$result[0]["Name"];
		}
		//set paging 
		$this->m_TotalRecords = count($result);
			
        if ($this->m_Range && $this->m_Range > 0)
            $this->m_TotalPages = ceil($this->m_TotalRecords/$this->m_Range);
		
        if($this->m_CurrentPage > $this->m_TotalPages)
        {
        	$this->m_CurrentPage = $this->m_TotalPages;
        }
            
        if(is_array($result)){
			$result = array_slice($result,($this->m_CurrentPage-1)*$this->m_Range,$this->m_Range);
		}	    
            
    	return $result;
	}		
	
	public function getRecordList()
	{
		return $this->m_ConfigAttrs;		
	}
	
	public function deleteRecord($id=null)
	{
		if ($id==null || $id=='')
            $id = BizSystem::clientProxy()->getFormInputs('_selectedId');

        $selIds = BizSystem::clientProxy()->getFormInputs('row_selections', false);
        if ($selIds == null)
            $selIds[] = $id;
        foreach ($selIds as $id)
        {        	
            if(is_array($this->m_ConfigAttrs))
            {
            	foreach($this->m_ConfigAttrs as $key=>$value)
            	{
            		if($value['Id']==$id)
            		{
            			$deleteKeys[]=$key;	
            		}
            	}
            }
        }
        if(is_array($deleteKeys))
        {
        	foreach($deleteKeys as $key)
        	{
        		unset($this->m_ConfigAttrs[$key]);
        	}
        }
        
        if (strtoupper($this->m_FormType) == "LIST")
            $this->rerender();

        $this->runEventLog();
        $this->processPostAction();
	}
	
	public function loadDialog($formName, $id=null,$transId=false)
    {
    	$paramFields = array();   
    	if($id==null)
    	{     
        	$paramFields["Id"] = $this->m_RecordId;
    	}else{
    		$paramFields["Id"] = $id;
    	}
        if ($transId!=false)
            $paramFields["Id"] = $this->m_RecordId;
        $this->_showForm($formName, "Dialog", $paramFields);
    }
	
	public function addConfigAttrRecord($rec)
	{
		$this->m_ConfigAttrs[] = $rec;
		return $this->m_ConfigAttrs;
	}
	
	public function updateConfigAttrRecord($rec,$Id)
	{
		if(is_array($this->m_ConfigAttrs))
		{
			foreach ($this->m_ConfigAttrs as $key=>$data)
			{
				if($data['Id']==$Id)
				{					
					$this->m_ConfigAttrs[$key]=$rec;
					return $this->m_ConfigAttrs;
				}
			}
		}
	}
	
	public function goNext($commit=false)
	{		
	    $fileOption  = $this->getViewObject()->getFileOption();
	    $configAttrs = $this->m_ConfigAttrs;
	    
		//generate the file	    	    
	    $svcObj = BizSystem::getService("appbuilder.metabuilder.service.lib.SvcBuilderService");
	    $svcObj->setFileOption($fileOption);
	    $svcObj->setConfigAttrs($configAttrs);
	    $svcObj->generate();
	    	    	    
		parent::goNext(false);
	}	
	
	public function clearConfigAttrs()
	{
		$this->m_ConfigAttrs = null;
		BizSystem::sessionContext()->setObjVar($this->m_Name, "ConfigAttrs",$this->m_ConfigAttrs, true);
	}
	
	public function cancel()
	{
		$this->clearConfigAttrs();
		return parent::cancel();
	}
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "ConfigAttrs", $this->m_ConfigAttrs);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "ConfigAttrs", $this->m_ConfigAttrs);     
    }		
}
?>