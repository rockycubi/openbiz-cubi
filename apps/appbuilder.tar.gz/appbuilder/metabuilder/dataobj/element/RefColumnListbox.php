<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class RefColumnListbox extends Listbox
{	
	protected $m_SQL = "SHOW COLUMNS FROM `%s`;";
	
	public function getFromList(&$list, $selectFrom=null)
	{	

		$db = $this->_getDBConn();
		if(!$db)
		{
			return ;
		}
    	$table = $this->_getTableName();
		try
    	{
    		$sql = sprintf($this->m_SQL,$table);
    		$columnList = $db->fetchAll($sql);
    		foreach($columnList as $colmnInfo)
	    	{
	    		$result[] = $colmnInfo;
	    	}
    	}
    	catch(Exception $e){	    	
	    	$result[] = $colmnInfo;	    	
    	}
    	
		foreach($result as $column)
		{	
			$list[] = array(
				'val'	=>	$column[0],
				'txt'	=>	$column[0].' - '.$column[1].''
			);			
		}
		
	}

	protected function _getTableName()
	{
	
		$tableElem = $this->getFormObj()->getElement("fld_table");
		if($tableElem)
		{
			$table = $tableElem->getValue();
		}
		return $table;
		
	}
	
    protected function _getDBConn()
    {
    	$secDOName = $this->getFormObj()->getElement("fld_name")->getValue();    
    	if(!$secDOName)
    	{
    		return ;
    	}	
		$secDO = BizSystem::getObject($secDOName);
		$dbName = $secDO->m_Database;
    	return $db = BizSystem::instance()->getDBConnection($dbName);
    }	
	
    public function Render()
    {
    	$this->m_Label = Expression::evaluateExpression($this->m_Label, $this->getFormObj());
    	$this->m_Description = Expression::evaluateExpression($this->m_Description, $this->getFormObj());
    	return parent::render();
    }
}
?>