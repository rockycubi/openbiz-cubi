<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class RefXTableListbox extends Listbox
{	
	
	public function getFromList(&$list, $selectFrom=null)
	{	
	
		$secDOName = $this->getFormObj()->getElement("fld_xdataobj")->getValue();
		if(!$secDOName)
		{
			return;
		}
		$secDO = BizSystem::getObject($secDOName);
		$dbName = $secDO->m_Database;
		$defaultTable = $secDO->m_MainTable;
		$db = BizSystem::instance()->getDBConnection($dbName);
		$this->m_DefaultValue = $defaultTable;
		$this->m_Value = $defaultTable;
		
		$tableList = $db->fetchAll("SHOW FULL TABLES");
		
		foreach($tableList as $table)
		{	
			$list[] = array(
				'val'	=>	$table[0],
				'txt'	=>	$table[0]
			);			
		}
				
	}

	
}
?>