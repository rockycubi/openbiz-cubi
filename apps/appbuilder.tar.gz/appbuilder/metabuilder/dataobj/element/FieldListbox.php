<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FieldListbox extends Listbox
{	
	protected $m_SQL = "SHOW COLUMNS FROM `%s`;";
	
	public function getFromList(&$list, $selectFrom=null)
	{	

		$fieldList = $this->getFormObj()->getViewObject()->getFieldList();
		
		foreach($fieldList as $field)
		{	
			$list[] = array(
				'val'	=>	$field['Name'],
				'txt'	=>	$field['Name'].' - '.$field['Column'].''
			);			
		}
		
	}

}
?>