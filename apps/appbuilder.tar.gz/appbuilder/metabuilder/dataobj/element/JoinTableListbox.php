<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class JoinTableListbox extends Listbox
{	
	
	public function getFromList(&$list, $selectFrom=null)
	{	

		$joinTable = $this->getFormObj()->getViewObject()->getJoinTable();
		$attrs = $this->getFormObj()->getViewObject()->getAttributes();
		$tableName = $attrs['Table'];
		
		foreach($joinTable as $join)
		{	
			$list[] = array(
				'val'	=>	$join['Name'],
				'txt'	=>	$join['Name'].' - '.$join['Table'].''
			);			
		}
		
		$this->m_BlankOption .= " - ".$tableName;
		
	}

	
}
?>