<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ColumnListbox extends Listbox
{	
	protected $m_SQL = "SHOW COLUMNS FROM `%s`;";
	
	public function getFromList(&$list, $selectFrom=null)
	{	

		$db = $this->_getDBConn();
    	$table = $this->_getTableName();
		try
    	{
    		$sql = sprintf($this->m_SQL,$table);
    		$columnList = $db->fetchAll($sql);
    		foreach($columnList as $colmnInfo)
	    	{
	    		$result[] = $colmnInfo;
	    	}
    	}
    	catch(Exception $e){	    	
	    	$result[] = $colmnInfo;	    	
    	}
    	
		foreach($result as $column)
		{	
			$list[] = array(
				'val'	=>	$column[0],
				'txt'	=>	$column[0].' - '.$column[1].''
			);			
		}
		
	}

	protected function _getTableName()
	{
		$attrs = $this->getFormObj()->getViewObject()->getAttributes();
		$table = $attrs['Table'];
		$joinTable = $this->getFormObj()->getElement("fld_join");
		if($joinTable && $joinTable->getValue() && is_array($this->getFormObj()->getViewObject()->getJoinTable()))
		{
			$table = $joinTable->getValue();			
		
			$joinTable = $this->getFormObj()->getViewObject()->getJoinTable();
			foreach($joinTable as $join)
			{
				if($join['Name']==$table)
				{
					$table = $join['Table'];
					break;
				}
			}	

		}		
		return $table;
		
	}
	
    protected function _getDBConn()
    {
    	$attrs = $this->getFormObj()->getViewObject()->getAttributes();
    	$dbName = $attrs['DBName'];
    	return $db = BizSystem::instance()->getDBConnection($dbName);
    }	
	
}
?>