<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

require_once 'ColumnListbox.php';

class JoinColumnRefListbox extends ColumnListbox
{	

	protected function _getTableName()
	{
		$attrs = $this->getFormObj()->getViewObject()->getAttributes();
		$table = $attrs['Table'];
		
		$joinTable = $this->getFormObj()->getElement("fld_join_ref");
		if($joinTable && $joinTable->getValue())
		{
			$table = $joinTable->getValue();
			$joinTable = $this->getFormObj()->getViewObject()->getJoinTable();
			foreach($joinTable as $join)
			{
				if($join['Name']==$table)
				{
					$table = $join['Table'];
					break;
				}
			}			
		}
		
		return $table;
		
	}

}
?>