<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.linker
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ConfigSecondaryWizardForm extends EasyFormWizard
{
	public $m_SecondaryModule;
	public $m_DefaultDisplayName;
	
	public $m_Relationship;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "SecondaryModule", $this->m_SecondaryModule);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "SecondaryModule", $this->m_SecondaryModule);     
    }
    
    /**
     * 
     * get default value for field creation element
     * return 1 means need create a new field for FK
     * return 0 means detected default FK field
     * @return bool
     */
    public function getDefaultFieldCreation()
    {    	
    	$do = $this->m_DataPanel->get('fld_do')->getValue();
    	if(!$do){
    		return 1;
    	}
    	
    	$fk_name = $this->getDefaultFKName();
    	$do = str_replace("/",".",$do);
    	$do = str_replace(".xml","",$do);
    	$do = BizSystem::getObject($do);
    	$fieldObj = $do->getFieldNameByColumn($fk_name);
    	if($fieldObj)
    	{
    		return 0;
    	}
    	else
    	{
    		return 1;
    	}
    }
    
    public function setActiveRecord($record)
    {
    	return parent::setActiveRecord($record);
    }
    
    public function getDefaultDisplayName()
    {
    	$displayName = $this->m_DataPanel->get('fld_do')->getValue();
    	$displayName = str_replace(".xml", "", $displayName);
    	$nameArr = explode("/", $displayName);
    	$displayName = $nameArr[count($nameArr)-1];
    	$displayName = str_replace("DO", "", $displayName);
    	$this->m_DefaultDisplayName = $displayName;
    	return $displayName;
    }

    
    public function getDefaultFKName()
    {
    	$priModule = $this->getViewObject()->getPrimaryModule();
    	$priDO = $priModule['primary_do'];
    	$priDO = str_replace(".xml", "", $priDO);
    	$nameArr = explode("/", $priDO);
    	$priDO = $nameArr[count($nameArr)-1];
    	$priDO = str_replace("DO", "", $priDO);
    	$priDO = strtolower($priDO);
    	$fkName = $priDO."_id";
    	return $fkName;
    }
    
    protected function getFormDOName($form)
    {
    	$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$form);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		return $xml->documentElement->attributes->getNamedItem("BizDataObj")->nodeValue;    	
    } 
       
    private function __getObjName($obj_file)
	{
		$obj_name = str_replace(".xml", "", $obj_file);
		$obj_name = str_replace("/", ".", $obj_name);
		return $obj_name;
	}
	
	public function getDefaultListWidget()
    {
		$module = $this->m_DataPanel->get('fld_module_name')->getValue();
		$do =  $this->m_DataPanel->get('fld_do')->getValue();  
		$do = $this->__getObjName($do); 	
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);    	
    	foreach($formList as $form)
    	{
    		$formDO = $this->getFormDOName($form);
    		if(preg_match('/ListWidget/si',$form) && $formDO == $do)
    		{
    			
    			return $form;
    		}	
    	}
    	return '';
    }
    
    public function getDefaultEditableWidget()
    {
    	$module = $this->m_DataPanel->get('fld_module_name')->getValue();   
    	$do =  $this->m_DataPanel->get('fld_do')->getValue(); 
    	$do = $this->__getObjName($do);	
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);    	
    	foreach($formList as $form)
    	{
    		$formDO = $this->getFormDOName($form);
    		if(preg_match('/ListEditableWidget/si',$form) && $formDO == $do)
    		{
    			return $form;
    		}	
    	}    	
    	return '';
    }    
    
    public function fetchData()
    {
    	$this->m_Relationship =	$this->getViewObject()->getRelationship();   
    	$result = parent::fetchData();    	
    	$this->m_DefaultDisplayName = $this->getDefaultDisplayName();		
 		if( $result['secondary_do_key_display'] == $this->m_DefaultDisplayName )
 		{
 			$result['secondary_do_key_display'] = "";
 		}
    	return $result;        
    }
    
	public function goNext($commit=false)
	{
		$rec = $this->readInputRecord();
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
		//check if both DO are using same DBConnection
		$priModArr = $this->getViewObject()->getPrimaryModule();
		$priDO = $priModArr['primary_do'];
		$priDoInfo = $svc->getDataObjectInfo($priDO);
		$priDoDBConn = $priDoInfo['DBNAME'];
		if(!$priDoDBConn){$priDoDBConn='Default';}
				
		$secDO = $rec['secondary_do'];
		$secDoInfo = $svc->getDataObjectInfo($secDO);
		$secDoDBConn = $secDoInfo['DBNAME'];		
		if(!$secDoDBConn){$secDoDBConn='Default';}
		
		
		if($secDoDBConn != $priDoDBConn ){
    		$msg = $this->getMessage("MSG_DBCONN_NOT_MATCH");
        	$errors = array(
        		"fld_do"=>$msg
        	);
        	$this->processFormObjError($errors);
        	return;
		}
		
		if($priDO == $secDO)
		{
			$msg = $this->getMessage("MSG_DO_CANNOT_SAME");
        	$errors = array(
        		"fld_do"=>$msg
        	);
        	$this->processFormObjError($errors);
        	return;
		}
		
		switch($this->m_Relationship)
		{
			case "MtoM":	
		        if($rec['secondary_do_key_field']=="")
		        {
		        		$msg = $this->getMessage("MSG_PLEASE_SELECT_PK_FIELDS");
			        	$errors = array(
			        		"fld_pk_field"=>$msg
			        	);
			        	$this->processFormObjError($errors);
			        	return;
		        }
		    	break;
		    	
			case "1toM":
				switch($rec['fld_fk_creation'])
				{
					case "0":	//use existing field
						if($rec['secondary_do_fk_field_exists']=="")
				        {
				        		$msg = $this->getMessage("MSG_PLEASE_SELECT_FK_FIELDS");
					        	$errors = array(
					        		"fld_fk_field_exists"=>$msg
					        	);
					        	$this->processFormObjError($errors);
					        	return;
				        }
						break;
					case "1":	//create new field
						if($rec['secondary_do_fk_field_create']=="")
				        {
				        		$msg = $this->getMessage("MSG_PLEASE_SELECT_FK_FIELDS");
					        	$errors = array(
					        		"fld_fk_field_create"=>$msg
					        	);
					        	$this->processFormObjError($errors);
					        	return;
				        }
						break;
				}				
		    	break;
        }  
        $this->m_SecondaryModule = $rec;
		parent::goNext(false); 
	}
}
?>