<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.linker
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class BuildCompletedWizardForm extends EasyFormWizard
{
	public $m_DataObjFiles = array();
	public $m_FormObjFiles = array();
	public $m_ViewObjFiles = array();
	public $m_MessageFiles = array();
	public $m_TemplateFiles = array();
	public $m_ModXMLFile ;

	public $m_PrimaryModule;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "DataObjFiles", 	$this->m_DataObjFiles);
        $sessionContext->getObjVar($this->m_Name, "FormObjFiles", 	$this->m_FormObjFiles);
        $sessionContext->getObjVar($this->m_Name, "ViewObjFiles", 	$this->m_ViewObjFiles);
        $sessionContext->getObjVar($this->m_Name, "MessageFiles", 	$this->m_MessageFiles);
        $sessionContext->getObjVar($this->m_Name, "TemplateFiles", 	$this->m_TemplateFiles);
        $sessionContext->getObjVar($this->m_Name, "ModXMLFile", 	$this->m_ModXMLFile);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "DataObjFiles", 	$this->m_DataObjFiles); 
        $sessionContext->setObjVar($this->m_Name, "FormObjFiles", 	$this->m_FormObjFiles);
        $sessionContext->setObjVar($this->m_Name, "ViewObjFiles", 	$this->m_ViewObjFiles);
        $sessionContext->setObjVar($this->m_Name, "MessageFiles", 	$this->m_MessageFiles);
        $sessionContext->setObjVar($this->m_Name, "TemplateFiles", 	$this->m_TemplateFiles);
        $sessionContext->setObjVar($this->m_Name, "ModXMLFile", 	$this->m_ModXMLFile);            
    }	
    
    public function doFinish()
    {
    	$priModule =	$this->getViewObject()->getPrimaryModule();	    	    
		$this->m_ModuleName = $priModule['primary_module'];
    	return parent::doFinish();
    }
    
    public function fetchData()
    {
    	$result = parent::fetchData();
    	$priModule =	$this->getViewObject()->getPrimaryModule();	    	
		$this->m_PrimaryModule = $priModule['primary_module'];		
    	return $result;
    }    
    
	public function outputAttrs()
	{		
		$result = parent::outputAttrs();
		$result['DataObjFiles']	= $this->m_DataObjFiles;
		$result['FormObjFiles'] = $this->m_FormObjFiles;
		$result['ViewObjFiles'] = $this->m_ViewObjFiles;
		$result['MessageFiles'] = $this->m_MessageFiles;
		$result['TemplateFiles'] = $this->m_TemplateFiles;
		$result['ModFile'] 	= $this->m_ModXMLFile;
		$priModule = $this->getViewObject()->getPrimaryModule();
		$this->m_PrimaryModule = $priModule['primary_module'];		
		return $result;
	}
}
?>