<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.linker
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ConfigPrimaryWizardForm extends EasyFormWizard
{	
	public $m_PrimaryModule;
	public $m_DefaultDisplayName;
	
	public $m_Relationship;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "PrimaryModule", $this->m_PrimaryModule);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "PrimaryModule", $this->m_PrimaryModule);     
    }
    
    public function getDefaultDisplayName()
    {
    	$displayName = $this->m_DataPanel->get('fld_do')->getValue();
    	$displayName = str_replace(".xml", "", $displayName);
    	$nameArr = explode("/", $displayName);
    	$displayName = $nameArr[count($nameArr)-1];
    	$displayName = str_replace("DO", "", $displayName);
    	$this->m_DefaultDisplayName = $displayName;
    	return $displayName;
    }
    
    protected function getFormDOName($form)
    {
    	$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$form);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		return $xml->documentElement->attributes->getNamedItem("BizDataObj")->nodeValue;    	
    }    
    
    private function __getObjName($obj_file)
	{
		$obj_name = str_replace(".xml", "", $obj_file);
		$obj_name = str_replace("/", ".", $obj_name);
		return $obj_name;
	}
	
	public function getDefaultListWidget()
    {
		$module = $this->m_DataPanel->get('fld_module_name')->getValue();   
		$do =  $this->m_DataPanel->get('fld_do')->getValue(); 	
		$do = $this->__getObjName($do);
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);    	
    	foreach($formList as $form)
    	{
    		$formDO = $this->getFormDOName($form);
    		if(preg_match('/ListWidget/si',$form) && $formDO == $do)
    		{
    			return $form;
    		}	
    	}
    }
    
	public function getDefaultPickWidget()
    {
		$module = $this->m_DataPanel->get('fld_module_name')->getValue();    	
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);    	
    	foreach($formList as $form)
    	{
    		if(preg_match('/SinglePickWidget/si',$form))
    		{
    			return $form;
    		}	
    	}
    }
    
    public function getDefaultEditableWidget()
    {
    	$module = $this->m_DataPanel->get('fld_module_name')->getValue();    	
    	$do =  $this->m_DataPanel->get('fld_do')->getValue();
    	$do = $this->__getObjName($do);
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$formList = $svc->listFormObjects($module);    	
    	foreach($formList as $form)
    	{
    		$formDO = $this->getFormDOName($form);
    		if(preg_match('/ListEditableWidget/si',$form) && $formDO == $do)
    		{
    			return $form;
    		}	
    	}    	
    }
    
    public function fetchData()
    {
    	$this->m_Relationship =	$this->getViewObject()->getRelationship();  
    	$result = parent::fetchData();    	
    	$this->m_DefaultDisplayName = $this->getDefaultDisplayName();		
 		if( $result['primary_do_key_display'] == $this->m_DefaultDisplayName )
 		{
 			$result['primary_do_key_display'] = "";
 		}
    	return $result;   	
    }    
    
	public function goNext($commit=false)
	{
		$rec = $this->readInputRecord();        		
        if($rec['primary_do_key_field']=="")
        {
        		$msg = $this->getMessage("MSG_PLEASE_SELECT_PK_FIELDS");
	        	$errors = array(
	        		"fld_pk_field"=>$msg
	        	);
	        	$this->processFormObjError($errors);
        }else{
        		$this->m_PrimaryModule = $rec;
				parent::goNext(false);
        }
	}
}
?>