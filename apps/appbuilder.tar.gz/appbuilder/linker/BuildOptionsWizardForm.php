<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.linker
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class BuildOptionsWizardForm extends EasyFormWizard
{
	public $m_BuildOptions;
	public $m_Relationship;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "BuildOptions", $this->m_BuildOptions);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "BuildOptions", $this->m_BuildOptions);     
    }
	
	public function fetchData()    
	{    	            		
		$this->m_Relationship =	$this->getViewObject()->getRelationship();		
        return parent::fetchData();
    }	
	
    public function getIntermediateTableCreation()
    {
    	$tableName = $this->getIntermediateTableName();
    	$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$priModArr = $this->getViewObject()->getPrimaryModule();
    	$priDoInfo = $svc->getDataObjectInfo($priModArr['primary_do']);
		$priDoDBConn = $priDoInfo['DBNAME'];
		$db = BizSystem::dbConnection($priDoDBConn);				
    	$tblList = $db->listTables();
    	
        foreach ($tblList as $table)
        {
        	if($table == $tableName)
        	{
        		return 1;
        	}
        }
        return 0;
    }
	public function getIntermediateTableName()
	{		
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
		
		$priModArr = $this->getViewObject()->getPrimaryModule();
		$priDoInfo = $svc->getDataObjectInfo($priModArr['primary_do']);
		$priDoTable = $priDoInfo['TABLE'];
		
		$secModArr = $this->getViewObject()->getSecondaryModule();
		$secDoInfo = $svc->getDataObjectInfo($secModArr['secondary_do']);
		$secDoTable = $secDoInfo['TABLE'];

		$newTableName = $priDoTable."_".$secDoTable;
		return $newTableName;
	}

	public function goNext($commit=false)
	{		
		$rec = $this->readInputRecord();
		$this->m_BuildOptions = $rec;

		$svc = BizSystem::getService("appbuilder.lib.MetaLinkerService");
		$relationship	= $this->getViewObject()->getRelationship();
		$primaryModule	= $this->getViewObject()->getPrimaryModule();
		$secondaryModule= $this->getViewObject()->getSecondaryModule();		
		$buildOptions 	= $this->getViewObject()->getBuildOptions();
		
		$svc->setRelationship($relationship);
		$svc->setPrimaryModule($primaryModule);
		$svc->setSecondaryModule($secondaryModule);
		$svc->setBuildOptions($buildOptions);		
		$generatedFiles = $svc->generate();
				
		BizSystem::getObject("appbuilder.linker.BuildCompletedWizardForm")->m_DataObjFiles  = $generatedFiles['DataObjFiles'];
		BizSystem::getObject("appbuilder.linker.BuildCompletedWizardForm")->m_FormObjFiles  = $generatedFiles['FormObjFiles'];
		BizSystem::getObject("appbuilder.linker.BuildCompletedWizardForm")->m_ViewObjFiles  = $generatedFiles['ViewObjFiles'];
		BizSystem::getObject("appbuilder.linker.BuildCompletedWizardForm")->m_MessageFiles  = $generatedFiles['MessageFiles'];
		BizSystem::getObject("appbuilder.linker.BuildCompletedWizardForm")->m_TemplateFiles = $generatedFiles['TemplateFiles'];
		BizSystem::getObject("appbuilder.linker.BuildCompletedWizardForm")->m_ModXMLFile	 = $generatedFiles['ModXMLFile'];
		
		parent::goNext(false);
	}	
}
?>