<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.linker.widget
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class LinkerWidget extends EasyForm
{
   
	public function outputAttrs()
	{
		$result 					= parent::outputAttrs();
		$result['relationship'] 	= $this->getViewObject()->getRelationship();
		$result['primaryModule'] 	= $this->getViewObject()->getPrimaryModule();
		$result['secondaryModule'] 	= $this->getViewObject()->getSecondaryModule();		
		if($result['relationship']!="")
		{
			$result['relationship'] 	= $this->getMessage($result['relationship']);
		}
		return $result;		
	}
}
?>