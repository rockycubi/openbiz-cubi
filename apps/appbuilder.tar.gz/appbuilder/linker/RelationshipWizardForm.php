<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.linker
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class RelationshipWizardForm extends EasyFormWizard
{
	public $m_Relationship;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "Relationship", $this->m_Relationship);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "Relationship", $this->m_Relationship);     
    }
    
	public function goNext($commit=false)
	{
		$rec = $this->readInputRecord();        		
        if($rec['relationship']=="")
        {
        		$msg = $this->getMessage("MSG_PLEASE_SELECT_ORM_LOGIC");
	        	$errors = array(
	        		"fld_relationship"=>$msg
	        	);
	        	$this->processFormObjError($errors);
        }else{
        		$this->m_Relationship = $rec['relationship'];
				parent::goNext(false);
        }
	}	
}
?>