<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.lib
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class MetaLinkerService
{
	protected $m_Relationship;
	protected $m_PrimaryModule;
	protected $m_SecondaryModule;	
	protected $m_BuildOptions;	

	/* property for One to Many logic */
	protected $m_o2m_fkField;
	protected $m_o2m_fkDisplayField;
	
	/* property for Many to Many logic */
	protected $m_m2m_intermediate_table;
	protected $m_m2m_intermediate_pri_do;
	protected $m_m2m_intermediate_pri_do_fullname;
	protected $m_m2m_intermediate_sec_do;	
	protected $m_m2m_intermediate_sec_do_fullname;
	protected $m_m2m_primary_fk;
	protected $m_m2m_secondary_fk;
	
	public function setRelationship($relationship)
	{
		$this->m_Relationship	=	$relationship;
		return $this;
	}
	
	public function setPrimaryModule($primaryModule)
	{
		$this->m_PrimaryModule	=	$primaryModule;
		return $this;
	}
	
	public function setSecondaryModule($secondaryModule)
	{
		$this->m_SecondaryModule	=	$secondaryModule;
		return $this;
	}
	
	public function setBuildOptions($buildOptions)
	{
		$this->m_BuildOptions	=	$buildOptions;
		return $this;
	}		
	
	public function generate()
	{
		switch(strtolower($this->m_Relationship))
		{
			case "1tom":
				$this->_genOnetoMany();
				break;
				
			case "mtom":
				$this->_genManytoMany();
				break;
			
		}
		// for debug only		
		return $this->m_GeneratedFiles;
	}
	
	protected function _genOnetoMany()
	{
		//set some common variable
		$sec_do_file = $this->m_SecondaryModule['secondary_do'];
		$sec_do_name = $this->__getObjName($sec_do_file);

		//process fk field creation
		if($this->m_SecondaryModule['secondary_do_key_creation']==1)
		{			
			$fk_field = $this->m_SecondaryModule['secondary_do_fk_field_create'];
			$this->__createFK4DO($sec_do_file, $fk_field);
		}else{
			$fk_field = $this->m_SecondaryModule['secondary_do_fk_field_exists'];
		}
		$this->m_o2m_fkField = $fk_field;
		
		//modify DO files
		$this->_o2m_modifyDO();
				
		//modify detail form
		$this->_o2m_modifyPriDetailForm();		
		
		//generate assoc form for pri module
		$this->_o2m_genAssocForm();
		
		//modify sec module's detail create / edit / copy form
		$this->_o2m_modifySecDetailForm();
		$this->_o2m_modifySecNewForm();
		$this->_o2m_modifySecEditForm();
		$this->_o2m_modifySecCopyForm();
	}
	
	protected function _genManytoMany()
	{
		//generate intermediate table and object
		$this->_m2m_genIntermediateDO();
		
		//modify DO files
		$this->_m2m_modifyPriDO();
		$this->_m2m_modifySecDO();
				
		//generate assoc form
		$this->_m2m_genPriAssocForm();
		$this->_m2m_genSecAssocForm();
		
		//modify detail form
		$this->_m2m_modifyPriDetailForm();
		$this->_m2m_modifySecDetailForm();
	}
	
	/*private methods below - for internal call only*/
	protected function __createFK4DO($do_file,$fk_field)
	{
		if($this->m_BuildOptions['modify_secondary_data_object']==0)
		{
			return ;
		}
		//create field
		$do_name = $this->__getObjName($do_file);
		$obj = BizSystem::getObject($do_name);		
		$db = $obj->getDBConnection("write");
		
		$tableName = $obj->m_MainTable;
		$field_name = $fk_field;
		$field_type = "int(11)";
		$set_null = "NULL";
		$after_field = "id";
		$comment = "FK for ".$this->m_PrimaryModule['primary_do_key_display'];
		$modName = substr($do_name,0,strpos($do_name,"."));
		
		
		try{
		$sql = "ALTER TABLE `$tableName` DROP `$field_name`";
		$db->query($sql);
		$this->__modifyInstallSQL($sql, $modName);
		}catch(Exception $e){}
		
		$sql="ALTER TABLE `$tableName` ADD `$field_name` $field_type $set_null COMMENT '$comment' AFTER `$after_field`";
		$db->query($sql);
		$this->__modifyInstallSQL($sql, $modName);
		
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$do_file);
		//add new field meta to DO file 		
		//after id field	
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		//prepare new field obj
		$newField = $xml->createElement("BizField");
		$newField->setAttribute("Name", 		$field_name);
		$newField->setAttribute("Column", 		$field_name);
		$newField->setAttribute("Description",	$comment);
		$newField->setAttribute("Required",		"N");
		$newField->setAttribute("Type",			"Number");
		
		//check if exists then ignore
		foreach($xml->getElementsByTagName("BizField") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == $field_name)
			{
				return ;
			}
		}
		
		foreach($xml->getElementsByTagName("BizField") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == "Id")
			{
				$node->parentNode->insertBefore($newField,$node->nextSibling);
			}
		}
		
		file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$do_file, $xml->saveXML());	
		$this->m_GeneratedFiles['DataObjFiles']['SecondaryDO']=str_replace(MODULE_PATH,"",$do_file);	
	}
	
	/*One to Many logic methods below */
	protected function _o2m_modifyDO()
	{
		if($this->m_BuildOptions['modify_primary_data_object']==1)
		{
			//modify pri do adds an ORM 1-M
			$pri_do_file = $this->m_PrimaryModule['primary_do'];
			$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_do_file);
			
			$xml = new DOMDocument();		
			$xml->preserveWhiteSpace = false;
			$xml->formatOutput = true;
			$xml->loadXML($xmlStr);
					
			/*
			 *  prepare reference element
			 * <Object Name="changelog.do.ChangeLogDO" 
			 * 			Description="" 
			 * 			Relationship="1-M" 
			 * 			Table="changelog" 
			 * 			Column="foreign_id" 
			 * 			FieldRef="Id" />
			 */
			$do_name = $this->__getObjName($this->m_SecondaryModule['secondary_do']);
			$sec_do = BizSystem::getObject($do_name);
			$table = $sec_do->m_MainTable;		
			/*
			foreach($sec_do->m_BizRecord as $field)
			{
				if($field->m_Name == $this->m_o2m_fkField){
					$column = $field->m_Column;
					break;
				}
			}
			*/
			$column = $this->m_o2m_fkField;
			$comment = "Reference to ".$this->m_SecondaryModule['secondary_module'];
			$fieldRef = $this->m_PrimaryModule['primary_do_key_field'];		
			
			$newField = $xml->createElement("Object");
			$newField->setAttribute("Name", 		$do_name);
			$newField->setAttribute("Description",	$comment);
			$newField->setAttribute("Relationship", "1-M");
			$newField->setAttribute("Table",		$table);
			$newField->setAttribute("Column",		$column);
			$newField->setAttribute("FieldRef",		$fieldRef);
	
			//check if exists then ignore
			$nodeExists = false;
			foreach($xml->getElementsByTagName("Object") as $node)
			{
				if($node->attributes->getNamedItem("Name")->nodeValue == $do_name)
				{
					$nodeExists = true ;
					break;
				}
			}
			
			if(!$nodeExists)
			{
				foreach($xml->getElementsByTagName("ObjReferences") as $node)
				{			
					$node->appendChild($newField);	
					break;
				}
			}
			file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_do_file, $xml->saveXML());
			$this->m_GeneratedFiles['DataObjFiles']['PrimaryDO']=str_replace(MODULE_PATH,"",$pri_do_file);		
		}
		
		if($this->m_BuildOptions['modify_secondary_data_object']==1)
		{
			//ObjReferences
			//modify sec do adds JoinTable and FK Name field
			$sec_do_file = $this->m_SecondaryModule['secondary_do'];
			$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_do_file);
			$xml = new DOMDocument();		
			$xml->preserveWhiteSpace = false;
			$xml->formatOutput = true;
			$xml->loadXML($xmlStr);
			
			/**
			<Join Name="JoinType" 
					Table="asset_type" 
					Column="id" 
					ColumnRef="type_id" 
					JoinType="LEFT JOIN" />
			 */
			
			$joinName = "Join".$this->m_PrimaryModule['primary_do_key_display'];
			$comment = "Join table for ".$this->m_PrimaryModule['primary_module'].' reference';
			$do_name = $this->__getObjName($this->m_PrimaryModule['primary_do']);
			$pri_do_pkField = $this->m_PrimaryModule['primary_do_key_field'];
			$pri_do = BizSystem::getObject($do_name);
			$table = $pri_do->m_MainTable;		
			foreach($pri_do->m_BizRecord as $field)
			{
				if($field->m_Name == $pri_do_pkField){
					$column = $field->m_Column;
					break;
				}
			}
			
			/*
			foreach($sec_do->m_BizRecord as $field)
			{			
				if($field->m_Name == $this->m_o2m_fkField){
					$columnRef = $field->m_Column;
					break;
				}
			}
			*/
			$columnRef = $this->m_o2m_fkField;
			$newElement = $xml->createElement("Join");
			$newElement->setAttribute("Name", 		$joinName);		
			$newElement->setAttribute("Table",		$table);
			$newElement->setAttribute("Column",		$column);
			$newElement->setAttribute("ColumnRef",	$columnRef);
			$newElement->setAttribute("JoinType", 	"LEFT JOIN");
			$newElement->setAttribute("Description",$comment);
			
			//check if exists then ignore
			$nodeExists = false;
			foreach($xml->getElementsByTagName("Join") as $node)
			{
				if($node->attributes->getNamedItem("Name")->nodeValue == $joinName)
				{
					$nodeExists = true ;
					break;
				}
			}
			
			if(!$nodeExists)
			{
				foreach($xml->getElementsByTagName("TableJoins") as $node)
				{			
					$node->appendChild($newElement);	
					break;
				}
			}
			
			//add join field
			/**
			 * <BizField Name="type_color" Column="color" Join="JoinType"/>			 
			 */
			$primary_name 		= $this->m_PrimaryModule['primary_do_key_display'];
			$primary_fieldname 	= $this->m_PrimaryModule['primary_do_display_field'];
			$joinFieldName = strtolower($primary_name)."_".$primary_fieldname;
			
			$pri_do_file = $this->m_PrimaryModule['primary_do'];
			$pri_do = BizSystem::getObject($do_name);
			$table = $pri_do->m_MainTable;		
			foreach($pri_do->m_BizRecord as $field)
			{
				if($field->m_Name == $primary_fieldname){
					$joinColumn = $field->m_Column;
					break;
				}
			}
			$newField = $xml->createElement("BizField");
			$newField->setAttribute("Name", 		$joinFieldName);		
			$newField->setAttribute("Column",		$joinColumn);
			$newField->setAttribute("Join",			$joinName);
			
			foreach($xml->getElementsByTagName("BizField") as $node)
			{
				if($node->attributes->getNamedItem("Name")->nodeValue == $joinFieldName)
				{
					$nodeExists = true ;
					break;
				}
			}
			if(!$nodeExists)
			{
				$xml->getElementsByTagName("BizFieldList")->item(0)->appendChild($newField);
			}
			$this->m_o2m_fkDisplayField = $joinFieldName;
			
			file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_do_file, $xml->saveXML());
			$this->m_GeneratedFiles['DataObjFiles']['SecondaryDO']=str_replace(MODULE_PATH,"",$sec_do_file);
		}
	}

	protected function _o2m_modifyPriDetailForm()
	{
		if($this->m_BuildOptions['modify_primary_detail_form']==0)
		{
			return ;
		}
		$pri_detail_form_file = $this->m_BuildOptions['primary_detail_form_name'];
				
		$this->__upgradeDetailForm($pri_detail_form_file);
		
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);				
		
		/*
		 *         
		<Element Name="fld_related_task"   
				TabSet="Extra Information"  
				Access="collab_task.access"  
				ElementSet="Task" 
				Class="FormElement" 
				FormReference="collab.task.widget.TaskListDetailForm" 
				FieldName="" 
				Label="" 
				AllowURLParam="N" />	
		 */
		//if specified add secondary read only list widget
		$secondary_name = $this->m_SecondaryModule['secondary_do_key_display'];
		$sec_display_name = ucwords($secondary_name);
		$sec_readonly_list_widget = $this->m_SecondaryModule['secondary_list_widget_ro'];
		if($sec_readonly_list_widget)
		{
			//get $pri_module_access
			$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_readonly_list_widget);
			$widget_xml = new DOMDocument();		
			$widget_xml->preserveWhiteSpace = false;
			$widget_xml->formatOutput = true;
			$widget_xml->loadXML($xmlStr);
			$sec_module_access = $widget_xml->documentElement->attributes->getNamedItem("Access")->nodeValue;
		}
		
		$listElement = $xml->createElement("Element");
		$listElement->setAttribute("Name", 			"fld_related_".strtolower($secondary_name));		
		$listElement->setAttribute("TabSet",		"Extra Information");
		$listElement->setAttribute("ElementSet",	$sec_display_name);
		$listElement->setAttribute("Class",			"FormElement");
		$listElement->setAttribute("FormReference", $this->__getObjName($sec_readonly_list_widget));
		$listElement->setAttribute("FieldName",		"");
		$listElement->setAttribute("Label",			"");
		$listElement->setAttribute("AllowURLParam",	"N");
		$listElement->setAttribute("Access",		$sec_module_access);
		
		
		/*
		 *         
		<Element Name="btn_manage_task"  
				TabSet="Extra Information"  
				Access="collab_task.access"  
				Hidden="{@:m_CanUpdateRecord=='1'?'N':'Y'}" 
				ElementSet="Task"  
				Style="color:#666666;margin-left:5px;margin-top:2px;"  
				Class="Button" 
				Text="Manage" 
				CssClass="button_gray_w" 
				Description="">
			<EventHandler Name="btn_manage_task_onclick" 
						Event="onclick" 
						Function="SwitchForm(collab.project.form.ProjectEditTaskForm,{@:Elem[fld_Id].Value})"   />
        </Element> 		
		 */
		//if specified add secondary management button for editable widget and form
		$sec_editable_list_widget = $this->m_SecondaryModule['secondary_list_widget_rw'];
		$pri_assoc_form_name = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($secondary_name))."Form", $this->__getObjName($pri_detail_form_file));
		$manageButton = $xml->createElement("Element");
		$manageButton->setAttribute("Name", 		"btn_manage_".strtolower($secondary_name));		
		$manageButton->setAttribute("Hidden",		"{@:m_CanUpdateRecord=='1'?'N':'Y'}");
		$manageButton->setAttribute("TabSet",		"Extra Information");
		$manageButton->setAttribute("ElementSet",	$sec_display_name);
		$manageButton->setAttribute("Class",		"Button");
		$manageButton->setAttribute("CssClass",		"button_gray_w");
		$manageButton->setAttribute("Text",			"Manage");
		$manageButton->setAttribute("Style",		"color:#666666;margin-left:5px;margin-top:2px;");		
		$manageButton->setAttribute("Access",		$sec_module_access);
		
		$manageButtonClick = $xml->createElement("EventHandler");
		$manageButtonClick->setAttribute("Name", 		"btn_manage_".strtolower($secondary_name)."_onclick");		
		$manageButtonClick->setAttribute("Event",		"onclick");
		$manageButtonClick->setAttribute("Function",	"SwitchForm($pri_assoc_form_name,{@:Elem[fld_Id].Value})");		
		$manageButton->appendChild($manageButtonClick);
		
		//find best position to add new elements in detail form
		$foundPos = false;
		foreach($xml->getElementsByTagName("Element") as $node)
		{			
			if($node->attributes
					->getNamedItem("TabSet")
					->nodeValue == "Extra Information")
			{
				$refNode = $node;
				$foundPos = true;
				break;
			}			
		}
		if(!$foundPos)
		{
			foreach($xml->getElementsByTagName("Element") as $node)
			{			
				if($node->attributes
						->getNamedItem("ElementSet")
						->nodeValue == "Miscellaneous")
				{
					$refNode = $node;
					$foundPos = true;
					break;
				}			
			}
		}
		//check if exists then ignore
		$nodeListExists = false;
		$nodeButtonExists = false;
		foreach($xml->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == "fld_related_".strtolower($secondary_name))
			{
				$nodeListExists = true ;				
			}
			if($node->attributes->getNamedItem("Name")->nodeValue == "btn_manage_".strtolower($secondary_name))
			{
				$nodeButtonExists = true ;				
			}
		}
			
		if(!$foundPos)
		{
			//append to data panel
			foreach($xml->getElementsByTagName("DataPanel") as $node)
			{
				if($sec_readonly_list_widget && !$nodeListExists)
				{
					$node->appendChild($listElement);
				}
				if($sec_editable_list_widget && !$nodeButtonExists)
				{
					$node->appendChild($manageButton);
				}
				break;
			}
		}
		else
		{
			//insert before ref node			
			if($sec_readonly_list_widget && !$nodeListExists)
			{
				$refNode->parentNode->insertBefore($listElement,$refNode);
			}
			if($sec_editable_list_widget && !$nodeButtonExists)
			{
				$refNode->parentNode->insertBefore($manageButton,$refNode);
			}
		}
		file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_detail_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['DetailForm']=str_replace(MODULE_PATH,"",$pri_detail_form_file);
	}
	
	protected function _o2m_genAssocForm()
	{
		if($this->m_BuildOptions['gen_primary_assoc_form']==0)
		{
			return ;
		}
		$secondary_name = $this->m_SecondaryModule['secondary_do_key_display'];
		$pri_detail_form_file = $this->m_BuildOptions['primary_detail_form_name'];
		$pri_detail_form_name = $this->__getObjName($pri_detail_form_file);
		$pri_assoc_form_name = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($secondary_name))."Form", $this->__getObjName($pri_detail_form_file));
		$pri_assoc_form_file = $this->__getObjFile($pri_assoc_form_name);
		
		//read from detail form
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		$oldFormName = $xml->documentElement->attributes->getNamedItem("Name")->nodeValue;
		$xml->documentElement->attributes->getNamedItem("Name")->nodeValue = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($secondary_name))."Form", $oldFormName);
		
		//only keep general elementSet and append formElement reference to detail
		$removeList=array();
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("ElementSet")->nodeValue!='General' &&
				$node->attributes->getNamedItem("ElementSet")->nodeValue!='')
			{
				$removeList[] = $node;				
			}			
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}
		
		//append the related form element
		/**
		 *         
				<Element Name="fld_related_attachment" 
				Access="attachment.access"  
				ElementSet="Attachment" 
				Class="FormElement" 
				FormReference="attachment.widget.AttachmentListEditForm" 
				FieldName="" 
				Label="" 
				AllowURLParam="N" />
		 */
		$sec_editable_list_widget = $this->m_SecondaryModule['secondary_list_widget_rw'];
		$sec_readonly_list_widget = $this->m_SecondaryModule['secondary_list_widget_ro'];
		$secondary_name = $this->m_SecondaryModule['secondary_do_key_display'];
		$sec_display_name = ucwords($secondary_name);
		//get $pri_module_access
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_readonly_list_widget);
		$widget_xml = new DOMDocument();		
		$widget_xml->preserveWhiteSpace = false;
		$widget_xml->formatOutput = true;
		$widget_xml->loadXML($xmlStr);
		$pri_module_access = $widget_xml->documentElement->attributes->getNamedItem("Access")->nodeValue;
		
		$relatedForm = $xml->createElement("Element");
		$relatedForm->setAttribute("Name", 			"fld_related_".strtolower($sec_display_name));		
		$relatedForm->setAttribute("Access",		$pri_module_access);
		$relatedForm->setAttribute("ElementSet",	$sec_display_name);
		$relatedForm->setAttribute("TabSet",		"Related Data");
		$relatedForm->setAttribute("Class",			"FormElement");
		$relatedForm->setAttribute("FormReference",	$this->__getObjName($sec_editable_list_widget));		
		$xml->getElementsByTagName("DataPanel")->item(0)->appendChild($relatedForm);
		
		
		//remove all elements from action paneel
		$removeList=array();
		foreach($xml->getElementsByTagName("ActionPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			$removeList[] = $node;				
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}		
		//append the buttons
		/**
		 *         
		 <Element Name="btn_save" 
        		Class="Button" 
        		Text="Save" 
        		CssClass="button_gray_m">
            <EventHandler Name="save_onclick" 	
            			Event="onclick" 
            			EventLogMsg=""  
            			Function="SwitchForm(account..form.AccountDetailForm,{@account..do.AccountDO:Field[Id].Value})"  
            			ShortcutKey="Ctrl+Enter" 
            			ContextMenu="Save" />
        </Element>
        <Element Name="btn_cancel" 
        		Class="Button" 
        		Text="Cancel" 
        		CssClass="button_gray_m">
            <EventHandler Name="btn_cancel_onclick" 
            			Event="onclick" 
            			Function="SwitchForm()"  
            			ShortcutKey="Escape" 
            			ContextMenu="Cancel" />
        </Element> 
		 */
		$saveButton = $xml->createElement("Element");
		$saveButton->setAttribute("Name", 		"btn_save");		
		$saveButton->setAttribute("Class",		"Button");
		$saveButton->setAttribute("Text",		"Save");
		$saveButton->setAttribute("CssClass",	"button_gray_m");
		$saveButtonClick = $xml->createElement("EventHandler");
		$saveButtonClick->setAttribute("Name", 			"btn_save_onclick");		
		$saveButtonClick->setAttribute("Event",			"onclick");
		$saveButtonClick->setAttribute("ShortcutKey",	"Ctrl+Enter");
		$saveButtonClick->setAttribute("ContextMenu",	"Save");
		$saveButtonClick->setAttribute("Function",		"SwitchForm($pri_detail_form_name,{@:Elem[fld_Id].Value})");		
		$saveButton->appendChild($saveButtonClick);
		$xml->getElementsByTagName("ActionPanel")->item(0)->appendChild($saveButton);
		
		
		$backButton = $xml->createElement("Element");
		$backButton->setAttribute("Name", 		"btn_cancel");		
		$backButton->setAttribute("Class",		"Button");
		$backButton->setAttribute("Text",		"Cancel");
		$backButton->setAttribute("CssClass",	"button_gray_m");
		$backButtonClick = $xml->createElement("EventHandler");
		$backButtonClick->setAttribute("Name", 			"btn_cancel_onclick");		
		$backButtonClick->setAttribute("Event",			"onclick");
		$backButtonClick->setAttribute("ShortcutKey",	"Escape");
		$backButtonClick->setAttribute("ContextMenu",	"Cancel");
		$backButtonClick->setAttribute("Function",		"SwitchForm()");		
		$backButton->appendChild($backButtonClick);
		$xml->getElementsByTagName("ActionPanel")->item(0)->appendChild($backButton);
		
		//save File
		file_put_contents($pri_assoc_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['AssocForm']=str_replace(MODULE_PATH,"",$pri_assoc_form_file);
		
	}

	protected function _o2m_modifySecDetailForm()
	{
		if($this->m_BuildOptions['modify_secondary_detail_form']==0)
		{
			return ;
		}
		$sec_detail_form_name = $this->m_BuildOptions['secondary_detail_form_name'];
		$sec_detail_form_file = $this->__getObjFile($sec_detail_form_name);
		$primary_name = $this->m_PrimaryModule['primary_do_key_display'];
		$pri_display_name = ucwords($primary_name);
		
		//read from detail form
		$xmlStr = file_get_contents($sec_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		$element = $xml->createElement("Element");
		$element->setAttribute("Name", 		"fld_".strtolower($pri_display_name));		
		$element->setAttribute("Hidden",	"{@:Elem[fld_".strtolower($pri_display_name)."].Value?'N':'Y'}");
		$element->setAttribute("ElementSet", "General");
		$element->setAttribute("Class",		"LabelText");
		$element->setAttribute("Label",		ucwords($pri_display_name));						
		$element->setAttribute("FieldName",		$this->m_o2m_fkDisplayField);
		
		//delete existing same name elements
		$removeList = array();
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == "fld_".strtolower($pri_display_name) 
			){
				$removeList[] = $node;	
			}					
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}		
		
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{		
			$node->parentNode->insertBefore($element,$node);	
			break;			
		}

		//save File
		file_put_contents($sec_detail_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['SecDetailForm']=str_replace(MODULE_PATH,"",$sec_detail_form_file);
	}
	
	protected function _o2m_modifySecForm($formName)
	{
		$sec_new_form_name = $formName;
		$sec_new_form_file = $this->__getObjFile($sec_new_form_name);
		$primary_name = $this->m_PrimaryModule['primary_do_key_display'];
		$pri_display_name = ucwords($primary_name);
		$pri_do_file = $this->m_PrimaryModule['primary_do'];
		$pri_do_name = $this->__getObjName($pri_do_file);
		$pri_do_pk  = $this->m_PrimaryModule['primary_do_key_field'];
		$pri_do_pk_display = $this->m_PrimaryModule['primary_do_display_field'];
		 		
		//read from detail form
		$xmlStr = file_get_contents($sec_new_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		
		/*
		 * if pri module has a picker widget then use widget
		 * else use list box as data picker
		 */
		if($this->m_PrimaryModule['primary_list_widget_pick']!=null)
		{
			//use picker widget
			/*
			<Element Name="fld_project" DefaultValueRename="N" DefaultValue="0" ElementSet="General" Description="This task will belong selected project" Class="Hidden" FieldName="project_id" Label="Project"  AllowURLParam="N" />		
			<Element Name="fld_project_name"  Class="InputPicker" ElementSet="General" Description="This task will belong selected project"
			 Enabled="N" UpdateForm="Y" ValuePicker="collab.project.widget.ProjectSinglePickForm" PickerMap="fld_project:fld_Id,fld_project_name:fld_title" DefaultValue="{@:Elem[fld_project].Value>0?@:Field[project_name].Value:''}" DefaultValueRename="N" FieldName="project_name" Label="Project"  /> 
			 */
			
			//get $pickerNameField value
			$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$this->m_PrimaryModule['primary_list_widget_pick']);
			$pickerXml = new DOMDocument();		
			$pickerXml->preserveWhiteSpace = false;
			$pickerXml->formatOutput = true;
			$pickerXml->loadXML($xmlStr);
			foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
			{		
				if($node->attributes->getNamedItem("FieldName")->nodeValue==$pri_do_pk_display)
				{
					$pickerNameField= $node->attributes->getNamedItem("Name")->nodeValue;				
					break;	
				}						
			}
		
			$elementName = "fld_".strtolower($pri_display_name);
			$element = $xml->createElement("Element");			
			$element->setAttribute("Name", 		$elementName);		
			$element->setAttribute("ElementSet", "General");
			$element->setAttribute("Class",		"Hidden");
			$element->setAttribute("FieldName",		$this->m_o2m_fkField);
			$element->setAttribute("Label",		ucwords($pri_display_name));	
			
			$pickerName = "fld_".strtolower($pri_display_name)."_name";
			$pickerObj = $this->__getObjName($this->m_PrimaryModule['primary_list_widget_pick']);
			$picker = $xml->createElement("Element");
			$picker->setAttribute("Name", 		$pickerName);		
			$picker->setAttribute("ElementSet", "General");
			$picker->setAttribute("Class",		"InputPicker");
			$picker->setAttribute("FieldName",		$this->m_o2m_fkDisplayField);
			$picker->setAttribute("Label",		ucwords($pri_display_name));						
			$picker->setAttribute("Enabled",	"N");
			$picker->setAttribute("UpdateForm",	"Y");
			$picker->setAttribute("ValuePicker",$pickerObj);
			$picker->setAttribute("PickerMap",		"$elementName:fld_Id,$pickerName:$pickerNameField");
			$picker->setAttribute("DefaultValue",	"{(@:Elem[$elementName].Value>0)?@:Field[".$this->m_o2m_fkDisplayField."].Value:''}");
		}
		else
		{
			//use list box
			/*
			 * <Element Name="fld_project" ElementSet="General" Class="Listbox" SelectFrom="collab.project.do.projectDO[name:Id]" FieldName="project_id" Label="Project"  AllowURLParam="N" />
			 */
			$element = $xml->createElement("Element");
			$element->setAttribute("Name", 		"fld_".strtolower($pri_display_name));		
			$element->setAttribute("ElementSet", "General");
			$element->setAttribute("Class",		"Listbox");
			$element->setAttribute("SelectFrom",$pri_do_name."[$pri_do_pk_display:$pri_do_pk]");			
			$element->setAttribute("Label",		ucwords($pri_display_name));						
			$element->setAttribute("FieldName",		$this->m_o2m_fkField);
		}
		
		//delete existing elements
		$removeList = array();
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == "fld_".strtolower($pri_display_name) ||
				$node->attributes->getNamedItem("FieldName")->nodeValue == $this->m_o2m_fkField 
			){
				$removeList[] = $node;	
			}					
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}
		
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{		
			$node->parentNode->insertBefore($element,$node);
			if($picker)
			{
				$node->parentNode->insertBefore($picker,$node);
			}	
			break;			
		}
		return $xml->saveXML();
	}
	
	protected function _o2m_modifySecNewForm()
	{
		if($this->m_BuildOptions['modify_secondary_new_form']==0)
		{
			return ;
		}
		$sec_form_name = $this->m_BuildOptions['secondary_new_form_name'];
		$sec_form_file = $this->__getObjFile($sec_form_name);
		$result = $this->_o2m_modifySecForm($sec_form_name);
		file_put_contents($sec_form_file, $result);
		$this->m_GeneratedFiles['FormObjFiles']['SecNewForm']=str_replace(MODULE_PATH,"",$sec_form_file);		
	}
	
	
	protected function _o2m_modifySecEditForm()
	{
		if($this->m_BuildOptions['modify_secondary_edit_form']==0)
		{
			return ;
		}
		$sec_form_name = $this->m_BuildOptions['secondary_edit_form_name'];
		$sec_form_file = $this->__getObjFile($sec_form_name);
		$result = $this->_o2m_modifySecForm($sec_form_name);
		file_put_contents($sec_form_file, $result);
		$this->m_GeneratedFiles['FormObjFiles']['SecEditForm']=str_replace(MODULE_PATH,"",$sec_form_file);
	}
	
	protected function _o2m_modifySecCopyForm()
	{
		if($this->m_BuildOptions['modify_secondary_copy_form']==0)
		{
			return ;
		}
		$sec_form_name = $this->m_BuildOptions['secondary_copy_form_name'];
		$sec_form_file = $this->__getObjFile($sec_form_name);
		$result = $this->_o2m_modifySecForm($sec_form_name);
		file_put_contents($sec_form_file, $result);
		$this->m_GeneratedFiles['FormObjFiles']['SecCopyForm']=str_replace(MODULE_PATH,"",$sec_form_file);
	}	
	
	/*Many to Many logic methods below */
	protected function _m2m_genIntermediateDO()
	{
		if($this->m_BuildOptions['intermediate_table_creation']==1)
		{
			//create a new table
			$modName		= $this->m_PrimaryModule['primary_module']; 
			$priDO			= $this->m_PrimaryModule['primary_do'];
			$do_name = $this->__getObjName($priDO);
			$obj = BizSystem::getObject($do_name);		
			$db = $obj->getDBConnection("write");
			
			$tableName 		= $this->m_BuildOptions['intermediate_table_create'];
			$primaryFK 		= strtolower($this->m_PrimaryModule['primary_do_key_display'])."_id";
			$secondaryFK 	= strtolower($this->m_SecondaryModule['secondary_do_key_display'])."_id";
			
			try{
				$sql = "DROP TABLE IF EXISTS `$tableName` ;";
				$db->query($sql);
				$this->__modifyInstallSQL($sql, $modName);
			}catch(Exception $e){}
			
			$sql = "			
CREATE TABLE IF NOT EXISTS `$tableName` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `$primaryFK` int(10) unsigned NOT NULL DEFAULT '0',
  `$secondaryFK` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `$primaryFK` (`$primaryFK`),
  KEY `$secondaryFK` (`$secondaryFK`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
				";
			$db->query($sql);			
			$this->__modifyInstallSQL($sql, $modName);
		}
		else
		{
			//using existing table
			$tableName		= $this->m_BuildOptions['intermediate_table_exists'];
			$primaryFK 		= $this->m_BuildOptions['intermediate_table_pri_fk'];
			$secondaryFK 	= $this->m_BuildOptions['intermediate_table_sec_fk'];
		}		
		
		//generate pri intermediate do
		$modName = $this->m_PrimaryModule['primary_module']; 
		$priName = $this->m_PrimaryModule['primary_do_key_display'];
		$secName = $this->m_SecondaryModule['secondary_do_key_display'];
		$priDO	 = $this->m_PrimaryModule['primary_do'];
		$do_name = $this->__getObjName($priDO);
		$obj = BizSystem::getObject($do_name);		
		
		$dbName = $obj->m_Database;
		$doName = ucfirst($priName).ucfirst($secName)."DO";
		$doDesc =  "Intermediate Data Object for $priName and $secName";
		
		$smarty = BizSystem::getSmartyTemplate();
        $smarty->assign("do_name", $doName);        
        $smarty->assign("do_desc", $doDesc);
        $smarty->assign("db_name", $dbName);                
        $smarty->assign("table_name", $tableName);
        $smarty->assign("primary_fk", $primaryFK);
        $smarty->assign("secondary_fk", $secondaryFK);                
        $templateFile = $this->__getMetaTempPath().'/do/DataObjectIntermediate.xml.tpl';
        $content = $smarty->fetch($templateFile);
        
        $targetPath = MODULE_PATH . "/" . str_replace(".", "/", $modName) . "/do";
        $targetFile = $targetPath . "/" . $doName . ".xml";
        file_put_contents($targetFile, $content);
        $this->m_m2m_intermediate_pri_do = $doName;
        $this->m_m2m_intermediate_pri_do_fullname = $modName.'.do.'.$doName;
        $this->m_GeneratedFiles['DataObjFiles']['PrimaryIntermediateDO']=str_replace(MODULE_PATH,"",$targetFile);	
        
        //generate sec intermediate do
        $modName = $this->m_SecondaryModule['secondary_module']; 
        $doName = ucfirst($secName).ucfirst($priName)."DO";
        
        $smarty->assign("do_name", $doName);   
        $content = $smarty->fetch($templateFile); 
        
        $targetPath = MODULE_PATH . "/" . str_replace(".", "/", $modName) . "/do";
        $targetFile = $targetPath . "/" . $doName . ".xml";
        file_put_contents($targetFile, $content);        
        $this->m_m2m_intermediate_sec_do = $doName;
        $this->m_m2m_intermediate_sec_do_fullname = $modName.'.do.'.$doName;
        $this->m_GeneratedFiles['DataObjFiles']['SecondaryIntermediateDO']=str_replace(MODULE_PATH,"",$targetFile);	
        
		$this->m_m2m_intermediate_table = $tableName;
		$this->m_m2m_primary_fk = $primaryFK;
		$this->m_m2m_secondary_fk = $secondaryFK;
		return ;
	}
		
	protected function _m2m_modifyPriDO()
	{
		if($this->m_BuildOptions['modify_primary_data_object']==0)
		{
			return ;
		}
		$pri_do_file	= $this->m_PrimaryModule['primary_do'];
		$sec_do_file	= $this->m_SecondaryModule['secondary_do'];
		$pri_do_name	= $this->__getObjName($pri_do_file);
		$sec_do_name	= $this->__getObjName($sec_do_file);
		$pri_pk_field 	= $this->m_PrimaryModule['primary_do_key_field'];
		$sec_pk_field	= $this->m_SecondaryModule['secondary_do_key_field'];
		$desc = "Reference to $sec_do_name with M-M relationship";
		
		$ref_do = BizSystem::getObject($sec_do_name);
		$ref_table = $ref_do->m_MainTable;
		foreach($ref_do->m_BizRecord as $field)
		{
			if($field->m_Name == $sec_pk_field){
				$ref_column = $field->m_Column;
				break;
			}
		}
			
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_do_file);		
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		/*
		 * <Object Name="collab.document.do.DocumentDO" 
		 * 			Description="" 
		 * 			Relationship="M-M" 
		 * 			Table="document" 
		 * 			Column="id" 
		 * 			FieldRef="Id" 
		 * 			OnDelete="Cascade" 
		 * 			OnUpdate="Cascade" 
		 * 			XTable="task_document" 
		 * 			XColumn1="task_id" 
		 * 			XColumn2="document_id" 
		 * 			XDataObj="collab.task.do.TaskDocumentDO"/> 		 
		 */
		$objReference = $xml->createElement("Object");
		$objReference->setAttribute("Name", 			$sec_do_name);		
		$objReference->setAttribute("Description",		$desc);
		$objReference->setAttribute("Relationship",		"M-M");
		$objReference->setAttribute("Table",			$ref_table);
		$objReference->setAttribute("Column",			$ref_column);
		$objReference->setAttribute("FieldRef", 		$pri_pk_field);
		$objReference->setAttribute("OnDelete",			"Cascade");
		$objReference->setAttribute("OnUpdate",			"Cascade");
		$objReference->setAttribute("XTable",			$this->m_m2m_intermediate_table);
		$objReference->setAttribute("XColumn1",			$this->m_m2m_primary_fk);
		$objReference->setAttribute("XColumn2",			$this->m_m2m_secondary_fk);
		$objReference->setAttribute("XDataObj",			$this->m_m2m_intermediate_pri_do_fullname);
		
		//escape repeat items
		$removeList=array();
		foreach($xml->getElementsByTagName("ObjReferences")->item(0)->getElementsByTagName("Object") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == $sec_do_name)				
			{
				$removeList[] = $node;				
			}			
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}
		
		//save changes to XML dom
		$xml->getElementsByTagName("ObjReferences")->item(0)->appendChild($objReference); 
		
		file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_do_file, $xml->saveXML());		
		$this->m_GeneratedFiles['DataObjFiles']['PrimaryDO']='/'.str_replace(MODULE_PATH,"",$pri_do_file);			
	}
	
	protected function _m2m_modifySecDO()
	{		
		if($this->m_BuildOptions['modify_secondary_data_object']==0)
		{
			return ;
		}
		$pri_do_file	= $this->m_PrimaryModule['primary_do'];
		$sec_do_file	= $this->m_SecondaryModule['secondary_do'];
		$pri_do_name	= $this->__getObjName($pri_do_file);
		$sec_do_name	= $this->__getObjName($sec_do_file);
		$pri_pk_field 	= $this->m_PrimaryModule['primary_do_key_field'];
		$sec_pk_field	= $this->m_SecondaryModule['secondary_do_key_field'];
		$desc = "Reference to $pri_do_name with M-M relationship";
		
		$ref_do = BizSystem::getObject($pri_do_name);
		$ref_table = $ref_do->m_MainTable;
		foreach($ref_do->m_BizRecord as $field)
		{
			if($field->m_Name == $sec_pk_field){
				$ref_column = $field->m_Column;
				break;
			}
		}

		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_do_file);		
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		/*
		 * <Object Name="collab.document.do.DocumentDO" 
		 * 			Description="" 
		 * 			Relationship="M-M" 
		 * 			Table="document" 
		 * 			Column="id" 
		 * 			FieldRef="Id" 
		 * 			OnDelete="Cascade" 
		 * 			OnUpdate="Cascade" 
		 * 			XTable="task_document" 
		 * 			XColumn1="task_id" 
		 * 			XColumn2="document_id" 
		 * 			XDataObj="collab.task.do.TaskDocumentDO"/> 		 
		 */
		$objReference = $xml->createElement("Object");
		$objReference->setAttribute("Name", 			$pri_do_name);		
		$objReference->setAttribute("Description",		$desc);
		$objReference->setAttribute("Relationship",		"M-M");
		$objReference->setAttribute("Table",			$ref_table);
		$objReference->setAttribute("Column",			$ref_column);
		$objReference->setAttribute("FieldRef", 		$sec_pk_field);
		$objReference->setAttribute("OnDelete",			"Cascade");
		$objReference->setAttribute("OnUpdate",			"Cascade");
		$objReference->setAttribute("XTable",			$this->m_m2m_intermediate_table);
		$objReference->setAttribute("XColumn1",			$this->m_m2m_secondary_fk);
		$objReference->setAttribute("XColumn2",			$this->m_m2m_primary_fk);
		$objReference->setAttribute("XDataObj",			$this->m_m2m_intermediate_sec_do_fullname);
		
		//escape repeat items
		$removeList=array();
		foreach($xml->getElementsByTagName("ObjReferences")->item(0)->getElementsByTagName("Object") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == $pri_do_name)				
			{
				$removeList[] = $node;				
			}			
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}
		
		//save changes to XML dom
		$xml->getElementsByTagName("ObjReferences")->item(0)->appendChild($objReference); 
		
		file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_do_file, $xml->saveXML());		
		$this->m_GeneratedFiles['DataObjFiles']['SecondaryDO']='/'.str_replace(MODULE_PATH,"",$sec_do_file);					
	}
				
	protected function _m2m_genPriAssocForm()
	{
		if($this->m_BuildOptions['gen_primary_assoc_form']==0)
		{
			return ;
		}
		$secondary_name = $this->m_SecondaryModule['secondary_do_key_display'];
		$pri_detail_form_file = $this->m_BuildOptions['primary_detail_form_name'];
		$pri_detail_form_name = $this->__getObjName($pri_detail_form_file);
		$pri_assoc_form_name = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($secondary_name))."Form", $this->__getObjName($pri_detail_form_file));
		$pri_assoc_form_file = $this->__getObjFile($pri_assoc_form_name);
		
		//read from detail form
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		$oldFormName = $xml->documentElement->attributes->getNamedItem("Name")->nodeValue;
		$xml->documentElement->attributes->getNamedItem("Name")->nodeValue = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($secondary_name))."Form", $oldFormName);
		
		//only keep general elementSet and append formElement reference to detail
		$removeList=array();
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("ElementSet")->nodeValue!='General' &&
				$node->attributes->getNamedItem("ElementSet")->nodeValue!='')
			{
				$removeList[] = $node;				
			}			
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}
		
		//append the related form element
		/**
		 *         
				<Element Name="fld_related_attachment" 
				Access="attachment.access"  
				ElementSet="Attachment" 
				Class="FormElement" 
				FormReference="attachment.widget.AttachmentListEditForm" 
				FieldName="" 
				Label="" 
				AllowURLParam="N" />
		 */
		$sec_editable_list_widget = $this->m_SecondaryModule['secondary_list_widget_rw'];
		$sec_readonly_list_widget = $this->m_SecondaryModule['secondary_list_widget_ro'];
		$secondary_name = $this->m_SecondaryModule['secondary_do_key_display'];
		$sec_display_name = ucwords($secondary_name);
		//get $pri_module_access
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_readonly_list_widget);
		$widget_xml = new DOMDocument();		
		$widget_xml->preserveWhiteSpace = false;
		$widget_xml->formatOutput = true;
		$widget_xml->loadXML($xmlStr);
		$sec_module_access = $widget_xml->documentElement->attributes->getNamedItem("Access")->nodeValue;
		
		$relatedForm = $xml->createElement("Element");
		$relatedForm->setAttribute("Name", 			"fld_related_".strtolower($sec_display_name));		
		$relatedForm->setAttribute("Access",		$sec_module_access);
		$relatedForm->setAttribute("ElementSet",	$sec_display_name);
		$relatedForm->setAttribute("TabSet",		"Related Data");
		$relatedForm->setAttribute("Class",			"FormElement");
		$relatedForm->setAttribute("FormReference",	$this->__getObjName($sec_editable_list_widget));		
		$xml->getElementsByTagName("DataPanel")->item(0)->appendChild($relatedForm);
		
		
		//remove all elements from action paneel
		$removeList=array();
		foreach($xml->getElementsByTagName("ActionPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			$removeList[] = $node;				
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}		
		//append the buttons
		/**
		 *         
		 <Element Name="btn_save" 
        		Class="Button" 
        		Text="Save" 
        		CssClass="button_gray_m">
            <EventHandler Name="save_onclick" 	
            			Event="onclick" 
            			EventLogMsg=""  
            			Function="SwitchForm(account..form.AccountDetailForm,{@account..do.AccountDO:Field[Id].Value})"  
            			ShortcutKey="Ctrl+Enter" 
            			ContextMenu="Save" />
        </Element>
        <Element Name="btn_cancel" 
        		Class="Button" 
        		Text="Cancel" 
        		CssClass="button_gray_m">
            <EventHandler Name="btn_cancel_onclick" 
            			Event="onclick" 
            			Function="SwitchForm()"  
            			ShortcutKey="Escape" 
            			ContextMenu="Cancel" />
        </Element> 
		 */
		$saveButton = $xml->createElement("Element");
		$saveButton->setAttribute("Name", 		"btn_save");		
		$saveButton->setAttribute("Class",		"Button");
		$saveButton->setAttribute("Text",		"Save");
		$saveButton->setAttribute("CssClass",	"button_gray_m");
		$saveButtonClick = $xml->createElement("EventHandler");
		$saveButtonClick->setAttribute("Name", 			"btn_save_onclick");		
		$saveButtonClick->setAttribute("Event",			"onclick");
		$saveButtonClick->setAttribute("ShortcutKey",	"Ctrl+Enter");
		$saveButtonClick->setAttribute("ContextMenu",	"Save");
		$saveButtonClick->setAttribute("Function",		"SwitchForm($pri_detail_form_name,{@:Elem[fld_Id].Value})");		
		$saveButton->appendChild($saveButtonClick);
		$xml->getElementsByTagName("ActionPanel")->item(0)->appendChild($saveButton);
		
		
		$backButton = $xml->createElement("Element");
		$backButton->setAttribute("Name", 		"btn_cancel");		
		$backButton->setAttribute("Class",		"Button");
		$backButton->setAttribute("Text",		"Cancel");
		$backButton->setAttribute("CssClass",	"button_gray_m");
		$backButtonClick = $xml->createElement("EventHandler");
		$backButtonClick->setAttribute("Name", 			"btn_cancel_onclick");		
		$backButtonClick->setAttribute("Event",			"onclick");
		$backButtonClick->setAttribute("ShortcutKey",	"Escape");
		$backButtonClick->setAttribute("ContextMenu",	"Cancel");
		$backButtonClick->setAttribute("Function",		"SwitchForm()");		
		$backButton->appendChild($backButtonClick);
		$xml->getElementsByTagName("ActionPanel")->item(0)->appendChild($backButton);
		
		//save File
		file_put_contents($pri_assoc_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['PriAssocForm']=str_replace(MODULE_PATH,"",$pri_assoc_form_file);
	}
	
	protected function _m2m_genSecAssocForm()
	{
		if($this->m_BuildOptions['gen_secondary_assoc_form']==0)
		{
			return ;
		}		
		$primary_name = $this->m_PrimaryModule['primary_do_key_display'];
		$sec_detail_form_file = $this->m_BuildOptions['secondary_detail_form_name'];
		$sec_detail_form_name = $this->__getObjName($sec_detail_form_file);
		$sec_assoc_form_name = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($primary_name))."Form", $this->__getObjName($sec_detail_form_file));
		$sec_assoc_form_file = $this->__getObjFile($sec_assoc_form_name);
		
		//read from detail form
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		$oldFormName = $xml->documentElement->attributes->getNamedItem("Name")->nodeValue;
		$xml->documentElement->attributes->getNamedItem("Name")->nodeValue = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($primary_name))."Form", $oldFormName);
		
		//only keep general elementSet and append formElement reference to detail
		$removeList=array();
		foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("ElementSet")->nodeValue!='General' &&
				$node->attributes->getNamedItem("ElementSet")->nodeValue!='')
			{
				$removeList[] = $node;				
			}			
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}
		
		//append the related form element
		/**
		 *         
				<Element Name="fld_related_attachment" 
				Access="attachment.access"  
				ElementSet="Attachment" 
				Class="FormElement" 
				FormReference="attachment.widget.AttachmentListEditForm" 
				FieldName="" 
				Label="" 
				AllowURLParam="N" />
		 */
		$pri_editable_list_widget = $this->m_PrimaryModule['primary_list_widget_rw'];
		$pri_readonly_list_widget = $this->m_PrimaryModule['primary_list_widget_ro'];
		$primary_name = $this->m_PrimaryModule['primary_do_key_display'];
		$pri_display_name = ucwords($primary_name);
		//get $pri_module_access
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_readonly_list_widget);
		$widget_xml = new DOMDocument();		
		$widget_xml->preserveWhiteSpace = false;
		$widget_xml->formatOutput = true;
		$widget_xml->loadXML($xmlStr);
		$pri_module_access = $widget_xml->documentElement->attributes->getNamedItem("Access")->nodeValue;
		
		$relatedForm = $xml->createElement("Element");
		$relatedForm->setAttribute("Name", 			"fld_related_".strtolower($pri_display_name));		
		$relatedForm->setAttribute("Access",		$pri_module_access);
		$relatedForm->setAttribute("ElementSet",	$pri_display_name);
		$relatedForm->setAttribute("TabSet",		"Related Data");
		$relatedForm->setAttribute("Class",			"FormElement");
		$relatedForm->setAttribute("FormReference",	$this->__getObjName($pri_editable_list_widget));		
		$xml->getElementsByTagName("DataPanel")->item(0)->appendChild($relatedForm);
		
		
		//remove all elements from action paneel
		$removeList=array();
		foreach($xml->getElementsByTagName("ActionPanel")->item(0)->getElementsByTagName("Element") as $node)
		{
			$removeList[] = $node;				
		}
		foreach ($removeList as $node)
		{
			$node->parentNode->removeChild($node);
		}		
		//append the buttons
		/**
		 *         
		 <Element Name="btn_save" 
        		Class="Button" 
        		Text="Save" 
        		CssClass="button_gray_m">
            <EventHandler Name="save_onclick" 	
            			Event="onclick" 
            			EventLogMsg=""  
            			Function="SwitchForm(account..form.AccountDetailForm,{@account.do.AccountDO:Field[Id].Value})"  
            			ShortcutKey="Ctrl+Enter" 
            			ContextMenu="Save" />
        </Element>
        <Element Name="btn_cancel" 
        		Class="Button" 
        		Text="Cancel" 
        		CssClass="button_gray_m">
            <EventHandler Name="btn_cancel_onclick" 
            			Event="onclick" 
            			Function="SwitchForm()"  
            			ShortcutKey="Escape" 
            			ContextMenu="Cancel" />
        </Element> 
		 */
		$saveButton = $xml->createElement("Element");
		$saveButton->setAttribute("Name", 		"btn_save");		
		$saveButton->setAttribute("Class",		"Button");
		$saveButton->setAttribute("Text",		"Save");
		$saveButton->setAttribute("CssClass",	"button_gray_m");
		$saveButtonClick = $xml->createElement("EventHandler");
		$saveButtonClick->setAttribute("Name", 			"btn_save_onclick");		
		$saveButtonClick->setAttribute("Event",			"onclick");
		$saveButtonClick->setAttribute("ShortcutKey",	"Ctrl+Enter");
		$saveButtonClick->setAttribute("ContextMenu",	"Save");
		$saveButtonClick->setAttribute("Function",		"SwitchForm($sec_detail_form_name,{@:Elem[fld_Id].Value})");		
		$saveButton->appendChild($saveButtonClick);
		$xml->getElementsByTagName("ActionPanel")->item(0)->appendChild($saveButton);
		
		
		$backButton = $xml->createElement("Element");
		$backButton->setAttribute("Name", 		"btn_cancel");		
		$backButton->setAttribute("Class",		"Button");
		$backButton->setAttribute("Text",		"Cancel");
		$backButton->setAttribute("CssClass",	"button_gray_m");
		$backButtonClick = $xml->createElement("EventHandler");
		$backButtonClick->setAttribute("Name", 			"btn_cancel_onclick");		
		$backButtonClick->setAttribute("Event",			"onclick");
		$backButtonClick->setAttribute("ShortcutKey",	"Escape");
		$backButtonClick->setAttribute("ContextMenu",	"Cancel");
		$backButtonClick->setAttribute("Function",		"SwitchForm()");		
		$backButton->appendChild($backButtonClick);
		$xml->getElementsByTagName("ActionPanel")->item(0)->appendChild($backButton);
		
		//save File
		file_put_contents($sec_assoc_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['SecAssocForm']=str_replace(MODULE_PATH,"",$sec_assoc_form_file);
	}
		
	protected function _m2m_modifyPriDetailForm()
	{
		if($this->m_BuildOptions['modify_primary_detail_form']==0)
		{
			return ;
		}
		
		$pri_detail_form_file = $this->m_BuildOptions['primary_detail_form_name'];		
		
		$this->__upgradeDetailForm($pri_detail_form_file);
		
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		/*
		 *         
		<Element Name="fld_related_task"   
				TabSet="Extra Information"  
				Access="collab_task.access"  
				ElementSet="Task" 
				Class="FormElement" 
				FormReference="collab.task.widget.TaskListDetailForm" 
				FieldName="" 
				Label="" 
				AllowURLParam="N" />	
		 */
		//if specified add secondary read only list widget
		$secondary_name = $this->m_SecondaryModule['secondary_do_key_display'];
		$sec_display_name = ucwords($secondary_name);
		$sec_readonly_list_widget = $this->m_SecondaryModule['secondary_list_widget_ro'];
		if($sec_readonly_list_widget)
		{		
			//get $pri_module_access
			$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_readonly_list_widget);
			$widget_xml = new DOMDocument();		
			$widget_xml->preserveWhiteSpace = false;
			$widget_xml->formatOutput = true;
			$widget_xml->loadXML($xmlStr);
			$sec_module_access = $widget_xml->documentElement->attributes->getNamedItem("Access")->nodeValue;
		}
		$listElement = $xml->createElement("Element");
		$listElement->setAttribute("Name", 			"fld_related_".strtolower($secondary_name));		
		$listElement->setAttribute("TabSet",		"Related Data");
		$listElement->setAttribute("ElementSet",	$sec_display_name);
		$listElement->setAttribute("Class",			"FormElement");
		$listElement->setAttribute("FormReference", $this->__getObjName($sec_readonly_list_widget));
		$listElement->setAttribute("FieldName",		"");
		$listElement->setAttribute("Label",			"");
		$listElement->setAttribute("AllowURLParam",	"N");
		$listElement->setAttribute("Access",		$sec_module_access);
		
		
		/*
		 *         
		<Element Name="btn_manage_task"  
				TabSet="Extra Information"  
				Access="collab_task.access"  
				Hidden="{@:m_CanUpdateRecord=='1'?'N':'Y'}" 
				ElementSet="Task"  
				Style="color:#666666;margin-left:5px;margin-top:2px;"  
				Class="Button" 
				Text="Manage" 
				CssClass="button_gray_w" 
				Description="">
			<EventHandler Name="btn_manage_task_onclick" 
						Event="onclick" 
						Function="SwitchForm(collab.project.form.ProjectEditTaskForm,{@:Elem[fld_Id].Value})"   />
        </Element> 		
		 */
		//if specified add secondary management button for editable widget and form
		$sec_editable_list_widget = $this->m_SecondaryModule['secondary_list_widget_rw'];
		$pri_assoc_form_name = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($secondary_name))."Form", $this->__getObjName($pri_detail_form_file));
		$manageButton = $xml->createElement("Element");
		$manageButton->setAttribute("Name", 		"btn_manage_".strtolower($secondary_name));		
		$manageButton->setAttribute("Hidden",		"{@:m_CanUpdateRecord=='1'?'N':'Y'}");
		$manageButton->setAttribute("TabSet",		"Related Data");
		$manageButton->setAttribute("ElementSet",	$sec_display_name);
		$manageButton->setAttribute("Class",		"Button");
		$manageButton->setAttribute("CssClass",		"button_gray_w");
		$manageButton->setAttribute("Text",			"Manage");
		$manageButton->setAttribute("Style",		"color:#666666;margin-left:5px;margin-top:2px;");		
		$manageButton->setAttribute("Access",		$sec_module_access);
		
		$manageButtonClick = $xml->createElement("EventHandler");
		$manageButtonClick->setAttribute("Name", 		"btn_manage_".strtolower($secondary_name)."_onclick");		
		$manageButtonClick->setAttribute("Event",		"onclick");
		$manageButtonClick->setAttribute("Function",	"SwitchForm($pri_assoc_form_name,{@:Elem[fld_Id].Value})");		
		$manageButton->appendChild($manageButtonClick);
		
		
		//find best position to add new elements in detail form
		$foundPos = false;
		foreach($xml->getElementsByTagName("Element") as $node)
		{			
			if($node->attributes
					->getNamedItem("TabSet")
					->nodeValue == "Related Data")
			{
				$refNode = $node;
				$foundPos = true;
				break;
			}			
		}
		if(!$foundPos)
		{
			foreach($xml->getElementsByTagName("Element") as $node)
			{			
				if($node->attributes
						->getNamedItem("ElementSet")
						->nodeValue == "Miscellaneous")
				{
					$refNode = $node;
					$foundPos = true;
					break;
				}			
			}
		}
		//check if exists then ignore
		$nodeListExists = false;
		$nodeButtonExists = false;
		foreach($xml->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == "fld_related_".strtolower($secondary_name))
			{
				$nodeListExists = true ;				
			}
			if($node->attributes->getNamedItem("Name")->nodeValue == "btn_manage_".strtolower($secondary_name))
			{
				$nodeButtonExists = true ;				
			}
		}
			
		if(!$foundPos)
		{
			//append to data panel
			foreach($xml->getElementsByTagName("DataPanel") as $node)
			{
				if($sec_readonly_list_widget && !$nodeListExists)
				{
					$node->appendChild($listElement);
				}
				if($sec_editable_list_widget && !$nodeButtonExists)
				{
					$node->appendChild($manageButton);
				}
				break;
			}
		}
		else
		{
			//insert before ref node			
			if($sec_readonly_list_widget && !$nodeListExists)
			{
				$refNode->parentNode->insertBefore($listElement,$refNode);
			}
			if($sec_editable_list_widget && !$nodeButtonExists)
			{
				$refNode->parentNode->insertBefore($manageButton,$refNode);
			}
		}
		
		
		file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_detail_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['PriDetailForm']='/'.str_replace(MODULE_PATH,"",$pri_detail_form_file);
	}
	
	protected function _m2m_modifySecDetailForm()
	{
		if($this->m_BuildOptions['modify_secondary_detail_form']==0)
		{
			return ;
		}
		
		$sec_detail_form_file = $this->m_BuildOptions['secondary_detail_form_name'];		
		
		$this->__upgradeDetailForm($sec_detail_form_file);
		
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_detail_form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		/*       
		<Element Name="fld_related_task"   
				TabSet="Extra Information"  
				Access="collab_task.access"  
				ElementSet="Task" 
				Class="FormElement" 
				FormReference="collab.task.widget.TaskListDetailForm" 
				FieldName="" 
				Label="" 
				AllowURLParam="N" />	
		 */
		//if specified add secondary read only list widget
		$pri_readonly_list_widget = $this->m_PrimaryModule['primary_list_widget_ro'];
		$primary_name = $this->m_PrimaryModule['primary_do_key_display'];
		$pri_display_name = ucwords($primary_name);
		if($pri_readonly_list_widget){
			//get $pri_module_access
			$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$pri_readonly_list_widget);
			$widget_xml = new DOMDocument();		
			$widget_xml->preserveWhiteSpace = false;
			$widget_xml->formatOutput = true;
			$widget_xml->loadXML($xmlStr);
			$pri_module_access = $widget_xml->documentElement->attributes->getNamedItem("Access")->nodeValue;
		}
		
		$listElement = $xml->createElement("Element");
		$listElement->setAttribute("Name", 			"fld_related_".strtolower($primary_name));		
		$listElement->setAttribute("TabSet",		"Related Data");
		$listElement->setAttribute("ElementSet",	$pri_display_name);
		$listElement->setAttribute("Class",			"FormElement");
		$listElement->setAttribute("FormReference", $this->__getObjName($pri_readonly_list_widget));
		$listElement->setAttribute("FieldName",		"");
		$listElement->setAttribute("Label",			"");
		$listElement->setAttribute("AllowURLParam",	"N");
		$listElement->setAttribute("Access",		$pri_module_access);
		
		
		/*
		<Element Name="btn_manage_task"  
				TabSet="Extra Information"  
				Access="collab_task.access"  
				Hidden="{@:m_CanUpdateRecord=='1'?'N':'Y'}" 
				ElementSet="Task"  
				Style="color:#666666;margin-left:5px;margin-top:2px;"  
				Class="Button" 
				Text="Manage" 
				CssClass="button_gray_w" 
				Description="">
			<EventHandler Name="btn_manage_task_onclick" 
						Event="onclick" 
						Function="SwitchForm(collab.project.form.ProjectEditTaskForm,{@:Elem[fld_Id].Value})"   />
        </Element> 		
		 */
		//if specified add secondary management button for editable widget and form
		$pri_editable_list_widget = $this->m_SecondaryModule['secondary_list_widget_rw'];
		$sec_assoc_form_name = str_replace("DetailForm", "Edit".str_replace(" ", "", ucwords($primary_name))."Form", $this->__getObjName($sec_detail_form_file));
		$manageButton = $xml->createElement("Element");
		$manageButton->setAttribute("Name", 		"btn_manage_".strtolower($primary_name));		
		$manageButton->setAttribute("Hidden",		"{@:m_CanUpdateRecord=='1'?'N':'Y'}");
		$manageButton->setAttribute("TabSet",		"Related Data");
		$manageButton->setAttribute("ElementSet",	$pri_display_name);
		$manageButton->setAttribute("Class",		"Button");
		$manageButton->setAttribute("CssClass",		"button_gray_w");
		$manageButton->setAttribute("Text",			"Manage");
		$manageButton->setAttribute("Style",		"color:#666666;margin-left:5px;margin-top:2px;");		
		$manageButton->setAttribute("Access",		$pri_module_access);
		
		$manageButtonClick = $xml->createElement("EventHandler");
		$manageButtonClick->setAttribute("Name", 		"btn_manage_".strtolower($primary_name)."_onclick");		
		$manageButtonClick->setAttribute("Event",		"onclick");
		$manageButtonClick->setAttribute("Function",	"SwitchForm($sec_assoc_form_name,{@:Elem[fld_Id].Value})");		
		$manageButton->appendChild($manageButtonClick);
		
		
		//find best position to add new elements in detail form
		$foundPos = false;
		foreach($xml->getElementsByTagName("Element") as $node)
		{			
			if($node->attributes
					->getNamedItem("TabSet")
					->nodeValue == "Related Data")
			{
				$refNode = $node;
				$foundPos = true;
				break;
			}			
		}
		if(!$foundPos)
		{
			foreach($xml->getElementsByTagName("Element") as $node)
			{			
				if($node->attributes
						->getNamedItem("ElementSet")
						->nodeValue == "Miscellaneous")
				{
					$refNode = $node;
					$foundPos = true;
					break;
				}			
			}
		}
		//check if exists then ignore
		$nodeListExists = false;
		$nodeButtonExists = false;
		foreach($xml->getElementsByTagName("Element") as $node)
		{
			if($node->attributes->getNamedItem("Name")->nodeValue == "fld_related_".strtolower($primary_name))
			{
				$nodeListExists = true ;				
			}
			if($node->attributes->getNamedItem("Name")->nodeValue == "btn_manage_".strtolower($primary_name))
			{
				$nodeButtonExists = true ;				
			}
		}
			
		if(!$foundPos)
		{
			//append to data panel
			foreach($xml->getElementsByTagName("DataPanel") as $node)
			{
				if($pri_readonly_list_widget && !$nodeListExists)
				{
					$node->appendChild($listElement);
				}
				if($pri_editable_list_widget && !$nodeButtonExists)
				{
					$node->appendChild($manageButton);
				}
				break;
			}
		}
		else
		{
			//insert before ref node			
			if($pri_readonly_list_widget && !$nodeListExists)
			{
				$refNode->parentNode->insertBefore($listElement,$refNode);
			}
			if($pri_editable_list_widget && !$nodeButtonExists)
			{
				$refNode->parentNode->insertBefore($manageButton,$refNode);
			}
		}
		
		
		file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$sec_detail_form_file, $xml->saveXML());
		$this->m_GeneratedFiles['FormObjFiles']['SecDetailForm']='/'.str_replace(MODULE_PATH,"",$sec_detail_form_file);
	}
	
	protected function __upgradeDetailForm($form_file)
	{
		
		$xmlStr = file_get_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$form_file);
		$xml = new DOMDocument();		
		$xml->preserveWhiteSpace = false;
		$xml->formatOutput = true;
		$xml->loadXML($xmlStr);
		
		$easyformElem = $xml->documentElement;
		$templateFile = $easyformElem->attributes->getNamedItem("TemplateFile")->nodeValue;
		// change detail form template 		 
		switch($templateFile)
		{
			case "form_detail.tpl.html":
				//upgrade to adv element set
				$xml->documentElement
					->attributes
					->getNamedItem("TemplateFile")
					->nodeValue = "form_detail_adv.tpl.html";
				
				/*
				 * Create a new form_title element
				 * Clone a new description element with MaxLength limit
				    <Element Name="fld_form_title" style="font-size:24px;color:#333333;line-height:24px;"  ElementSet="" Class="LabelText" FieldName="name" Label="Name" AllowURLParam="N"/>
    				<Element Name="fld_form_description" BackgroundColor="bef0fd" MaxLength="4" ElementSet="General" Class="LabelTextarea" FieldName="description" Label="Description" AllowURLParam="N"/>
				 */
				foreach($xml->getElementsByTagName("DataPanel")->item(0)->getElementsByTagName("Element") as $node)
				{
					if($node->attributes->getNamedItem("Class")->nodeValue=='LabelText' && 
						strtoupper($node->attributes->getNamedItem("Hidden")->nodeValue)!='Y'){
							$form_title_node = $node;
							$form_desc_node = $node->nextSibling->cloneNode();							
							break;
						}
				}
				$form_title_node->setAttribute("Name","fld_form_title");
				$form_title_node->setAttribute("ElementSet","");
				$form_title_node->setAttribute("Class","LabelText");
				$form_title_node->setAttribute("Style","font-size:24px;color:#333333;line-height:24px;");
				
				$form_desc_node->setAttribute("Name","fld_form_description");
				$form_desc_node->setAttribute("ElementSet","");
				$form_desc_node->setAttribute("Class","LabelText");
				$form_desc_node->setAttribute("BackgroundColor","bef0fd");
				$form_desc_node->setAttribute("MaxLength","15");
				
				$form_title_node->parentNode->insertBefore($form_desc_node,$form_title_node->nextSibling);
				break;
				
			case "form_detail_adv_custom.tpl.html":
			default:
				//not changing
				break;
		}
		
		return file_put_contents(MODULE_PATH.DIRECTORY_SEPARATOR.$form_file, $xml->saveXML());
	}
	
	/* shared common methods below */
	private function __modifyInstallSQL($sql , $mod)
	{
	 	$targetPath = MODULE_PATH . "/" . str_replace(".", "/", $mod) ;       
        $targetFile = $targetPath . "/mod.install.sql";
        
		if(is_file($targetFile)){
			$content = file_get_contents($targetFile);
		}
				
		$sql = trim($sql);
		$content .= "\n\n$sql\n";
		return file_put_contents($targetFile, $content);
	}
	
	private function __getMetaTempPath()
	{
		$this->m_MetaTempPath = MODULE_PATH.DIRECTORY_SEPARATOR.'appbuilder'.
											DIRECTORY_SEPARATOR.'resource'.
											DIRECTORY_SEPARATOR.'module_template';
		return $this->m_MetaTempPath; 
	}
	
	private function __getObjName($obj_file)
	{
		$obj_name = str_replace(".xml", "", $obj_file);
		$obj_name = str_replace("/", ".", $obj_name);
		return $obj_name;
	}
	
	private function __getObjFile($obj_name)
	{
		$obj_file = str_replace(".", "/", $obj_name);
		$obj_file = str_replace("/xml", ".xml", $obj_file);
		if(!preg_match("/\.xml$/",$obj_file))
		{
			$obj_file.=".xml";
		}
		$obj_file = MODULE_PATH.DIRECTORY_SEPARATOR.$obj_file;
		return $obj_file;
	}	
}
?>