<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.lib
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id: MetadataXMLUtil.php 531 2012-12-19 06:42:00Z jixian $
 */

class MetadataXMLUtil
{ 
    protected $m_MetaFile;
    protected $m_ElemName;
    protected $m_AttrName;
	protected $m_PrtElemName;
    protected $m_PrtAttrName;
    protected $m_XmlFile;
    protected $m_Doc;
	
	public function __construct($metaFile)
	{
		$this->m_MetaFile = $metaFile;
	}
	
	public function setCurrentElement($elemName, $elemNameValue, $prtElemName, $prtElemNameValue)
	{
		$this->m_ElemName = $elemName;
		$this->m_AttrName = $elemNameValue;
		$this->m_PrtElemName = $prtElemName;
		$this->m_PrtAttrName = $prtElemNameValue;
	}
    
    public function getCurrentElement()
    {
		if ($this->m_PrtElemName) {
			$xpathStr = '//'.$this->m_PrtElemName;
			if ($this->m_PrtAttrName) $xpathStr .= '[@Name="'.$this->m_PrtAttrName.'"]';
			$xpathStr .= '/'.$this->m_ElemName.'[@Name="'.$this->m_AttrName.'"]';
		}
		else {
			$xpathStr = '//'.$this->m_ElemName.'[@Name="'.$this->m_AttrName.'"]';
		}
		//$xpathStr = '//'.$this->m_ElemName.'[@Name="'.$this->m_AttrName.'"]';
        $elem = $this->QueryXpath($xpathStr);
        return $elem;
    }
    
    public function GetMetaFileInfo()
    {
    	$pos = strrpos($this->m_MetaFile, "modules/");
        if ($pos > 0)
        {
            $modulesPath = substr($this->m_MetaFile, 0, $pos+8);
            $pos = strrpos($this->m_MetaFile, "/");
            $fileName = substr($this->m_MetaFile, $pos+1);
            $package = str_replace("/",".",str_replace(array($modulesPath, "/".$fileName),"",$this->m_MetaFile));
            return array('modules_path'=>$modulesPath, 'package'=>$package, 'fileName'=>$fileName);
        }
        return null;
    }
    
    public function QueryXpath($xpathStr, $returnSingle=true)
    {
        $doc = $this->GetDocDocument();
        if (!$doc) return false;
        
        $xpath = new DOMXPath($doc);
        $elems = $xpath->query($xpathStr);
        if ($returnSingle)
        {
            $elem = $elems->item(0);
            return $elem;
        }
        return $elems;
    }
    
    public function GetDocDocument()
    {
        if ($this->m_Doc) 
            return $this->m_Doc;
        //$this->m_XmlFile = MODULE_PATH."/".str_replace(".","/",$this->m_MetaName).".xml";
        $this->m_XmlFile = $this->m_MetaFile;

        if (!file_exists($this->m_XmlFile)) 
            return null;
        $doc = new DomDocument();
        $ok = $doc->load($this->m_XmlFile);
        if (!$ok)
            return null;
        $this->m_Doc = $doc;
        //$rootElem = $doc->documentElement;
        return $doc;
    }
    
    public function addElement($recArr, $prtElemName, $prtAttrName)
    {
        $doc = $this->GetDocDocument();
        if (!$doc) return false;
		
		// get parent element
		$xpath = new DOMXPath($doc);
		$xpathStr = '//'.$prtElemName;
		if (!empty($prtAttrName)) {
			$xpathStr .= '[@Name="'.$prtAttrName.'"]';
		}
        $prtElems = $xpath->query($xpathStr);
        $prtElem = $prtElems->item(0);
		
		// if the new element has Name attribute, verify the parent node doesn't have a node with same name value
		if (isset($recArr['Name']) && !empty($recArr['Name'])) {
			foreach ($prtElem->childNodes as $chld) {
				if ($chld->nodeType != XML_ELEMENT_NODE) continue;
				if ($chld->getAttribute("Name") == $recArr['Name']) {
					throw new Exception("Unable to create an element with Name as ".$recArr['Name']);
					return false;
				}
			}
		}
		
		// create an element
        $elem = $doc->createElement($this->m_ElemName);
		// set input attributes
        foreach ($recArr as $name => $value)
        {
            if ($value!="") {
        		$elem->setAttribute($name, $value);
            }
        }
        $prtElem->appendChild($elem);
        
        // save xml file
        $doc->formatOutput = true;
        $doc->save($this->m_XmlFile);
		file_put_contents($this->m_XmlFile, xmlpp(file_get_contents($this->m_XmlFile)));
        return true;
    }
    
    public function removeElement()
    {
        $doc = $this->GetDocDocument();
        if (!$doc) return false;
		
		$elem = $this->getCurrentElement();
		if (!$elem) return false;
            
        // get the parent element
        $prtElem = $elem->parentNode;
        $prtElem->removeChild($elem);
        
        // save xml file
        $doc->formatOutput = true;
        $doc->save($this->m_XmlFile);
		file_put_contents($this->m_XmlFile, xmlpp(file_get_contents($this->m_XmlFile)));
        return true;
    }
    
    public function moveElement($elemPath, $nameVal1, $nameVal2, $insertMode)
    {
        $doc = $this->GetDocDocument();
        if (!$doc) return false;
        
        //echo "$elemPath, $nameVal1, $nameVal2, $insertMode";
        
        $xpath = new DOMXPath($doc);
        $xpathStr = "//".$elemPath.'[@Name="'.$nameVal1.'"]'; 
        $elems = $xpath->query($xpathStr);
        $elem = $elems->item(0);
        
        $xpathStr = "//".$elemPath.'[@Name="'.$nameVal2.'"]';
        $elems = $xpath->query($xpathStr);
        $elemRef = $elems->item(0);
        
        if($insertMode == "before") 
        {
            $elemRef->parentNode->insertBefore($elem, $elemRef);
        } 
        else if($insertMode == "after") 
        {   
            if($elemRef->nextSibling) 
                $elemRef->parentNode->insertBefore($elem, $elemRef->nextSibling);
            else 
                $elemRef->parentNode->appendChild($elem);
        }
        
        // save xml file
        $doc->formatOutput = true;
        $doc->save($this->m_XmlFile);
		file_put_contents($this->m_XmlFile, xmlpp(file_get_contents($this->m_XmlFile)));
        return true;
    }
    
    public function saveElement($recArr)
    {
        $doc = $this->GetDocDocument();
        if (!$doc) { 
        	echo "Cannot get xml doc. Please reload the page in your browser";
        	return false; 
        }
        
        /*$xpath = new DOMXPath($doc);
        $xpathStr = '//'.$this->m_ElemName.'[@Name="'.$this->m_AttrName.'"]';
        $elems = $xpath->query($xpathStr);
        $elem = $elems->item(0);*/
		$elem = $this->getCurrentElement();
        
        // collect all attributes
        foreach ($elem->attributes as $attrName => $attrNode)
            $attrs[] = $attrName;
		// clean all attributes
        // we need this feature for erase an attribute
        foreach ($attrs as $attr)
            $elem->removeAttribute($attr);

        // set input attributes
        foreach ($recArr as $name => $value)
        {
            if (in_array($recArr, $attrs) || $value!="") {        	
        		$elem->setAttribute($name, $value);
            }
        }
        
        // save xml file
        $doc->formatOutput = true;
        $doc->save($this->m_XmlFile);
        file_put_contents($this->m_XmlFile, xmlpp(file_get_contents($this->m_XmlFile)));
        return true;
    }
	
	// replace [@abc] with [@Name='abc']
    private function adjustElemPath($path)
    {
        $list = explode('/',$path);
        foreach ($list as $elem) 
        {
            $pattern = "/([a-zA-Z_0-9]+)\[@([a-zA-Z_0-9\-]+)\]/i";
            $replace = "$1[@Name='$2']";
            $list2[] = preg_replace($pattern, $replace, $elem);
        }
        return implode('/',$list2);
    }
}

/** Prettifies an XML string into a human-readable and indented work of art 
 *  @param string $xml The XML as a string 
 *  @param boolean $html_output True if the output should be escaped (for use in HTML) 
 *  http://gdatatips.blogspot.com/2008/11/xml-php-pretty-printer.html, Apache 2.0 License.
 */  
function xmlpp($xml, $html_output=false) {  
    $xml_obj = new SimpleXMLElement($xml);  
    $level = 4;  
    $indent = 0; // current indentation level  
    $pretty = array();  
      
    // get an array containing each XML element  
    $xml = explode("\n", preg_replace('/>\s*</', ">\n<", $xml_obj->asXML()));  
  
    // shift off opening XML tag if present  
    if (count($xml) && preg_match('/^<\?\s*xml/', $xml[0])) {  
      $pretty[] = array_shift($xml);  
    }  
  
    foreach ($xml as $el) {  
      if (preg_match('/^<([\w])+[^>\/]*>$/U', $el)) {  
          // opening tag, increase indent  
          $pretty[] = str_repeat(' ', $indent) . $el;  
          $indent += $level;  
      } else {  
        if (preg_match('/^<\/.+>$/', $el)) {              
          $indent -= $level;  // closing tag, decrease indent  
        }  
        if ($indent < 0) {  
          $indent += $level;  
        }  
        $pretty[] = str_repeat(' ', $indent) . $el;  
      }  
    }     
    $xml = implode("\n", $pretty);     
    return ($html_output) ? htmlentities($xml) : $xml;  
}  
?>