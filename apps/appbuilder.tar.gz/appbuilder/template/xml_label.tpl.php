<?php $name = $this->formname; ?>
<form id="<?php echo $name;?>" name="<?php echo $name;?>">
<div class="menu_title" style="margin-bottom:0px;">
<h2 style="width:105px;overflow:hidden;" ><?php 
	$attrs = $this->form['rootNode']->attributes();
	$elemName = $this->form['rootNode']->getName();
	$title = $attrs['Name']." ";
	echo $title;?>
</h2>
<p style="float:right;display:block;padding-top:4px;">
	<span style="display: block;float: left;"><a href="<?php echo APP_INDEX; ?>/appbuilder/xml_edit/metaobj=<?php  echo $_REQUEST['metaobj']; ?>" class="menu_index_link"><?php echo $this->form['formobj']->getMessage('STR_DESIGN'); ?></a></span> 
	<a href="<?php echo APP_INDEX; ?>/appbuilder/xml_edit/metaobj=<?php echo $_REQUEST['metaobj']; ?>"><img border="0" src="/themes/default/images/spacer.gif" class="btn_design" ></a>
</p>
</div>
<p style="margin-left: 15px;padding-top:5px;margin-right: 20px; text-align:left;">
<label style="color: #149BC8;float:none;text-align:left;"><?php echo $this->form['formobj']->getMessage('LABEL_OBJECT'); ?></label>
<span style="display:block;padding-left:5px;width:165px;overflow:hidden"><?php echo $_REQUEST['metaobj']; ?></span>

<label style="color: #149BC8;float:none;text-align:left;"><?php echo $this->form['formobj']->getMessage('LABEL_MODIFICATION'); ?></label>
<span style="display:block;padding-left:5px;"><?php echo $this->form['modification_time']; ?></span>
<label style="color: #149BC8;float:none;text-align:left;"><?php echo $this->form['formobj']->getMessage('LABEL_FILESIZE'); ?></label>
<span style="display:block;padding-left:5px;"><?php echo $this->form['filesize_h']; ?></span>
</p>
</form>