<?php $name = $this->formname; ?>

<script language="JavaScript">
 minus = new Image();
 minus.src = "<?php echo Resource::GetImageUrl()?>/minus.gif";
 plus = new Image();
 plus.src = "<?php echo Resource::GetImageUrl()?>/plus.gif";
</script>

<form id="<?php echo $name;?>" name="<?php echo $name;?>">
<div class="menu_title">
<h2 style="width:105px;overflow:hidden;" ><?php 
	$attrs = $this->form['rootNode']->attributes();
	$elemName = $this->form['rootNode']->getName();
	$title = $attrs['Name']." ";
	echo $title;?>
</h2>
<p style="float:right;display:block;padding-top:4px;">
	<span style="display: block;float: left;"><a href="<?php echo APP_INDEX; ?>/appbuilder/source_edit/metaobj=<?php  echo $_REQUEST['metaobj']; ?>" class="menu_index_link"><?php echo $this->form['formobj']->getMessage('STR_SOURCE'); ?></a></span> 
	<a href="<?php echo APP_INDEX; ?>/appbuilder/code_edit/metaobj=<?php echo $_REQUEST['metaobj']; ?>"><img border="0" src="/themes/default/images/spacer.gif" class="btn_source" ></a>
</p>
</div>
<input type="hidden" name="metaobj" value="<?php echo $this->form['metaobj'];?>"/>
<div  class="toplevel" style="width:180px; overflow:hidden; clear:both">
<table cellspacing="0" cellpadding="2" >

<tr>
<td colspan="9">
   <div id="<?php echo $name?>_data">
   <div id="<?php echo str_replace('.','_',$name)?>_tree" >
	<ul style="width:180px;">
        <?php 
        	$formType = strtolower((string)$attrs->FormType);
            displayElement($this->form['rootNode'], $formType, true);
        ?>
	</ul>
    </div>

   </div>
</td>
</tr>

<tr>
<td  align="left" >
    <?php if (is_array($this->actionPanel)) :?>
     <div style="padding:0px;margin:0px;border-top:1px solid #D6D6D6;width:100%;padding-top:5px;margin-top:3px;padding-left:3px;">
   		 
		   <?php foreach ($this->actionPanel as $elem ): ?>
		     <?php echo $elem['element']?>
		   <?php endforeach; ?>
	 </div>
	<div id="<?php echo $name?>.load_disp" style="display:none"></div>
   <?php endif;?>
   
</td>
</tr>

</table>
</div>
</form>

<?php 
	$rules = getTreeRules($this->form['rootNode']);
?>

<script>
deletableList = [ <?php echo $rules['deletable']?> ];
createableList = [ <?php echo $rules['creatable']?> ];
draggableList = [ <?php echo $rules['draggable']?> ];
dragrulesList = [ <?php echo $rules['dragrules']?> ];
$j(function () {
	$j("#<?php echo str_replace('.','_',$name)?>_tree").tree({
	    ui : {
	        theme_name : "classic",
			context: false
	    },
	    rules : {
			droppable : [ "tree-drop" ],
            multiple : true,
            deletable : deletableList,
            renameable : "none",
			creatable : createableList,
            draggable : draggableList,
            dragrules : dragrulesList,
            drag_button : "left"
        },
        lang : {
			new_node: "New item",
			loading	: "Loading ..."
		},
        callback : {
            onselect : function(n,t) { 
				elemName = n.getAttribute('rel');
				// if this element is creatable, enable the 'add' button
				if (createableList.indexOf(elemName)>=0) $j('#btn_add').show();
				else $j('#btn_add').hide();
				// if this element is deletable, enable the 'delete' button
				if (deletableList.indexOf(elemName)>=0) $j('#btn_del').show();
				else $j('#btn_del').hide();
				attrNameValue = n.id;
				prtNode = getParentElement(n);
				elemName2 = prtNode ? prtNode.attr('rel') : "";
				attrNameValue2 = prtNode ? prtNode.attr('id') : "";
				Openbiz.CallFunction("<?php echo $name;?>.selectRecord("+elemName+","+attrNameValue+","+elemName2+","+attrNameValue2+")");
            },
			// beforedelete, beforecreate, oncreate, onmove
			onmove : function (n, r, type, t) {
			    // set pending new element, parent element and name attribute
			    //alert("Movie "+n.id+" to "+r.id);
			    //t.select_branch(n);
				elemName = n.getAttribute('rel');
				attrNameValue = n.id;
				elemName2 = r.getAttribute('rel');
				attrNameValue2 = r.id;
				Openbiz.CallFunction("<?php echo $name;?>.moveElement("+elemName+","+attrNameValue+","+attrNameValue2+","+type+")");
			}
        }
	});
});

function loadNewElementForm(formName)
{
	xmltree = $j.tree_focused();
	n = xmltree.selected;
	elemName = n.attr('rel');
	attrNameValue = n.attr('id');
	Openbiz.CallFunction("<?php echo $name;?>.loadNewElementForm("+formName+","+elemName+","+attrNameValue+")");
}

function deleteElement()
{
	xmltree = $j.tree_focused();
	n = xmltree.selected;
	elemName = n.attr('rel');
	attrNameValue = n.attr('id');
	ok = confirm("Are you sure you want to delete '"+elemName+":"+attrNameValue+"'?");
	if (ok) {
		prtNode = getParentElement(n);
		elemName2 = prtNode ? prtNode.attr('rel') : "";
		attrNameValue2 = prtNode ? prtNode.attr('id') : "";
		Openbiz.CallFunction("<?php echo $name;?>.deleteElement("+elemName+","+attrNameValue+","+elemName2+","+attrNameValue2+")");
	}
}

// addElement(elem_namevalue, elem_type, elem_namevalue)
function addElement(id, rel, text)
{
	xmltree = $j.tree_focused();
	newobj = xmltree.create({data:text,attributes:{id:id,rel:rel,class:rel}});
	xmltree.select_branch(newobj);
}
function renameElement(id, rel, text)
{
	xmltree = $j.tree_focused();
	oldObj = xmltree.selected;	
	newobj = xmltree.create({data:text,attributes:{id:id,rel:rel}},oldObj,'before');
	xmltree.remove(oldObj);
	xmltree.select_branch(newobj);
}
// remove current selected element
function removeElement()
{
	xmltree = $j.tree_focused();
	newobj = xmltree.remove(xmltree.selected);
}
// 
function getParentElement(n)
{
	xmltree = $j.tree_focused();
	node = xmltree.get_node(n);
    prtNode = xmltree.parent(node);
	return prtNode;
}
</script>


<?php
// helper function here
function displayElement($elem, $formType, $isRoot=false)
{
	
	$attrs = $elem->attributes();
	$elemName = $elem->getName();
	$name = $attrs['Name'];
	$text = ($name)&&($name!="") ? "$name" : "$elemName";
	
	if($formType != 'list' && ($text=='NavPanel' || $text=='SearchPanel') )
	{
		return;
	}

	if ($isRoot)
		echo "<li id=\"$name\" class=\"open $elemName\" rel=\"$elemName\" title=\"$text\"><a href=\"#\">$text</a>\n";
	else
		echo "<li id=\"$name\" class=\"$elemName\" rel=\"$elemName\" title=\"$text\"><a href=\"#\">$text</a>\n"; 	
	$children = $elem->children();
	if ($children && count($children)>0)
	{
		echo "<ul>\n";
		foreach ($children as $chld)
		{
			displayElement($chld,$formType);
		}
		echo "</ul>\n";
	}
	echo "</li>\n";
}

function getTreeRules($rootElem)
{
	$metaType = $rootElem->getName();
	$rules = array();
	switch ($metaType)
	{
		case "EasyForm" :
			$rules['deletable'] = '"Element", "EventHandler"';
			$rules['clickable'] = '"EasyForm", "Element", "EventHandler"';
			$rules['creatable'] = '"DataPanel", "SearchPanel", "ActionPanel", "NavPanel", "Element"';
			$rules['draggable'] = '"Element", "EventHandler"';
			$rules['dragrules'] = '"Element * Element", "EventHandler * EventHandler"';
			break;
		case "EasyView" :
			$rules['deletable'] = '"Reference"';
			$rules['clickable'] = '"EasyView", "Reference"';
			$rules['creatable'] = '"FormReferences"';
			$rules['draggable'] = '"Reference"';
			$rules['dragrules'] = '"Reference * Reference"';
			break;
		case "BizDataObj" :
			$rules['deletable'] = '"BizField", "Join", "Object"';
			$rules['clickable'] = '"BizDataObj", "BizField", "Join", "Object"';
			$rules['creatable'] = '"BizFieldList", "TableJoins", "ObjReferences"';
			$rules['draggable'] = '"BizField", "Join", "Object"';
			$rules['dragrules'] = '"BizField * BizField", "Join * Join", "Object * Object"';
			break;
		case "ETL" :
			$rules['deletable'] = '"Database", "Queue", "Task", "Transform"';
			$rules['clickable'] = '"Database", "Queue", "Task", "Transform"';
			$rules['creatable'] = '"DataSource", "Queue", "Task"';
			$rules['draggable'] = '"Task", "Transform"';
			$rules['dragrules'] = '"Task * Task", "Transform * Transform"';
			break;
	}
	return $rules;
}
?>