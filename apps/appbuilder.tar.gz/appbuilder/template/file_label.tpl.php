<?php $name = $this->formname; ?>
<form id="<?php echo $name;?>" name="<?php echo $name;?>">
<div class="menu_title" style="margin-bottom:0px;">
<h2 style="width:170px;overflow:hidden;" ><?php 	
echo $this->form['filename'];
	?>
</h2>

</div>
<p style="margin-left: 15px;padding-top:5px;margin-right: 20px; text-align:left;">
<label style="color: #149BC8;float:none;text-align:left;"><?php echo $this->form['formobj']->getMessage('LABEL_FILE'); ?></label>
<span style="display:block;padding-left:5px;width:165px;overflow:hidden"><?php echo '/'.$this->form['filename_full']; ?></span>

<label style="color: #149BC8;float:none;text-align:left;"><?php echo $this->form['formobj']->getMessage('LABEL_MODIFICATION'); ?></label>
<span style="display:block;padding-left:5px;"><?php echo $this->form['modification_time']; ?></span>

<label style="color: #149BC8;float:none;text-align:left;"><?php echo $this->form['formobj']->getMessage('LABEL_FILESIZE'); ?></label>
<span style="display:block;padding-left:5px;"><?php echo $this->form['filesize_h']; ?></span>
</p>
</form>