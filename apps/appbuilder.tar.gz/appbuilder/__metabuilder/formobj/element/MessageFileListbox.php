<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class MessageFileListbox extends Listbox
{	
	public function getFromList(&$list, $selectFrom=null)
	{
		$fileOption = $this->getFormObj()->getViewObject()->getFileOption();
		$module = $fileOption['module'];
				
		$files = BizSystem::getObject("appbuilder.lib.MetadataService")->listMessages($module);		
		foreach($files as $file)
		{
			$file_value = basename($file);
			$file_display = str_replace($module,"",$file);
			
			$list[] = array(
				'val'	=>	$file_value,
				'txt'	=>	$file_display	
			);			
		}
		
	}
	

}
?>