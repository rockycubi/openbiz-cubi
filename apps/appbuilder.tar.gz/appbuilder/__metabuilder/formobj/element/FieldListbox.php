<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.formobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FieldListbox extends Listbox
{	
	
	public function getFromList(&$list, $selectFrom=null)
	{	

		$obj = $this->getFormObj()->getElement("fld_dataobj")->getValue();
		if(!$obj)
		{
			return;
		}
		$do = BizSystem::getObject($obj);
		$fieldList = $do->m_BizRecord;
		
		foreach($fieldList as $field)
		{	
			
			$list[] = array(
				'val'	=>	$field->m_Name,
				'txt'	=>	$field->m_Name.' - '.$field->m_Column.''
			);			
		}
		
	}

}
?>