<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class AttributesWizardForm extends EasyFormWizard
{
	public $m_DOName;
	public $m_ModuleName;
	
	public function fetchData()
	{
		$result = parent::fetchData();
		$fileOption = $this->getViewObject()->getFileOption();
		$this->m_DOName = $fileOption['do_name'];
		$this->m_ModuleName = $fileOption['module'];
		return $result;
	}

	public function goSkipNext($commit=false)
	{	
        // call ValidateForm()
        $recArr = $this->readInputRecord();
        $this->setActiveRecord($recArr);
    	
   		 try
        {
             if ($this->ValidateForm() == false)
            return;
        }catch (ValidationException $e)
        {
            $this->processFormObjError($e->m_Errors);
            return;
        }

        $this->m_ActiveRecord = $this->readInputRecord();
		$viewObj = $this->getViewObject();
        // get the step
    	if($viewObj->getCurrentStep()){
        	$step = $viewObj->getCurrentStep();
        }else{
        	$step = $_GET['step'];
        }
        if (!$step || $step=="")
            $step=1;

        // redirect the prev step
        /* @var $viewObj EasyViewWizard */
        $this->preloadFields();
        
        $viewObj->renderStep($step+2);
	}		
	
	public function goNext($commit=false)
	{
		$this->preloadFields();
		return parent::goNext($commit);
	}
	
	public function preloadFields()
	{
		$fieldListForm = BizSystem::getObject("appbuilder.metabuilder.dataobj.form.FieldListWizardForm");
		if($fieldListForm->m_FieldListAutoload)
		{
			return;
		}
		$rec = $this->readInputRecord();
		$dbName 	= $rec['DBName'];
		$dbTable 	= $rec['Table'];
		
		foreach($this->getColumns($dbName, $dbTable) as $fieldRec)
		{
			/*<BizField Name="type_id" Description="Type Id" Column="type_id" Required="N"/>*/
			if($fieldRec['Null']=='YES')
			{
				$required="N";
			}
			else
			{
				$required="Y";
			}
			
			$fieldName = $fieldRec['Field'];
			$valueOnCreate = "";
			$valueOnUpdate = "";			
			$type="Text";
			
			if(substr($fieldRec['Type'],0,3)=='int')
			{
				$type="Number";
			}
			elseif($fieldRec['Type']=='datetime')
			{
				$type="Datetime";				
			}
			elseif($fieldRec['Type']=='date')
			{
				$type="Date";
			}
			
			switch($fieldRec['Field'])
			{
				case "id":
					$fieldName = 'Id';
					$valueOnCreate = "";
					$valueOnUpdate = "";
					break;
				case "update_by":
					$valueOnCreate = "{@profile:Id}";					
				case "create_by":					
					$valueOnUpdate = "{@profile:Id}";
					break;
					
				case "update_time":							
					$valueOnCreate = "{date('Y-m-d H:i:s')}";
				case "create_time":								
					$valueOnUpdate = "{date('Y-m-d H:i:s')}";
					break;	
				
				case "owner_id":								
					$valueOnCreate = "{@profile:Id}";
					break;
				case "group_id":							
					$valueOnCreate = "{@profile:default_group}";
					break;
				case "group_perm":							
					$valueOnCreate = "{BizSystem::GetDefaultPerm(group)}";
					break;
				case "other_perm":								
					$valueOnCreate = "{BizSystem::GetDefaultPerm(other)}";
					break;														
			}
			
			$fieldArr = array(
				"Id" => $fieldName,
				"Name" => $fieldName,
				"Column" => $fieldRec['Field'],
				"Description" => "Data Column ".$fieldRec['Field'],
				"SQLExpr" => "",
				"Join" => "",
				"Alias" => "",
				"Format" => "",
				"Encrypted" => "N",				
				"Required" => $required,
				"Type" => $type,
				"ValueOnCreate" => $valueOnCreate,
				"ValueOnUpdate" => $valueOnUpdate,
			);
			$fieldListArr[] = $fieldArr;
		}
		
		$fieldListForm->m_FieldList = $fieldListArr;
	}
	
	protected function getColumns($dbName,$dbTable)
	{
		$db = BizSystem::instance()->getDBConnection($dbName);
		$fieldList = $db->fetchAssoc("SHOW FULL COLUMNS FROM `$dbTable`");
    	return $fieldList;
	}
	
	public function getDefaultDesc()
	{
		$fileOption = $this->getViewObject()->getFileOption();
		$fileOption['do_name'] = str_replace("DO","",$fileOption['do_name']);
		$desc = trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $fileOption['do_name']));
		return $desc;
	}
}
?>