<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ObjectReferenceForm extends EasyFormWizard
{
	public $m_DOName;
	public $m_BaseTable;
	public $m_ParentFormName = "appbuilder.metabuilder.dataobj.form.ObjectReferenceListWizardForm";
	
	
	public function fetchData()
	{		
		$fileOption = $this->getViewObject()->getFileOption();
		$attrs = $this->getViewObject()->getAttributes();
		
		$this->m_DOName = $fileOption['do_name'];

		$this->m_BaseTable = $attrs['Table'];
		
		$prtForm = BizSystem::getObject($this->m_ParentFormName);
		
        if (strtoupper($this->m_FormType) == "NEW")
        {
            $result =  $this->getNewRecord();
        }
        else
        {        	           					
			$recordId = $this->m_RecordId;		
			$recordSet = $prtForm->getRecordList();			
			if(is_array($recordSet))
			{
				foreach($recordSet as $key=>$data)
				{
					if($data['Id']==$recordId)
					{
						$result = $data;
						break;
					}
				}
			}
        }
			
		return $result;
	}
	
	public function updateRecord()
	{
		//validate the value exists or not
        $currentRec = $this->fetchData();
        $recArr = $this->readInputRecord();
		$rec = $this->readInputRecord();
		
		if(!$rec['Name'])
		{
			$this->m_Errors = array(
				"fld_name" => $this->getMessage("OBJECT_REFERENCE_IS_REQUIRED"),
			);
			$this->rerender();
			return ;
		}
		
		$valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
		if(is_array($valueSetData)){
			foreach($valueSetData as $key=>$data)
			{
				if(strtolower($data['Name'])==strtolower($rec['Name']))
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_name" => $this->getMessage("OBJECT_REFERENCE_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}
		//save value
		$rec['Id'] 		= $rec['Name'];
		$prtForm = BizSystem::getObject($this->m_ParentFormName);		
		$prtForm->updateObjectReferenceRecord($rec,$currentRec['Id']);

		$this->m_ActiveRecord = null;
		$this->processPostAction();
		return $result;		
	}
	
	public function insertRecord()
	{
		//validate the value exists or not
		$rec = $this->readInputRecord();
		
			
		if(!$rec['Name'])
		{
			$this->m_Errors = array(
				"fld_name" => $this->getMessage("OBJECT_REFERENCE_IS_REQUIRED"),
			);
			$this->rerender();
			return ;
		}		
		
		$valueSetData = BizSystem::getObject($this->m_ParentFormName)->getRecordList();
		if(is_array($valueSetData)){
			foreach($valueSetData as $key=>$data)
			{
				if(strtolower($data['Name'])==strtolower($rec['Name']))
				{
					//exists , failed
					$this->m_Errors = array(
						"fld_name" => $this->getMessage("OBJECT_REFERENCE_ALREADY_EXISTS_IN_LIST"),
					);
					$this->rerender();
					return ;
				}
			}
		}

		//save value
		$rec['Id'] 		= $rec['Name'];
		$prtForm = BizSystem::getObject($this->m_ParentFormName);		
		$prtForm->addObjectReferenceRecord($rec);
		$this->m_ActiveRecord = null;
		
		$this->processPostAction();
		return $result;
	}
	
	   	
}
?>