<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.form
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class BuildCompletedWizardForm extends EasyFormWizard
{
	public $m_GenerateFileEncoded;
	public $m_GenerateMetaObj;
	
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$result['FileOption'] = $this->getViewObject()->getFileOption();
		$result['Attributes'] = $this->getViewObject()->getAttributes();
		$result['Customization'] = $this->getViewObject()->getCustomization();
		$result['FieldList'] = $this->getViewObject()->getFieldList();
		$result['JoinTable'] = $this->getViewObject()->getJoinTable();
		$result['ObjectReference'] = $this->getViewObject()->getObjectReference();
		
		$fileOption = $result['FileOption'];
		if(substr($fileOption['folder'],strlen($fileOption['folder'])-1,1)=='/')
		{
			$fileOption['folder'] = substr($fileOption['folder'],0,strlen($fileOption['folder'])-1);
		}
		$result['FileOption']['view_url'] = str_replace("View","",$result['FileOption']['do_name']);
		$result['FileOption']['view_url'] = strtolower(str_replace(" ","_",trim(preg_replace("/([A-Z])([0-9a-z])/", " $1$2", $result['FileOption']['view_url']))));
		
		$result['GeneratedPHPFile'] =  $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['do_name'].".php";
		$result['GeneratedXMLFile'] =  $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['do_name'].".xml";
		
		if(is_file(MODULE_PATH.DIRECTORY_SEPARATOR.$result['GeneratedPHPFile'])){
			$result['GeneratedPHPFileEncoded'] = base64_encode($result['GeneratedPHPFile']);
		}
		$result['GeneratedXMLFileEncoded'] = base64_encode($result['GeneratedXMLFile']);		
		
		$module 	= $result['FileOption']['module'];
		$folder 	= $result['FileOption']['folder'];
		$result['package'] = $module.'.'.str_replace('/','.',$folder);
		if(substr($result['package'],strlen($result['package'])-1,1)=='.')
		{
			$result['package'] = substr($result['package'],	0,	strlen($result['package'])-1);
		}
		
		return $result;
	}
	
	public function doFinish()
	{		
		$fileOption = $this->getViewObject()->getFileOption();
		if(substr($fileOption['folder'],strlen($fileOption['folder'])-1,1)=='/')
		{
			$fileOption['folder'] = substr($fileOption['folder'],0,strlen($fileOption['folder'])-1);
		}
		
		$generatedPHPFile = $fileOption['module'].'/'.$fileOption['folder'].'/'.$fileOption['do_name'];
		$this->m_GenerateMetaObj = str_replace("/",'.',$generatedPHPFile);
		
		$this->getViewObject()->clearConfigAttrs();
		
		$result = parent::doFinish();
		return $result;
	} 
	
}
?>