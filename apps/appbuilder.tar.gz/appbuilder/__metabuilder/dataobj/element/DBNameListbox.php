<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class DBNameListbox extends Listbox
{
	protected $m_ConfigFile = "application.xml";
	protected $m_ConfigNode = "DataSource";
	
	public function getFromList(&$list, $selectFrom=null)
	{	
		$file = APP_HOME.DIRECTORY_SEPARATOR.$this->m_ConfigFile;
		if(!is_file($file)){
			return;
		}
		$configArr=BizSystem::getXmlArray($file);
		$nodesArr = $configArr["APPLICATION"][strtoupper($this->m_ConfigNode)]["DATABASE"];
		$result = array();				
		
		$name = $configArr["APPLICATION"][strtoupper($this->m_ConfigNode)]["DATABASE"]["ATTRIBUTES"]["NAME"];
		if(!$name){
			for($i=0;$i<count($nodesArr);$i++){
				if(is_array($nodesArr[$i]["ATTRIBUTES"])){				
					foreach($nodesArr[$i]["ATTRIBUTES"] as $key=>$value){
						$result[$i][$key]=$value;
					}
				}
				$result[$i]["Id"]=$nodesArr[$i]["ATTRIBUTES"]["NAME"];				
			}
			
		}else{
			$this->m_FixSearchRule = "[Id]='$name'";
			$result[0]=$this->fetchData();
		}
		
		foreach($result as $conn)
		{	
			if($conn['STATUS']!=1){
				continue;
			}
			$list[] = array(
				'val'	=>	$conn['NAME'],
				'txt'	=>	$conn['NAME'].'  ('.$conn['SERVER'].':'.$conn['DBNAME'].')'
			);			
		}
		
	}

}
?>