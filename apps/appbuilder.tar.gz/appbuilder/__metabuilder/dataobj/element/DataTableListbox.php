<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metabuilder.dataobj.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class DataTableListbox extends Listbox
{	
	protected $m_SQL = "SHOW FULL TABLES";
	
	public function getFromList(&$list, $selectFrom=null)
	{	

		$db = $this->_getDBConn();
    	
		try
    	{
    		$tableInfos = $db->fetchAll($this->m_SQL);
    		foreach($tableInfos as $tableInfo)
	    	{
	    		$result[] = $tableInfo;
	    	}
    	}
    	catch(Exception $e){	    	
	    	$result[] = $tableInfo;	    	
    	}
    	
		foreach($result as $table)
		{	
			$list[] = array(
				'val'	=>	$table[0],
				'txt'	=>	$table[0]
			);			
		}
		
	}

    protected function _getDBConn()
    {
    	$dbNameElem = $this->getFormObj()->getElement("fld_dbname");
    	if($dbNameElem)
    	{
    		$dbName = $dbNameElem->getValue();
    	}
    	else
    	{
    		$attrs = $this->getFormObj()->getViewObject()->getAttributes();
    		$dbName = $attrs['DBName'];	
    		
    	}
    	return $db = BizSystem::instance()->getDBConnection($dbName);
    }	
	
}
?>