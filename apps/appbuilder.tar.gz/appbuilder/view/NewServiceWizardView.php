<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.view
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class NewServiceWizardView extends EasyViewWizard
{	
	public function renderStep($step)
    {
    	parent::renderStep($step);            
		switch(strtoupper($this->m_NaviMethod)){
			case "SWITCHFORM":
				$objectName = "appbuilder.metabuilder.service.widget.SvcLeftWidget";
				$formObj = BizSystem::getObject($objectName);
				$formObj->rerender();			
				break;							
		}
    }   
    
    public function render(){
    	if($_GET['action']=='reset'){
    		$this->m_CurrentStep=1;
    	}
    	$result = parent::render();    	
    	return $result;
    }
        
    
    public function getFileOption()
    {    	    	
		if($this->m_FormStates['appbuilder.metabuilder.service.form.ConfigAttrsWizardForm']['visited'])
    	{    		      		
	    	return BizSystem::getObject("appbuilder.metabuilder.service.form.FileCreationWizardForm")->m_FileOptions;			 	
    	}
		return null;    	
    }
    
	public function getConfigAttrs()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.service.form.ConfigAttrsWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.service.form.ConfigAttrsWizardForm")->m_ConfigAttrs;			
    	}
		return null;
    }

    public function clearConfigAttrs()
    {
    	return BizSystem::getObject("appbuilder.metabuilder.service.form.ConfigAttrsWizardForm")->clearConfigAttrs();
    	
    }
}
?>