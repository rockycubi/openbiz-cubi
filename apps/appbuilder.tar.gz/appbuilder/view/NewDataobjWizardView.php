<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.view
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class NewDataobjWizardView extends EasyViewWizard
{	
	public function renderStep($step)
    {
    	parent::renderStep($step);            
		switch(strtoupper($this->m_NaviMethod)){
			case "SWITCHFORM":
				$objectName = "appbuilder.metabuilder.dataobj.widget.DataobjLeftWidget";
				$formObj = BizSystem::getObject($objectName);
				$formObj->rerender();			
				break;							
		}
    }   
    
    public function render(){
    	if($_GET['action']=='reset'){
    		$this->m_CurrentStep=1;
    	}
    	$result = parent::render();    	
    	return $result;
    }
        
    
    public function getFileOption()
    {    	    	
		if($this->m_FormStates['appbuilder.metabuilder.dataobj.form.AttributesWizardForm']['visited'])
    	{    		      		
	    	return BizSystem::getObject("appbuilder.metabuilder.dataobj.form.FileCreationWizardForm")->m_FileOptions;			 	
    	}
		return null;    	
    }
    
	public function getAttributes()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.dataobj.form.AttributesWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.dataobj.form.AttributesWizardForm")->m_ActiveRecord;			
    	}
		return null;
    }


	public function getCustomization()
    {    	
    	$attrs = $this->getAttributes();    	
    	if($this->m_FormStates['appbuilder.metabuilder.dataobj.form.CustomizationWizardForm']['visited'] && 
    		$attrs['Class']=='CustomClass')
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.dataobj.form.CustomizationWizardForm")->m_ActiveRecord;			
    	}    	
		return null;
    }    

	public function getFieldList()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.dataobj.form.FieldListWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.dataobj.form.FieldListWizardForm")->m_FieldList;			
    	}
		return null;
    }     

	public function getJoinTable()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.dataobj.form.JoinTableListWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.dataobj.form.JoinTableListWizardForm")->m_JoinTable;			
    	}
		return null;
    }     
    
	public function getObjectReference()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.dataobj.form.ObjectReferenceListWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.dataobj.form.ObjectReferenceListWizardForm")->m_ObjectReference;			
    	}
		return null;
    }     
}
?>