<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.view
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class LinkModuleWizardView extends EasyViewWizard
{
	
    public function getRelationship()
    {
    	if($this->m_FormStates['appbuilder.linker.ConfigPrimaryWizardForm']['visited'])
    	{  
	    	$formObj = BizSystem::getObject("appbuilder.linker.RelationshipWizardForm");
			$data = $formObj->m_Relationship;	
			return $data;		
    	}
    }
    
	public function getPrimaryModule()
    {
    	if($this->m_FormStates['appbuilder.linker.ConfigSecondaryWizardForm']['visited'])
    	{    		    	
	    	$formObj = BizSystem::getObject("appbuilder.linker.ConfigPrimaryWizardForm");
			$data = $formObj->m_PrimaryModule;
			$do = str_replace("/",".",$data['primary_do']);
    		$do = str_replace(".xml","",$do);
    		$do = str_replace($data['primary_module'].".","",$do);
    		if(strlen($do)>20)
    		{
    			$do = substr($do,0,17)."...";
    		}
    		$data['primary_do_display'] = $do; 
			return $data;
    	}
    }    
    
    public function getSecondaryModule()
    {
        if($this->m_FormStates['appbuilder.linker.BuildOptionsWizardForm']['visited'])
        	{    		    	
	    	$formObj = BizSystem::getObject("appbuilder.linker.ConfigSecondaryWizardForm");
			$data = $formObj->m_SecondaryModule;
			$do = str_replace("/",".",$data['secondary_do']);
    		$do = str_replace(".xml","",$do);
    		$do = str_replace($data['secondary_module'].".","",$do);
    		if(strlen($do)>20)
    		{
    			$do = substr($do,0,17)."...";
    		}
    		$data['secondary_do_display'] = $do; 
			return $data;
    	}
    }    
    
    public function getBuildOptions()
    {
    	$form = BizSystem::getObject("appbuilder.linker.BuildOptionsWizardForm");
		$options = $form->m_BuildOptions;
		return $options;    
    }
    
    public function renderStep($step)
    {
    	parent::renderStep($step);            
		switch(strtoupper($this->m_NaviMethod)){
			case "SWITCHFORM":
				$objectName = "appbuilder.linker.widget.LinkerLeftWidget";
				$formObj = BizSystem::getObject($objectName);
				$formObj->rerender();			
				break;							
		}
    }    
    
}
?>