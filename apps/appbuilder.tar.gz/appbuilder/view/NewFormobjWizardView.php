<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.view
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class NewFormobjWizardView extends EasyViewWizard
{	
	public function renderStep($step)
    {
    	parent::renderStep($step);            
		switch(strtoupper($this->m_NaviMethod)){
			case "SWITCHFORM":
				$objectName = "appbuilder.metabuilder.formobj.widget.FormobjLeftWidget";
				$formObj = BizSystem::getObject($objectName);
				$formObj->rerender();			
				break;							
		}
    }   
    
    public function render(){
    	if($_GET['action']=='reset'){
    		$this->m_CurrentStep=1;
    	}
    	$result = parent::render();    	
    	return $result;
    }
        
    
    public function getFileOption()
    {    	    	
		if($this->m_FormStates['appbuilder.metabuilder.formobj.form.AttributesWizardForm']['visited'])
    	{    		      		
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.FileCreationWizardForm")->m_FileOptions;			 	
    	}
		return null;    	
    }
    
	public function getAttributes()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.formobj.form.AttributesWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.AttributesWizardForm")->m_ActiveRecord;			
    	}
		return null;
    }


	public function getCustomization()
    {    	
    	$attrs = $this->getAttributes();    	
    	if($this->m_FormStates['appbuilder.metabuilder.formobj.form.CustomizationWizardForm']['visited'] && 
    		$attrs['Class']=='CustomClass')
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.CustomizationWizardForm")->m_ActiveRecord;			
    	}    	
		return null;
    }    

	public function getDataPanel()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.formobj.form.DataPanelWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->m_PanelConfig;			
    	}
		return null;
    }     

	public function getActionPanel()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.formobj.form.ActionPanelWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->m_PanelConfig;			
    	}
		return null;
    }     
    
	public function getNaviPanel()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.formobj.form.NaviPanelWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.NaviPanelWizardForm")->m_PanelConfig;			
    	}
		return null;
    }     

	public function getSearchPanel()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.formobj.form.SearchPanelWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.formobj.form.SearchPanelWizardForm")->m_PanelConfig;			
    	}
		return null;
    }  

    public function clearFormPanels()
    {
    	BizSystem::getObject("appbuilder.metabuilder.formobj.form.DataPanelWizardForm")->clearPanelConfig();
    	BizSystem::getObject("appbuilder.metabuilder.formobj.form.ActionPanelWizardForm")->clearPanelConfig();
    	BizSystem::getObject("appbuilder.metabuilder.formobj.form.NaviPanelWizardForm")->clearPanelConfig();
    	BizSystem::getObject("appbuilder.metabuilder.formobj.form.SearchPanelWizardForm")->clearPanelConfig();
    }    
}
?>