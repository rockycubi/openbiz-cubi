<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.view
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class NewLovWizardView extends EasyViewWizard
{
	public $m_ValueSets = array();
	
    public function getSessionVars($sessionContext)
    {
       	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "ValueSets", $this->m_ValueSets, true);
    }

    public function setSessionVars($sessionContext)
    {
        parent::setSessionVars($sessionContext);
        if (!$this->m_DropSession){
        	$sessionContext->setObjVar($this->m_Name, "ValueSets", $this->m_ValueSets, true);
        }               
    }	
	
	public function renderStep($step)
    {
    	parent::renderStep($step);            
		switch(strtoupper($this->m_NaviMethod)){
			case "SWITCHFORM":
				$objectName = "appbuilder.metabuilder.lov.widget.LovLeftWidget";
				$formObj = BizSystem::getObject($objectName);
				$formObj->rerender();			
				break;							
		}
    }   
    
    public function render(){
    	if($_GET['action']=='reset'){
    		$this->m_CurrentStep=1;
    		$this->m_ValueSets = array();
    	}
    	$result = parent::render();    	
    	return $result;
    }
    
    public function saveCurrentValueSet()
    {
    	$valueSet = array(
    		"Setting"	=>$this->getActiveValueSet(),
    		"Data"		=>$this->getActiveValueSetData()
    	);
    	$dataMerged = false;
    	if(is_array($this->m_ValueSets))
    	{
    		foreach($this->m_ValueSets as $key=>$data)
    		{
    			if($data['Setting']['valueset_name']==$valueSet['Setting']['valueset_name'])
    			{
    				$this->m_ValueSets[$key] = $valueSet;
    				$dataMerged=true;
    				break;
    			}
    		}
    	}
    	if(!$dataMerged)
    	{
    		$this->m_ValueSets[]=$valueSet;
    	}
    	
    	$this->clearActiveValueSet();
    	return $this->m_ValueSets;
    }
    
    public function getAllValueSets()
    {
    	return $this->m_ValueSets;
    }
    
    public function getFileOption()
    {    	
		if($this->m_FormStates['appbuilder.metabuilder.lov.form.AddSetWizardForm']['visited'])
    	{    		      		
	    	return BizSystem::getObject("appbuilder.metabuilder.lov.form.FileCreationWizardForm")->m_FileOptions;			 	
    	}
		return null;    	
    }
    
    public function canEditValueSets()
    {
   	 	if($this->m_FormStates['appbuilder.metabuilder.lov.form.BuildCompletedWizardForm']['visited'])
    	{    		      		
	    	return false;			 	
    	}
    	return true;
    }
    
    public function clearActiveValueSet()
    {
    	BizSystem::getObject("appbuilder.metabuilder.lov.form.AddSetWizardForm")->clearActiveValueSet();		
    	BizSystem::getObject("appbuilder.metabuilder.lov.form.FillValueWizardForm")->clearActiveValueSetData();	
    }
    
    public function getActiveValueSet()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.lov.form.FillValueWizardForm']['visited'])
    	{    		      		    		
	    	return BizSystem::getObject("appbuilder.metabuilder.lov.form.AddSetWizardForm")->m_ActiveValueSet;			 	
    	}
		return null;
    }

    
	public function getActiveValueSetData()
    {    	
    	if($this->m_FormStates['appbuilder.metabuilder.lov.form.FillValueWizardForm']['visited'])
    	{  
	    	return BizSystem::getObject("appbuilder.metabuilder.lov.form.FillValueWizardForm")->m_ActiveValueSetData;			
    	}
		return null;
    }
    	    
}
?>