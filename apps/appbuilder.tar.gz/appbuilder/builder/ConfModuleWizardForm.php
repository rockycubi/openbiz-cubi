<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.builder
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ConfModuleWizardForm extends EasyFormWizard
{
	public $m_ModuleConfig ; 
	public $m_HasPermFields;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "ModuleConfig", $this->m_ModuleConfig);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "ModuleConfig", $this->m_ModuleConfig);     
    }

	public function goNext($commit=false)
	{		
		$rec = $this->readInputRecord();
		$this->m_ModuleConfig = $rec;
		BizSystem::getObject("appbuilder.builder.BuildOptionsWizardForm")->m_ActiveRecord=null;
		parent::goNext(false);
	}	    
    
	protected function checkPermFields()
	{
		$fields = $this->getViewObject()->getFields();
		if(!is_array($fields))
		{
			return false;
		}
		if(	in_array("owner_id",$fields) && 
			in_array("group_id",$fields) &&
			in_array("group_perm",$fields) &&
			in_array("other_perm",$fields)
			)
			{
				return true;
			}
			else
			{
				return false;
			}
	}
	
	public function fetchData()    
	{    	       
		$this->m_HasPermFields = (int) $this->checkPermFields();    
		 		
		if ($this->m_ActiveRecord != null)
            return $this->m_ActiveRecord;
    	
        if (strtoupper($this->m_FormType) == "NEW")
            return $this->getNewRecord();
            
        return parent::fetchData();
    }
	
	public function getNewRecord()
	{		
		$result = array();
		$tableName = $this->getViewObject()->getTableName();
		$names = explode("_", $tableName);
		if($names[1])
		{					
			$objectName = str_replace("_"," ",$tableName);
			$objectNameSpacing = ucwords($objectName);
			$objectName = str_replace(" ","",$objectNameSpacing);
		}
		else 
		{
			$objectNameSpacing = $objectName = ucfirst($names[0]);
		}
		
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$moduleList = $svc->listModules();
    	if(!isset($_POST['fld_module_type'])){
	    	if(in_array(strtolower($names[0]), $moduleList))
	    	{
	    		$moduleType="0";
	    	}
	    	else
	    	{
	    		$moduleType="1";
	    	}    	
    	}else{
    		$moduleType = $_POST['fld_module_type'];    		
    	}
		$result['object_name'] = $objectName."DO";
		$result['object_desc'] = $objectNameSpacing." Description";
		$result['module_type'] = $moduleType;
		$result['module_name_create'] = strtolower($names[0]);
		$result['module_name_exists'] = strtolower($names[0]);
		$result['resource_name'] = strtolower($names[0]);
		$result['extend_type_do'] = $objectName."TypeDO";
		$result['extend_type_desc'] = $objectNameSpacing." Type Description";
		
		return $result;
	}
}
?>