<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.builder
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ConfDataFieldWizardForm extends EasyFormWizard
{
	public $m_SelectedFields ;
	public $m_ConfigFields ; 
	
	protected $m_ElemenetSetCounter;
	protected $m_ElemenetSorting;
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "SelectedFields", $this->m_SelectedFields);
        $sessionContext->getObjVar($this->m_Name, "ConfigFields", $this->m_ConfigFields);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "SelectedFields", $this->m_SelectedFields);
        $sessionContext->setObjVar($this->m_Name, "ConfigFields", $this->m_ConfigFields);         
    }	
	
	public function deleteRecord($id=null)
	{
		if ($id==null || $id=='')
            $id = BizSystem::clientProxy()->getFormInputs('_selectedId');

        $selIds = BizSystem::clientProxy()->getFormInputs('row_selections', false);
        if ($selIds == null)
            $selIds[] = $id;
        $db = $this->_getDBConn();
        $tableName = $this->getViewObject()->getTableName();
        foreach ($selIds as $id)
        {      
        	$sql = "ALTER TABLE `$tableName` DROP `$id`;";
        	$db->query($sql);
        }
        if (strtoupper($this->m_FormType) == "LIST")
            $this->rerender();

        $this->runEventLog();
        $this->processPostAction();
	}

	public function getConfigFields()
	{
		$selIds 		= BizSystem::clientProxy()->getFormInputs('row_selections', false);
		$elementSets 	= BizSystem::clientProxy()->getFormInputs('fld_elementset', false);
		$displayNames 	= BizSystem::clientProxy()->getFormInputs('fld_label', false);
		$sorting 		= BizSystem::clientProxy()->getFormInputs('fld_sorting', false);  
		
		$fields = array();
		$fieldsTmp = array();
		$fieldsSorting = array();
		foreach($selIds as $id)
		{
			$fieldsTmp[$id] = array(
					"Id" 		=>	$id,
					"ElementSet"=>	$elementSets[$id],
					"Label"		=>	$displayNames[$id],
					"Sorting"	=>	$sorting[$id]
			);
		}
		foreach($selIds as $id)
		{
			$fieldsSorting[$id] =	$sorting[$id];
		}
		asort($fieldsSorting);
		
		foreach($fieldsSorting  as $key=>$value)
		{
			$fields[$key] = $fieldsTmp[$key];
		}		
		$this->m_ConfigFields = $fields;
		return $fields;
	}
	
	public function goNext($commit=false)
	{		
		$selIds = BizSystem::clientProxy()->getFormInputs('row_selections', false); 
        if(count($selIds)>0)
        {			
        	if(!in_array("id", $selIds))
        	{
        		$msg = $this->getMessage("MSG_PLEASE_SELECT_ID_FIELDS");
	        	$errors = array(
	        		"DATABASE"=>$msg
	        	);
	        	$this->processFormObjError($errors);
        	}else{
        		$this->m_SelectedFields = $selIds;
        		$this->m_ConfigFields = $this->getConfigFields();
        		$formObj=BizSystem::getObject("appbuilder.builder.ConfModuleWizardForm")->m_ActiveRecord=null;
				parent::goNext(false);
        	}
        }
        else
        {
        	$msg = $this->getMessage("MSG_PLEASE_SELECT_FIELDS");
        	$errors = array(
        		"DATABASE"=>$msg
        	);
        	$this->processFormObjError($errors);
        }
	}	
	
	public function fetchDataSet()
	{
		$db = $this->_getDBConn();
		$tableName = $this->getViewObject()->getTableName();
		if(!$tableName)return;
		$sql = "SHOW FULL COLUMNS FROM `$tableName`";
		$fieldsInfo = $db->fetchAssoc($sql);
		
		if(!$this->m_SelectedFields)
		{
			$this->m_SelectedFields=array();
		}
    	
		foreach($fieldsInfo as $fieldInfo)
    	{
    		$fieldInfo["Id"] = $fieldInfo['Field'];
    		if(in_array($fieldInfo['Field'], $this->m_SelectedFields)){
    			$fieldInfo["SelectedField"] = 1;
    		}else{
    			$fieldInfo["SelectedField"] = 0;
    		}
    		$result[] = $fieldInfo;
    	}
		
		//set default selected record
		if(!$this->m_RecordId){
				$this->m_RecordId=$result[0]["Id"];
		}
		
		//set paging 
		$this->m_TotalRecords = count($result);
			
        if ($this->m_Range && $this->m_Range > 0)
            $this->m_TotalPages = ceil($this->m_TotalRecords/$this->m_Range);
		
        if($this->m_CurrentPage > $this->m_TotalPages)
        {
        	$this->m_CurrentPage = $this->m_TotalPages;
        }
            
        if(is_array($result)){
			$result = array_slice($result,($this->m_CurrentPage-1)*$this->m_Range,$this->m_Range);
		}	
		return $result;
	}
	
    protected function _getDBConn()
    {
    	return $this->getViewObject()->getDBConn();
    }
    
 	public function fetchFieldInfo($tableName,$fieldName)
	{
		if($fieldName && $tableName)
		{
	    	$db = $this->_getDBConn();    	
			$tableInfos = $db->fetchAssoc("SHOW FULL COLUMNS FROM `$tableName` WHERE Field='$fieldName';");
			$infoArr = $tableInfos[$fieldName];
			if($infoArr['Null']=='YES')
			{
				$infoArr['SetNull']="1";
			}
			else
			{
				$infoArr['SetNull']="0";
			}
			return $infoArr;
		}		
	}
	   
	public function getDefaultLabel()
	{
		$rec = $this->getActiveRecord();
		switch($rec['Id'])
		{
			case "create_by":
			case "create_time":
			case "update_by":
			case "update_time":
			case "sort_order":
			case "sortorder":
				if($rec['Comment'])
				{
					$label = $rec['Comment'];
				}else{
					$label = $rec['Id'];
				}	
				$label = str_replace("_id", "", $label);
				$label = str_replace("_", " ", $label);
				$label = ucwords($label);
				break;
			
			case "owner_id":
			case "group_id":
			case "group_perm":
			case "other_perm":
				$label	=	"";
				break;
				
			default:
				if($rec['Comment'])
				{
					$label = $rec['Comment'];
				}else{
					$label = $rec['Id'];
				}	
				$label = str_replace("_id", "", $label);
				$fieldArr = explode("_", $label);
				$label = str_replace($fieldArr[0]."_", " ", $label);
				$label = str_replace("_", " ", $label);
				$label = ucwords($label);
				break;
		}
		return $label;
	}
	
	public function getDefaultElementSet()
	{
		$rec = $this->getActiveRecord();
		switch($rec['Id'])
		{
			case "create_by":
			case "create_time":
			case "update_by":
			case "update_time":
			case "sort_order":
			case "sortorder":
				$elementString	=	"Miscellaneous";
				break;
			case "owner_id":
			case "group_id":
			case "group_perm":
			case "other_perm":
				$elementString	=	"";
				break;
			default:
				if($rec['Comment'])
				{
					$label = $rec['Comment'];
				}else{
					$label = $rec['Id'];
				}				
				$label = str_replace("_id", "", $label);
				$fieldArr = explode("_", $label);
				if(count($fieldArr)>1){
					$elementString	=	ucwords($fieldArr[0]);
				}else{
					if($this->m_ElemenetSetCounter<=5)
					{
						$elementString	=	"General";
					}
					else
					{
						$elementString	=	"Additional";
					}
					$this->m_ElemenetSetCounter ++;
				}
				break;
		}
		return $elementString;
	}
	
	public function getDefaultSorting()
	{
		if($this->m_ElemenetSorting<=95)
		{
			$this->m_ElemenetSorting+=5;
		}
		return $this->m_ElemenetSorting;
	}
	
}