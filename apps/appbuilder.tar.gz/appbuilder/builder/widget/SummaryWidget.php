<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.builder.widget
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class SummaryWidget extends EasyForm
{
   
	public function outputAttrs()
	{
		$result 				= parent::outputAttrs();
		$result['dbConn'] 		= $this->getViewObject()->getDBConnName();
		$result['tableName'] 	= $this->getViewObject()->getTableName();
		$result['tableFields'] 	= $this->getViewObject()->getFields();
		return $result;		
	}
}
?>