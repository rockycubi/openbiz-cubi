<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class SelectFromForm extends PickerForm 
{ 
	
	public function SaveRecord()
	{
		//$fld_data = BizSystem::clientProxy()->getFormInputs('fld_data');
		$rec = $this->readInputRecord();
		
		//$parentForm = BizSystem::objectFactory()->getObject($this->m_ParentFormName);
    	$updArray = array();
    	$updRec = $this->m_ParentFormRecord;
		// get the picker map of the control
		if ($this->m_PickerMap)
		{
			$pickerList = $this->_parsePickerMap($this->m_PickerMap);	            
			foreach ($pickerList as $ctrlPair)
			{
				$this_ctrl = $this->getElement($ctrlPair[1]);
				if (!$this_ctrl)
					continue;
									
				$this_ctrl_val = $rec[$this_ctrl->m_FieldName];
				$other_ctrl_name = $ctrlPair[0];
				if(!$updArray[$other_ctrl_name]){
					$updArray[$other_ctrl_name] = $this_ctrl_val;
				}else{
					$updArray[$other_ctrl_name] .= ';'.$this_ctrl_val;
				}
			}	            
		}
		$this->close();	                                               
		
		BizSystem::clientProxy()->updateFormElements($this->m_ParentFormName, $updArray);
	}
	
	public function setParentFormData($formName, $elemName=null, $pickerMap=null)
    {
        $this->m_ParentFormName = $formName;
        $this->m_ParentFormElemName = $elemName;
        $this->m_PickerMap = $pickerMap;
		$elemValue = BizSystem::clientProxy()->getFormInputs($elemName);
		$this->getElement("fld_selectfrom")->m_Value = $elemValue;
    }
    
    public function updateForm()
    {
    	$rec = $this->readInputRecord();
    	switch(strtolower($rec['expr_type']))
    	{
    		case "string":    			
    			$values = explode("\n", trim($rec['string_value']));
    			$rec['selectfrom'] = implode("|",$values);
    			break;

    			
    		case "dataobj":    	    	
    			if($rec['data_field_picture'])
    			{
    				$fieldPicture = ":".$rec['data_field_picture'];
    			}
    			else
    			{
    				$fieldPicture = "";
    			}
    			
    			if($rec['data_condition'])
    			{
    				$condition = ",".$rec['data_condition'];
    			}
    			else
    			{
    				$condition = "";
    			}
    			
    			$rec['selectfrom'] = $rec['data_module'].'.'.$rec['data_object']."[".$rec['data_field_value'].":".$rec['data_field_text']."$fieldPicture]$condition"  ;    			
    			break;
    			
    		case "sql":
    			$rec['selectfrom'] = '{tx}BizSystem::getService('.$rec['svc_object'].')->'.$rec['svc_method'].'(){/tx}';
    			break;
    	}
    	$this->setActiveRecord($rec);
    	$this->rerender();
    }
    
    public function getCurrentObject()
    {
    	return $_REQUEST['metaobj'];
    }
}
?>