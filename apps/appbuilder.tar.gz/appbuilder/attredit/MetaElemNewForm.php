<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */


include_once (MODULE_PATH."/appbuilder/lib/MetadataXMLUtil.php");

class MetaElemNewForm extends EasyForm 
{ 
    public $m_MetaFile;
    protected $m_ElemPath;
    protected $m_AttrName;
    protected $m_XmlFile;
    protected $m_Doc;
	protected $_element;
	protected $m_PrtElemPath;
	protected $m_PrtAttrName;
	protected $formType;
	
	protected function readMetadata(&$xmlArr)
	{
		parent::readMetaData($xmlArr);
		// change the inheritFrom according to the input element type
		$metaObj = $_REQUEST['metaobj'];
		$elemName = $_REQUEST['elem_name'];
		$elemNameValue = $_REQUEST['elem_name_value'];
		$metaFile = MODULE_PATH."/".str_replace(".","/",$metaObj).".xml";
		$this->m_MetaFile = $metaFile;
		$this->m_ElemPath = $elemName;
		$this->m_AttrName = $elemNameValue;
		$this->m_PrtElemPath = $_REQUEST['prt_elem_name'];
		$this->m_PrtAttrName = $_REQUEST['prt_elem_name_value'];
		
		$rootElem = simplexml_load_file($this->m_MetaFile);
		$rootElemName = $rootElem->getName();
	}
	
	public function outputAttrs()
	{
		if (!empty($this->m_AttrName)) $this->m_Title .= " of [".$this->m_AttrName."]";
		else $this->m_Title .= " of [".$this->m_ElemPath."]";
		return parent::outputAttrs();
	}
	
	public function saveRecord()
	{
		try
        {
            $this->ValidateForm();
        }
        catch (ValidationException $e)
        {
        	$this->processFormObjError($e->m_Errors);
            return;
        }
        $recArr = $this->readInputRecord();
        
        if (count($recArr) == 0)
            return;
        
        $metaXmlUtil = new MetadataXMLUtil($this->m_MetaFile);
		$metaXmlUtil->setCurrentElement($this->m_ElemPath, $this->m_AttrName, $this->m_PrtElemPath, $this->m_PrtAttrName);

		try {
			$metaXmlUtil->addElement($recArr, $this->m_PrtElemPath, $this->m_PrtAttrName);
		} catch (Exception $e) {
			BizSystem::clientProxy()->showClientAlert ($e->getMessage());
			return;
		}
		// if name is changed, refresh the left tree node name
		$script = "<script>";
		$script .= "addElement('".$recArr['Name']."','".$this->m_ElemPath."','".$recArr['Name']."');";
		$script .= "</script>";
		BizSystem::clientProxy()->runClientScript($script);
		$this->close();
	}
}
?>