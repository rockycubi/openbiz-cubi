<?PHP
/**
 * PHPOpenBiz Framework
 *
 * LICENSE
 *
 * This source file is subject to the BSD license that is bundled
 * with this package in the file LICENSE.txt.
 *
 * @package   openbiz.bin.easy
 * @copyright Copyright &copy; 2005-2009, Rocky Swen
 * @license   http://www.opensource.org/licenses/bsd-license.php
 * @link      http://www.phpopenbiz.org/
 * @version   $Id$
 */

/**
 * FolderTree class - contains formtree object metadata functions
 *
 * @package openbiz.bin.easy
 * @author Rocky Swen
 * @copyright Copyright (c) 2005-2009
 * @since 1.2
 * @access public
 */
class MetaXMLTree extends EasyForm
{
    protected $m_MetaName;
    protected $m_XmlFile;
    protected $m_MetaType;
    public $m_SupportedMetaFile = true;
	
	public function __construct(&$xmlArr)
    {
        parent::__construct($xmlArr);
		$this->initMetaObj();
    }
	
	protected function initMetaObj()
    {
        $metaobj = $_REQUEST['metaobj'];
		$this->m_MetaName = $metaobj;
        $this->m_XmlFile = MODULE_PATH."/".str_replace(".","/",$metaobj).".xml";
    }
	
    /**
     * Select Record
     *
     * @param string $recId
     * @access remote
     */
    public function selectRecord($elemName, $attrNameValue, $prtElemName="", $prtAttrNameValue="")
    {
		// set the elemtype and elemname to _POST so that they will be used to initiate the right edit form
		$_POST['elem_name'] = $_REQUEST['elem_name'] = $elemName;
		$_POST['elem_name_value'] = $_REQUEST['elem_name_value'] = $attrNameValue;
		
		$_POST['prt_elem_name'] = $_REQUEST['prt_elem_name'] = $prtElemName;
		$_POST['prt_elem_name_value'] = $_REQUEST['prt_elem_name_value'] = $prtAttrNameValue;
		
		// get the proper element attribute edit form 
		$attrEditFormName = "appbuilder.attredit.MetaElemEditForm";
		$attrEditFormObj = BizSystem::getObject($attrEditFormName);
		
		// rerender the right panel form to the attribute edit form
		$attrEditFormObj->rerender();
    }
	
	public function moveElement($elemName, $attrNameValue, $attrNameValue2, $insertMode)
	{
		// set the elemtype and elemname to _POST so that they will be used to initiate the right edit form
		$_POST['elem_name'] = $_REQUEST['elem_name'] = $elemName;
		$_POST['elem_name_value'] = $_REQUEST['elem_name_value'] = $attrNameValue;
		
		// get the proper element attribute edit form 
		$attrEditFormName = "appbuilder.attredit.MetaElemEditForm";
		$attrEditFormObj = BizSystem::getObject($attrEditFormName);
		
		// rerender the right panel form to the attribute edit form
		$attrEditFormObj->moveElement($elemName, $attrNameValue, $attrNameValue2, $insertMode);
	}
	
	public function loadNewElementForm($formName, $elemName, $attrNameValue="")
    {
		// set the elemtype and elemname to _POST so that they will be used to initiate the right edit form
		$_POST['elem_name'] = $_REQUEST['elem_name'] = $elemName;
		$_POST['elem_name_value'] = $_REQUEST['elem_name_value'] = $attrNameValue;
		
        $this->_showForm($formName, "Dialog", array());
    }
	
	public function deleteElement($elemName, $attrNameValue, $prtElemName="", $prtAttrNameValue="")
	{
		// set the elemtype and elemname to _POST so that they will be used to initiate the right edit form
		$_POST['elem_name'] = $_REQUEST['elem_name'] = $elemName;
		$_POST['elem_name_value'] = $_REQUEST['elem_name_value'] = $attrNameValue;
		
		$_POST['prt_elem_name'] = $_REQUEST['prt_elem_name'] = $prtElemName;
		$_POST['prt_elem_name_value'] = $_REQUEST['prt_elem_name_value'] = $prtAttrNameValue;
		
		// get the proper element attribute edit form 
		$attrEditFormName = "appbuilder.attredit.MetaElemEditForm";
		$attrEditFormObj = BizSystem::getObject($attrEditFormName);
		
		// rerender the right panel form to the attribute edit form
		$attrEditFormObj->deleteRecord();
	}
    
    /**
     * Output attributs
     *
     * @return void
     */
    public function outputAttrs()
    {
        $out['name'] = $this->m_Name;
        $out['title'] = $this->m_Title;
        $out['hasSubform'] = $this->m_SubForms ? 1 : 0;
        $out['depth'] = $this->m_Depth;
		if (file_exists($this->m_XmlFile)) {
			$out['metaobj'] = $this->m_MetaName;
            $rootElem = simplexml_load_file($this->m_XmlFile);
			$out['rootNode'] = $rootElem;
		}
        $out['description'] = $this->m_Description;
        $out['filesize'] = filesize($this->m_XmlFile);
        $out['filesize_h'] = BizSystem::getService(UTIL_SERVICE)->format_bytes($out['filesize']);
        $out['modification_time'] = date("Y-m-d H:i:s",filemtime($this->m_XmlFile));
        $out['creation_time'] = date("Y-m-d H:i:s",filectime($this->m_XmlFile));
        $out['formobj'] = $this;
        return $out;
    }

    /**
     * Fetch DataSet, and store on active record
     * 
     * @return void
     */
    public function fetchDataSet()
    {
        return null;
    }
    

}

?>