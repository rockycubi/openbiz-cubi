<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit.widget
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class SubformEditableListWidgetForm extends PickerForm
{
	public $m_TotalRecords;
	public $m_SubFormArray = array();
	
    public function getSessionVars($sessionContext)
    {
    	parent::getSessionVars($sessionContext);
        $sessionContext->getObjVar($this->m_Name, "SubFormArray", $this->m_SubFormArray);
    }

    public function setSessionVars($sessionContext)
    {
    	parent::setSessionVars($sessionContext);
        $sessionContext->setObjVar($this->m_Name, "SubFormArray", $this->m_SubFormArray);     
    }	
	
	public function runSearch()
    {
        include_once(OPENBIZ_BIN."/easy/SearchHelper.php");
        $searchRule = "";
        foreach ($this->m_SearchPanel as $element)
        {
            $searchStr = '';
        	if(method_exists($element,"getSearchRule")){
        		$searchStr = $element->getSearchRule();        		
        	}else{        	
	            if (!$element->m_FieldName)
	                continue;
	
	            $value = BizSystem::clientProxy()->getFormInputs($element->m_Name);     	                   
	            if($element->m_FuzzySearch=="Y")
	            {
	                $value="*$value*";
	            }
	            if ($value!='')
	            {
	                $searchStr = inputValToRule($element->m_FieldName, $value, $this);	  
	                $values[] = $value; 	                           
	            }
        	}
        	if($searchStr){
        		if ($searchRule == "")
                    $searchRule .= $searchStr;
                else
                    $searchRule .= " AND " . $searchStr;
        	}        	        	
        }
        $this->m_SearchRule = $searchRule;
        $this->m_SearchRuleBindValues = $values;

        $this->m_RefreshData = true;

        $this->m_CurrentPage = 1;

        BizSystem::log(LOG_DEBUG,"FORMOBJ",$this->m_Name."::runSearch(), SearchRule=".$this->m_SearchRule);

		$recArr = $this->readInputRecord();		
		
		$this->m_SearchPanelValues = $recArr;
		
        $this->m_ModuleName = $this->m_SearchPanel->get("form_module_filter")->m_Value;	
        $this->runEventLog();
        $this->rerender();
    }	
	
	public function fetchDataSet()
	{
		$resultRaw = $this->getRecordList();
		if(!is_array($resultRaw))
		{
			return array();
		}
		
		
		$searchRule = $this->m_SearchRule;		
		
		preg_match_all("/\[(.*?)\]/si", $searchRule,$match);	
		$i=0;		
		$searchFilter = array();
		if(is_array($this->m_SearchRuleBindValues))
		{
			foreach( $this->m_SearchRuleBindValues as $key=>$value)
			{
				$fieldName = $match[1][$i];
				$fieldValue = $value;
				$i++;
				$searchFilter[$fieldName]=$fieldValue;
			}		
		}
		if(count($searchFilter))
		{
			
			foreach($resultRaw as $record)
			{				
				$testField = false;
				foreach($searchFilter as $field=>$value)
				{					
					if($record[$field]!=$value){
						$testField =true;
						break;
					}
				}
				if(!$testField)
				{
					$result[] = $record; 
				}
			}
		}
		else
		{
			$result=$resultRaw;
		}
		
    	//set default selected record
		if(!$this->m_RecordId){
				$this->m_RecordId=$result[0]["Name"];
		}
		//set paging 
		$this->m_TotalRecords = count($result);
			
        if ($this->m_Range && $this->m_Range > 0)
            $this->m_TotalPages = ceil($this->m_TotalRecords/$this->m_Range);
		
        if($this->m_CurrentPage > $this->m_TotalPages)
        {
        	$this->m_CurrentPage = $this->m_TotalPages;
        }
            
        if(is_array($result)){
			$result = array_slice($result,($this->m_CurrentPage-1)*$this->m_Range,$this->m_Range);
		}	    
            
    	return $result;
	}	

	public function getRecordList()
	{	    	
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
		if(is_array($this->m_SubFormArray)){	
	    	foreach($this->m_SubFormArray as $obj)
	    	{
	    		$obj = str_replace(".","/",$obj).".xml";
	    		$objInfo = $svc->getFormObjectInfo($obj);
	    		$objInfo['Id']=$objInfo['PACKAGE'].'.'.$objInfo['Id'];
	    		if(!$objInfo['FORMTYPE'])
				{
					$objInfo['FORMTYPE'] = 'Detail';
				}
				$objInfo['ICONTYPE'] = RESOURCE_URL.'/appbuilder/images/icon_form_'.strtolower($objInfo['FORMTYPE']).'_small.png';
				$objInfo['MODULE'] = $module;
	    		$result[] = $objInfo;
	    	}    
		}
		return $result;
	}

	public function removeRecord()
	{
	    if ($id==null || $id=='')
            $id = BizSystem::clientProxy()->getFormInputs('_selectedId');

        $selIds = BizSystem::clientProxy()->getFormInputs('row_selections', false);
        if ($selIds == null)
            $selIds[] = $id;
        foreach ($selIds as $id)
        {         	
        	unset($this->m_SubFormArray[$id]);
        }        

        $this->runEventLog();
        $this->rerender();
		
	}
	
    
    
}
?>