<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit.widget.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN."/easy/element/DropDownList.php";
class ModuleList extends DropDownList
{
	
    public function getList()
    {
        $list = array();
        $this->getSimpleFromList($list);       
        return $list;
    }	       
    
    protected function getSimpleFromList(&$list)
    {

		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$pkgList = $svc->listModules();
        foreach ($pkgList as $package)
        {            
            $list[$i]['pic'] = RESOURCE_URL.'/appbuilder/images/icon_module_item_small.png';
            $list[$i]['val'] = $package;
            $list[$i]['txt'] = $package;
            $i++;        	
        }
    }   
	
	public function getDefaultValue()
	{
		$metaobj = $_REQUEST['metaobj'];
		if ($metaobj) {
			$parts = explode('.',$metaobj);
			$module = $parts[0];
			return $module;
		}
		return '';
	}
}
?>