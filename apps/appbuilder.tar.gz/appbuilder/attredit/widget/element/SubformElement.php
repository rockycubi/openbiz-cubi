<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit.widget.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

include_once OPENBIZ_BIN.'/easy/element/FormElement.php'; 
class SubformElement extends FormElement
{
	public function getValue()
	{
		//form1 ; form2
		$array= BizSystem::getObject($this->m_FormReference)->m_SubFormArray;
		$value = implode(";", $array);
		return $value;
		
	}
	
	public function render()
	{
		$rec=$this->getFormObj()->fetchData();
		$value = $rec[$this->m_FieldName];
		$formArr=array();
		if($value){
			$forms = explode(";",$value);			
			foreach($forms as $form)
			{			
				$formArr[$form]=$form;
			}
		}
		BizSystem::getObject($this->m_FormReference)->m_SubFormArray=$formArr;
		return parent::render();
		
	}
}
?>