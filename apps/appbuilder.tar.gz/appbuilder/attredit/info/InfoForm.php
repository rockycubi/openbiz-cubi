<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit.info
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */


include_once (MODULE_PATH."/appbuilder/lib/MetadataXMLUtil.php");

class InfoForm extends EasyForm 
{ 
    protected $m_MetaFile;
	
	protected function readMetadata(&$xmlArr)
	{
		parent::readMetaData($xmlArr);
		// change the inheritFrom according to the input element type
		$metaObj = $_REQUEST['metaobj'];
		$metaFile = MODULE_PATH."/".str_replace(".","/",$metaObj).".xml";
		$this->m_MetaFile = $metaFile;
		
		$rootElem = simplexml_load_file($this->m_MetaFile);
		$elemName = $rootElem->getName();
		$infoFormName = "appbuilder.attredit.info.".$elemName."InfoForm";
		$metaArr = explode(".",$metaObj);
		
		$_REQUEST['elem_name']=$elemName;
		$_REQUEST['elem_name_value']=$metaArr[count($metaArr)-1];
		$classFile = MODULE_PATH."/".str_replace(".","/",$infoFormName).".xml";
		//echo "class file is $classFile";
		if (file_exists($classFile)) {
			$this->m_InheritFrom = $infoFormName;
		}
	}
}
?>