<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */


include_once (MODULE_PATH."/appbuilder/lib/MetadataXMLUtil.php");

class MetaElemEditForm extends EasyForm 
{ 
    public $m_MetaFile;
    protected $m_ElemPath;
    protected $m_AttrName;
    protected $m_XmlFile;
    protected $m_Doc;
	protected $_element;
	protected $m_PrtElemPath;
	protected $m_PrtAttrName;
	protected $formType;
	
	protected $m_EditingFormType;
	
	public $m_ParentFormType;
	
	
	protected function readMetadata(&$xmlArr)
	{
		parent::readMetaData($xmlArr);
		// change the inheritFrom according to the input element type
		$metaObj = $_REQUEST['metaobj'];
		$elemName = $_REQUEST['elem_name'];
		$elemNameValue = $_REQUEST['elem_name_value'];
		$metaFile = MODULE_PATH."/".str_replace(".","/",$metaObj).".xml";
		$this->m_MetaFile = $metaFile;
		$this->m_ElemPath = $elemName;
		$this->m_AttrName = $elemNameValue;
		$this->m_PrtElemPath = $_REQUEST['prt_elem_name'];
		$this->m_PrtAttrName = $_REQUEST['prt_elem_name_value'];
		
		$rootElem = simplexml_load_file($this->m_MetaFile);
		$rootElemName = $rootElem->getName();
		$this->setInheritFromName($elemName, $rootElemName);
	}
	
	protected function setInheritFromName($elemName, $rootElemName)
	{
		if (!empty($elemName)) { // && !empty($elemNameValue)) {
			if ($rootElemName == 'Module') {
				$inheritFormName = "appbuilder.attredit.mod.".$elemName."EditForm";
				if ($this->m_PrtElemPath == 'Dependency') $inheritFormName = "appbuilder.attredit.mod.Dep".$elemName."EditForm";
			}
			else {
				$inheritFormName = "appbuilder.attredit.".$elemName."EditForm";
			}
			//echo "inheritFormName is $inheritFormName";
			// TODO: for element, get the Class attribute, set the inheritFormName = "appbuilder.attredit.".$className."EditForm"
			if ($elemName == "Element") {
				$className = BizSystem::clientProxy()->getFormInputs("fld_class");
				if (empty($className)) {
					$attrs = $this->getElemAttributes();
					$className = $attrs['Class'];
				}
				//print_r($attrs);
				$_inheritFormName = "appbuilder.attredit.element.".$className."EditForm";
				$classFile = MODULE_PATH."/".str_replace(".","/",$_inheritFormName).".xml";
				//echo "class file is $classFile";
				if (file_exists($classFile)) {
					$inheritFormName = $_inheritFormName;
					//echo "inheritFormName is $inheritFormName";
				}
				$this->formType = $this->getFormType();
			}
			$this->m_InheritFrom = $inheritFormName;
		}
	}
    
	public function fetchData()
	{
		$this->m_EditingFormType = $this->getFormType();
		$this->m_ParentFormType = $this->getFormTypeDetail();
		// if has valid active record, return it, otherwise do a query
	    if ($this->m_ActiveRecord != null)
	        return $this->m_ActiveRecord;
		
		if (empty($this->m_ElemPath) || empty($this->m_AttrName)) {
			return parent::fetchData();
		}
		return $this->getElemAttributes();
	}
	
	public function getFormType()
	{
		$this->m_XmlFile = $this->m_MetaFile;
        if (!file_exists($this->m_XmlFile)) 
            return null;
        $rootElem = simplexml_load_file($this->m_XmlFile);
		$attrs = $rootElem->attributes();
		if(strtolower($attrs['FormType'])=="list")
		{
			return "list";
		}else{
			return "detail";
		}
	}
	
	public function getFormTypeDetail()
	{
		$this->m_XmlFile = $this->m_MetaFile;
        if (!file_exists($this->m_XmlFile)) 
            return null;
        $rootElem = simplexml_load_file($this->m_XmlFile);
		$attrs = $rootElem->attributes();
		if(strtolower($attrs['FormType']))
		{
			return strtolower($attrs['FormType']);
		}else{
			return "list";
		}
	}
	
	protected function getElemAttributes()
	{
		$this->m_XmlFile = $this->m_MetaFile;
		//echo "xml file is $this->m_XmlFile"; exit;
        if (!file_exists($this->m_XmlFile)) 
            return null;
        $rootElem = simplexml_load_file($this->m_XmlFile);
        //print_r($rootElem);
		$this->m_PrtElemPath = $_REQUEST['prt_elem_name'];
		$this->m_PrtAttrName = $_REQUEST['prt_elem_name_value'];
		if ($this->m_PrtElemPath) {
			$xpathStr = '//'.$this->m_PrtElemPath;
			if ($this->m_PrtAttrName) $xpathStr .= '[@Name="'.$this->m_PrtAttrName.'"]';
			$xpathStr .= '/'.$this->m_ElemPath.'[@Name="'.$this->m_AttrName.'"]';
		}
		else {
			$xpathStr = '//'.$this->m_ElemPath.'[@Name="'.$this->m_AttrName.'"]';
		}
        $elems = $rootElem->xpath($xpathStr);
        if (!$elems || count($elems)==0)
            return null;
        // give warning if find >1 matching elements
        if (count($elems) > 1)
        {
            echo "<div class='error'>WARNING: More than 1 '$this->m_ElemPath' elements are found with Name as '".$this->m_AttrName."'. Please change these elements with unique names!</div>";
        }
        // get the attributes of the element
        $elem = $this->_element = $elems[0];
        $attrs = $elem->attributes();
        foreach ($attrs as $k=>$v)
            $attrList[$k] = $v."";
		return $attrList;
	}
	
	public function outputAttrs()
	{
		$out = parent::outputAttrs();
		$out['xml_element'] = $this->_element;
		
		return $out;
	}
	
	public function saveRecord()
	{
		try
        {
            $this->ValidateForm();
        }
        catch (ValidationException $e)
        {
        	$this->processFormObjError($e->m_Errors);
            return;
        }
        $recArr = $this->readInputRecord();
        //merge extend attributes
        
        
        if (count($recArr) == 0)
            return;
        
        $metaXmlUtil = new MetadataXMLUtil($this->m_MetaFile);
		$metaXmlUtil->setCurrentElement($this->m_ElemPath, $this->m_AttrName, $this->m_PrtElemPath, $this->m_PrtAttrName);
		$elem = $metaXmlUtil->getCurrentElement();
		if ($elem) {
			if (!$metaXmlUtil->saveElement($recArr))
				return;
			//BizSystem::clientProxy()->showClientAlert ("Changes of ".$this->m_MetaFile." are saved");
			//if name has changed  then refresh left tree
			if($recArr['Name']!=$this->m_AttrName){
				$script = "<script>";				
				$script .= "renameElement('".$recArr['Name']."','".$this->m_ElemPath."','".$recArr['Name']."');";
				$script .= "</script>";	
				BizSystem::clientProxy()->runClientScript($script);
			}
			$this->m_Notices=array("fld_content"=>$this->getMessage("MSG_SAVED"));
	        $this->rerender();
        }
		else {
			if (!$metaXmlUtil->addElement($recArr, $this->m_PrtElemPath, $this->m_PrtAttrName))
				return;

			//if its create a new element then add it to left tree
			$script = "<script>";
			$script .= "addElement('".$recArr['Name']."','".$this->m_ElemPath."','".$recArr['Name']."');";
			$script .= "</script>";
			BizSystem::clientProxy()->runClientScript($script);
		}
	}
	
	public function deleteRecord()
	{
		$metaXmlUtil = new MetadataXMLUtil($this->m_MetaFile);
		$metaXmlUtil->setCurrentElement($this->m_ElemPath, $this->m_AttrName, $this->m_PrtElemPath, $this->m_PrtAttrName);
		if (!$metaXmlUtil->removeElement())
			return;
		// if name is changed, refresh the left tree node name
		$script = "<script>";
		$script .= "removeElement();";
		$script .= "</script>";
		BizSystem::clientProxy()->runClientScript($script);
	}
	
	public function moveElement($elemPath, $nameVal1, $nameVal2, $insertMode)
    {
		$metaXmlUtil = new MetadataXMLUtil($this->m_MetaFile);
		$metaXmlUtil->setCurrentElement($this->m_ElemPath, $this->m_AttrName, $this->m_PrtElemPath, $this->m_PrtAttrName);
		if (!$metaXmlUtil->moveElement($elemPath, $nameVal1, $nameVal2, $insertMode))
			return;
		//BizSystem::clientProxy()->showClientAlert ("Changes of ".$this->m_MetaFile." are saved");
    }
	
	public function showAddChildForm($childElemName)
	{
		$_POST['elem_name'] = $_REQUEST['elem_name'] = $childElemName;
		$_POST['prt_elem_name'] = $_REQUEST['prt_elem_name'] = $this->m_ElemPath;
		$_POST['prt_elem_name_value'] = $_REQUEST['prt_elem_name_value'] = $this->m_AttrName;
		//$_POST['elem_name_value'] = $_REQUEST['elem_name_value'] = $attrNameValue;
		
		$attrEditFormName = "appbuilder.attredit.MetaElemEditForm";
		$attrEditFormObj = BizSystem::getObject($attrEditFormName,1);
		
		// rerender the right panel form to the attribute edit form
		$attrEditFormObj->rerender();
	}
	
	public function ShowInfo()
	{
		
		//BizSystem::getObject("appbuilder.attredit.info.InfoForm")->render();
		$this->switchForm("appbuilder.attredit.info.InfoForm");
	}
	
	public function GetMetaFileInfo()
    {
    	$pos = strrpos($this->m_MetaFile, "modules/");
        if ($pos > 0)
        {
            $modulesPath = substr($this->m_MetaFile, 0, $pos+8);
            $pos = strrpos($this->m_MetaFile, "/");
            $fileName = substr($this->m_MetaFile, $pos+1);
            $package = str_replace("/",".",str_replace(array($modulesPath, "/".$fileName),"",$this->m_MetaFile));
            return array('modules_path'=>$modulesPath, 'package'=>$package, 'fileName'=>$fileName);
        }
        return null;
    }
	
	protected function GetDocDocument()
    {
        if ($this->m_Doc) 
            return $this->m_Doc;
        //$this->m_XmlFile = MODULE_PATH."/".str_replace(".","/",$this->m_MetaName).".xml";
        $this->m_XmlFile = $this->m_MetaFile;
        
        if (!file_exists($this->m_XmlFile)) 
            return null;
        $doc = new DomDocument();
        $ok = $doc->load($this->m_XmlFile);
        if (!$ok)
            return null;
        $this->m_Doc = $doc;
        //$rootElem = $doc->documentElement;
        return $doc;
    }
	
	public function QueryXpath($xpathStr, $returnSingle=true)
    {
        $doc = $this->GetDocDocument();
        if (!$doc) return false;
        
        $xpath = new DOMXPath($doc);
        $elems = $xpath->query($xpathStr);
        if ($returnSingle)
        {
            $elem = $elems->item(0);
            return $elem;
        }
        return $elems;
    }
}
?>