<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.attredit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class SimpleExprForm extends PickerForm 
{ 
	
	public function SaveRecord()
	{
		//$fld_data = BizSystem::clientProxy()->getFormInputs('fld_data');
		$rec = $this->readInputRecord();
		
		//$parentForm = BizSystem::objectFactory()->getObject($this->m_ParentFormName);
    	$updArray = array();
    	$updRec = $this->m_ParentFormRecord;
		// get the picker map of the control
		if ($this->m_PickerMap)
		{
			$pickerList = $this->_parsePickerMap($this->m_PickerMap);	            
			foreach ($pickerList as $ctrlPair)
			{
				$this_ctrl = $this->getElement($ctrlPair[1]);
				if (!$this_ctrl)
					continue;
									
				$this_ctrl_val = $rec[$this_ctrl->m_FieldName];
				$other_ctrl_name = $ctrlPair[0];
				if(!$updArray[$other_ctrl_name]){
					$updArray[$other_ctrl_name] = $this_ctrl_val;
				}else{
					$updArray[$other_ctrl_name] .= ';'.$this_ctrl_val;
				}
			}	            
		}
		$this->close();	                                               
		
		BizSystem::clientProxy()->updateFormElements($this->m_ParentFormName, $updArray);
	}
	
	public function setParentFormData($formName, $elemName=null, $pickerMap=null)
    {
        $this->m_ParentFormName = $formName;
        $this->m_ParentFormElemName = $elemName;
        $this->m_PickerMap = $pickerMap;
		$elemValue = BizSystem::clientProxy()->getFormInputs($elemName);
		$this->getElement("fld_expression")->m_Value = $elemValue;
    }
    
    public function updateForm()
    {
    	$rec = $this->readInputRecord();
    	switch(strtolower($rec['expr_type']))
    	{
    		case "php":
    			switch(strtolower($rec['expr_php_temp']))
    			{
    				case "const":
    					$rec['expression'] = "{tx}APP_INDEX{/tx}/module/view_name";
    					break;
    				case "date":
    					$rec['expression'] = "{fx}date('Y-m-d',time()){/fx}";
    					break;
    				case "string":
    					$rec['expression'] = '{tx}$customString{/tx}';
    					break;
    				case "obj_attr":
    					$rec['expression'] = '{tx}@:'.$rec['php_obj_attr'].'{/tx}';
    					break;
    				case "obj_method":
    					$rec['expression'] = '{tx}@:'.$rec['php_obj_method'].'(){/tx}';
    					break;    					
    				case "condition":
    					$rec['expression'] = '{$test?\'Y\':\'N\'}';
    					break;
    				case "profile":
    					$rec['expression'] = '{@profile:Id}';
    					break;
    				case "string":
    					$rec['expression'] = '{tx}$customString{/tx}';
    					break;
    			}
    			break;
    		case "form_element":
    			switch(strtolower($rec['form_obj_type']))
    			{
    				case "current":
    					if($rec['form_current_element'])
    					{
    						$rec['expression'] = '{tx}@:Elem['.$rec['form_current_element'].'].Value{/tx}';
    					}
    					break;
    				case "specified":
    					if($rec['form_object'] && $rec['form_element']){
    						$rec['expression'] = '{tx}@'.$rec['form_object'].':Elem['.$rec['form_element'].'].Value{/tx}';
    					}
    					break;
    			}
    			break;
    			
    		case "data_field":
    	    	switch(strtolower($rec['data_obj_type']))
    			{
    				case "current":
    					if($rec['data_current_field'])
    					{
    						$rec['expression'] = '{tx}@:Field['.$rec['data_current_field'].'].Value{/tx}';
    					}
    					break;
    				case "specified":
    					if($rec['data_object'] && $rec['data_field']){
    						$rec['expression'] = '{tx}@'.$rec['data_object'].':Field['.$rec['data_field'].'].Value{/tx}';
    					}
    					break;
    			}    			
    			break;
    			
    		case "call_service":
    			$rec['expression'] = '{tx}BizSystem::getService('.$rec['svc_object'].')->'.$rec['svc_method'].'(){/tx}';
    			break;
    	}
    	$this->setActiveRecord($rec);
    	$this->rerender();
    }
    
    public function getCurrentObject()
    {
    	return $_REQUEST['metaobj'];
    }
}
?>