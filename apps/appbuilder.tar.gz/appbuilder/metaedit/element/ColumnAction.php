<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

require_once OPENBIZ_BIN.'/easy/element/ColumnText.php';
class ColumnAction extends ColumnText
{
	public function render(){
		$func_up = $this->getBtnFunction('btn_action_edit');
		$func_down = $this->getBtnFunction('btn_action_delete');
		$formobj = $this->getFormObj();		
        
        
        $style = $this->getStyle();
        $id = $this->m_Name;

        
		$sHTML = "<a $func_up  class=\"btn_edit\" href=\"javascript:;\"><img src=\"".Resource::getImageUrl()."/spacer.gif"."\" style=\"width:12px;height:12px;\" /></a> ".
				 "<a $func_down  class=\"btn_delete\" href=\"javascript:;\"><img src=\"".Resource::getImageUrl()."/spacer.gif"."\" style=\"width:12px;height:12px;\" /></a>";
		return $sHTML;
	}
	
	public function getBtnFunction($event_name){
        $name = $this->m_Name;
        // loop through the event handlers
        $func = "";

        if ($this->m_EventHandlers == null)
            return null;
        $formobj = $this->getFormObj();
        
        $eventHandler = $this->m_EventHandlers->get($event_name);
                
        $ehName = $eventHandler->m_Name;
        $event = $eventHandler->m_Event;
        $type = $eventHandler->m_FunctionType;
        if (!$event) return;
        if($events[$event]!=""){
           $events[$event]=array_merge(array($events[$event]),array($eventHandler->getFormedFunction()));
        }else{
           $events[$event]=$eventHandler->getFormedFunction();
        }

		foreach ($events as $event=>$function){
			if(is_array($function)){
				foreach($function as $f){
					$function_str.=$f.";";
				}
				$func .= " $event=\"$function_str\"";
			}else{
				$func .= " $event=\"$function\"";
			}
		}
        return $func;		
	}
}
?>