<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit.creator.element
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

require_once OPENBIZ_BIN.'/easy/element/Listbox.php';

class TemplatePackageSelector extends Listbox
{
	public function getFromList(&$list, $selectFrom=null)
	{
		$module = $this->getSelectedModuleName();
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$pkgList = $svc->listTemplateLocations($module);
        foreach ($pkgList as $package)
        {                    	        	
        	$list[$i]['val'] = $package;
		    $list[$i]['txt'] = $package;
		    $i++;        		        	     	
        }
	}
	
	public function getSelectedModuleName()
	{
		if($this->getFormObj()->getViewObject()->m_Name=='appbuilder.view.ModuleDetailView')
		{
			$module = BizSystem::getObject("appbuilder.metaedit.ModuleInfoForm")->m_RecordId;
		}
		else
		{
			$module = BizSystem::getObject("appbuilder.metaedit.ModuleFilterForm")->m_RecordId;
		}	
		return $module;
	}
		
}
?>