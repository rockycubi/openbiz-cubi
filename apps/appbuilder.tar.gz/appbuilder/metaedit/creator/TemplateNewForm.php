<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit.creator
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class TemplateNewForm extends EasyForm
{
	public function fetchData()
	{	
		if ($this->m_ActiveRecord != null)
		{
            $result = $this->m_ActiveRecord;
		}
		$module = $this->getSelectedModuleName();
		$result['module'] = $this->getSelectedModuleName();
		return $result;
	}
	
	public function getSelectedModuleName()
	{
		if($this->getViewObject()->m_Name=='appbuilder.view.ModuleDetailView')
		{
			$module = BizSystem::getObject("appbuilder.metaedit.ModuleInfoForm")->m_RecordId;
		}
		else
		{
			$module = BizSystem::getObject("appbuilder.metaedit.ModuleFilterForm")->m_RecordId;
		}	
		return $module;
	}
	
	public function Create()
	{
		$rec = $this->readInputRecord();
		$this->setActiveRecord($rec);
		$filename = $rec['filename'];
		$package = $rec['package'];
		$module = $this->getSelectedModuleName();
		$fileShortPath = str_replace(".",'/',$package).DIRECTORY_SEPARATOR.$filename;		
		$filePath = MODULE_PATH.DIRECTORY_SEPARATOR.$fileShortPath;
		$templateFile = MODULE_PATH.DIRECTORY_SEPARATOR.'appbuilder'.DIRECTORY_SEPARATOR.'resource'.
						DIRECTORY_SEPARATOR.'module_template'.DIRECTORY_SEPARATOR.'template'.DIRECTORY_SEPARATOR.$rec['template'];
		$fileFolderPath = MODULE_PATH.DIRECTORY_SEPARATOR.str_replace(".",'/',$package);
		if(!is_dir($fileFolderPath))
		{
			@mkdir($fileFolderPath,0777);
		}			
						
		//validate if the file exists				
		if(is_file($filePath))
		{
			$this->m_Errors = array(
				"fld_filename" => $this->getMessage("TARGET_FILE_EXISTS")
			);
			$this->rerender();
			return;
		}
		
		if(!is_file($templateFile))
		{
			$this->m_Errors = array(
				"fld_template" => $this->getMessage("TEMPLATE_FILE_DOES_NOT_EXISTS")
			);
			$this->rerender();
			return;
		}
		
		@copy($templateFile,$filePath);
		
		$url = APP_INDEX."/appbuilder/code_edit/file=".base64_encode($fileShortPath);
		BizSystem::clientProxy()->redirectPage($url);
	}
}
?>