<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */


class CodeEditForm extends EasyForm 
{ 
    protected $m_MetaFile;
    protected $m_CodeFile;
	
	protected function readMetadata(&$xmlArr)
	{
		parent::readMetaData($xmlArr);
		// change the inheritFrom according to the input element type
		$file = base64_decode($_REQUEST['file']);
		
		$codefile = MODULE_PATH."/".$file;
		$this->m_MetaFile = $codefile;
	}
    
	public function fetchData()
	{
		$this->m_CodeFile = $this->m_MetaFile;
		//echo "xml file is $this->m_CodeFile";
        if (!file_exists($this->m_CodeFile)) {
            return null;
		}
		$text = file_get_contents($this->m_CodeFile);
        //$text = htmlentities(file_get_contents($this->m_CodeFile));
        return array("fld_content"=>$text);
	}
	
	public function validateForm()
	{
		return true;
	}

	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		switch($_GET['type'])
		{
			case "xml":
				$result['editor_mode']='{name: "xml", alignCDATA: true}';
				break;
			
			case "code":
			default:
				$result['editor_mode']='"application/x-httpd-php"';
				break;
			
		}
		return $result;
	}	
	
	public function saveRecord()
	{
		$currentRec = $this->fetchData();
        $recArr = $this->readInputRecord();
        $this->setActiveRecord($recArr);
        if (count($recArr) != 0){
            	
	        try
	        {
	            $this->ValidateForm();
	        }
	        catch (ValidationException $e)
	        {
	            $this->processFormObjError($e->m_Errors);
	            return;
	        }
	
	        $content = $recArr['content'];	 
	        file_put_contents($this->m_CodeFile, $content);
	        $this->m_Notices=array("fld_content"=>$this->getMessage("MSG_SAVED"));
	        $this->rerender();
        
        }
        // in case of popup form, close it, then rerender the parent form
        if ($this->m_ParentFormName)
        {
            $this->close();

            $this->renderParent();
        }
	}
}
?>