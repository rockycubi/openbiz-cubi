<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

/**
 * 
 * Source Editor is only for edit XML metadata.
 * so parse code as XML data
 * @author jixian
 *
 */
class SourceEditForm extends EasyForm 
{ 
    protected $m_MetaFile;
    protected $m_XmlFile;
    protected $m_Doc;
	
	protected function readMetadata(&$xmlArr)
	{
		parent::readMetaData($xmlArr);
		// change the inheritFrom according to the input element type
		$metaObj = $_REQUEST['metaobj'];
		
		$metaFile = MODULE_PATH."/".str_replace(".","/",$metaObj).".xml";
		$this->m_MetaFile = $metaFile;
	}
    
	public function fetchData()
	{
		$this->m_XmlFile = $this->m_MetaFile;
		//echo "xml file is $this->m_XmlFile";
        if (!file_exists($this->m_XmlFile)) {
            return null;
		}
		$text = file_get_contents($this->m_XmlFile);
        //$text = htmlentities(file_get_contents($this->m_XmlFile));
        return array("fld_content"=>$text);
	}
	
	public function validateForm()
	{
		return true;
	}
	
	public function outputAttrs()
	{
		$result = parent::outputAttrs();		
		$result['editor_mode']='{name: "xml", alignCDATA: true}';
		return $result;
	}	
		
	public function saveRecord()
	{
		$currentRec = $this->fetchData();
        $recArr = $this->readInputRecord();
        $this->setActiveRecord($recArr);
        if (count($recArr) != 0){
            	
	        try
	        {
	            $this->ValidateForm();
	        }
	        catch (ValidationException $e)
	        {
	            $this->processFormObjError($e->m_Errors);
	            return;
	        }	
	        
	        $content = $recArr['content'];	 
	        file_put_contents($this->m_XmlFile, $content);
	        //$script = "<script>alert('Saved ".$this->m_XmlFile."')</script>";
	        //BizSystem::clientProxy()->runClientScript($script);
	        $this->m_Notices=array("fld_content"=>$this->getMessage("MSG_SAVED"));
			$this->rerender();
        }
        // in case of popup form, close it, then rerender the parent form
        if ($this->m_ParentFormName)
        {
            $this->close();

            $this->renderParent();
        }
	}
}
?>