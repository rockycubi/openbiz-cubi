<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class ModuleInfoForm extends EasyForm
{
	public $m_RecordId;
	
	public function fetchData()
	{
		$module = $_GET['mod'];
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	if(is_dir(MODULE_PATH.DIRECTORY_SEPARATOR.$module))
    	{
    		$result = $svc->getModuleInfo($module);
    	}    
    	$this->m_RecordId = $module;
    	return $result;
	}
	
	public function outputAttrs()
	{
		$result = parent::outputAttrs();
		$result['moduleName'] = ucwords($_GET['mod']);
		return $result;
	}
}
?>