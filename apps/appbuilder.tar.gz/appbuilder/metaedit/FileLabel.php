<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

class FileLabel extends EasyForm
{
	protected $m_File;
	
	public function outputAttrs()
    {
    	$this->m_File = MODULE_PATH.DIRECTORY_SEPARATOR.base64_decode($_REQUEST['file']);
    	$filename = base64_decode($_REQUEST['file']);
    	$out['filename_full'] = $filename;
    	$filename = basename($filename);
        $out['name'] = $this->m_Name;
        $out['filename'] = $filename;
        $out['title'] = $this->m_Title;
        $out['hasSubform'] = $this->m_SubForms ? 1 : 0;
        $out['depth'] = $this->m_Depth;
		
        $out['description'] = $this->m_Description;
        $out['filesize'] = filesize($this->m_File);
        $out['filesize_h'] = BizSystem::getService(UTIL_SERVICE)->format_bytes($out['filesize']);
        $out['modification_time'] = date("Y-m-d H:i:s",filemtime($this->m_File));
        $out['creation_time'] = date("Y-m-d H:i:s",filectime($this->m_File));
        $out['formobj'] = $this;
        return $out;
    }
}
?>