<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

require_once 'MetaObjListForm.php';
class PhpListForm extends MetaObjListForm
{
	public function GetRecordList()
	{
		if($this->getViewObject()->m_Name=='appbuilder.view.ModuleDetailView')
		{
			$module = BizSystem::getObject("appbuilder.metaedit.ModuleInfoForm")->m_RecordId;
		}
		else
		{
			$module = BizSystem::getObject("appbuilder.metaedit.ModuleFilterForm")->m_RecordId;
		}
		
		$svc = BizSystem::getObject("appbuilder.lib.MetadataService");
    	$objList = $svc->listPHPFiles($module);
    	
    	foreach($objList as $obj)
    	{
    		$objInfo = $svc->getTemplateInfo($obj);
    		$objInfo['PATH'] = base64_encode($objInfo['Id']);
    		$objInfo['Name'] = $objInfo['NAME'];
    		$result[] = $objInfo;
    	}
    	return $result;
	}	
}
?>