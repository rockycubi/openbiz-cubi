<?php
/**
 * Openbiz AppBuilder
 *
 * LICENSE http://www.openbiz.me/developer/appbuilder/eula.php
 *
 * @package   appbuilder.metaedit
 * @copyright Copyright (c) 2008-2012, Openbiz Technology LLC
 * @license   http://www.openbiz.me/developer/appbuilder/eula.php
 * @version   $Id$
 */

require_once MODULE_PATH.'/common/form/ArrayListForm.php';
class MetaObjListForm extends ArrayListForm
{
	public function EditFile($path=null)
	{
		if(!$path){
			$path = base64_encode($this->m_RecordId);
		}
		$url = APP_INDEX."/appbuilder/code_edit/file=".$path;		
		BizSystem::clientProxy()->redirectPage($url);
	}

	
	public function EditMeta($obj=null)
	{
		if(!$obj){			
			$record = $this->fetchRecord($this->m_RecordId);
			$obj = $record['PACKAGE'].'.'.$record['NAME'];			
		}
		$url = APP_INDEX."/appbuilder/xml_edit/metaobj=".$obj;		
		BizSystem::clientProxy()->redirectPage($url);
	}
	
	public function fetchRecord($Id)
	{
		$recordList = $this->fetchDataSet();
		if(!$id)
		{
			return $recordList[0];
		}
		foreach ($recordList as $record)
		{
			if($record['Id']==$Id)
			{
				return $record;
			}
		}
	}
	
	public function DeleteRecord($path=null,$format=0)
	{		
		switch((int)$format)
		{
			case 0: //for code files
			default:
				if(!$path){
					$path = base64_encode($this->m_RecordId);
				}
				$path = MODULE_PATH.DIRECTORY_SEPARATOR.base64_decode($path);
				break;
				
			case 1: //for meta obj;		
				if(!$path || strtolower($path) =='null'){			
					$record = $this->fetchRecord($this->m_RecordId);
					$path = $record['PACKAGE'].'.'.$record['NAME'];
				}					
				$obj = $path;
				$path = MODULE_PATH.DIRECTORY_SEPARATOR.str_replace(".",DIRECTORY_SEPARATOR,$obj).'.xml';
				break;
		}	
		
		@unlink($path);
		if (strtoupper($this->m_FormType) == "LIST")
            $this->rerender();
            
        $this->runEventLog();
        $this->processPostAction();		
	}
	
	
 
}
?>